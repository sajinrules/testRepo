<?php

/************************************************************/
/*                                                          */
/* Fonction de v�rification de l'ouverture des commentaires */
/*                                                          */
/************************************************************/

function wats_get_ticket_update_rights()
{
	global $wats_settings, $current_user, $post;
	
	wats_load_settings();
	
	if ($wats_settings['ticket_status_key_enabled'] == 1 && get_post_meta($post->ID,'wats_ticket_status',true) == wats_get_closed_status_id() && !current_user_can('administrator'))
		return false;
	else if ($wats_settings['visibility'] == 2 && (!is_user_logged_in() || (is_user_logged_in() && !current_user_can('administrator') && $current_user->ID != $post->post_author && ($wats_settings['ticket_visibility_same_company'] == 0 || wats_check_user_same_company($current_user->ID,$post->post_author) == false))))
		return false;

	return true;
}

/****************************************************************************/
/*                                                                          */
/* Fonction de renvoi du message d'erreur pour l'ouverture des commentaires */
/*                                                                          */
/****************************************************************************/

function wats_get_ticket_update_rights_message()
{
	global $wats_settings, $current_user, $post;
	
	wats_load_settings();
	
	$output = '';
	if ($wats_settings['ticket_status_key_enabled'] == 1 && get_post_meta($post->ID,'wats_ticket_status',true) == wats_get_closed_status_id() && !current_user_can('administrator'))
	{
		$output .= '<div id="ticket_is_closed">'.__('The ticket is closed. Only administrators could reopen it.','WATS').'</div>';
	}
	else if ($wats_settings['visibility'] == 2 && (!is_user_logged_in() || (is_user_logged_in() && !current_user_can('administrator') && $current_user->ID != $post->post_author && ($wats_settings['ticket_visibility_same_company'] == 0 || wats_check_user_same_company($current_user->ID,$post->post_author) == false))))
	{
		$output .= '<div id="ticket_is_read_only">'.__('Only admins and ticket author can update this ticket.','WATS').'</div>';
	}
		
	return $output;
}


/*********************************************************/
/*                                                       */
/* Fonction de v�rification de la visibilit� des tickets */
/*                                                       */
/*********************************************************/

function wats_check_visibility_rights()
{
	global $wats_settings, $current_user, $post;

	if ($wats_settings['visibility'] == 0)
		return true;
	else if ($wats_settings['visibility'] == 1 && is_user_logged_in())
		return true;
	else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || $current_user->ID == $post->post_author || (!is_admin() && $wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only')) || ($wats_settings['ticket_visibility_same_company'] == 1 && wats_check_user_same_company($current_user->ID,$post->post_author) == true)))
		return true;
		
	return false;
}

/***************************************************/
/*                                                 */
/* Fonction de g�n�ration du rapport au format xml */
/*                                                 */
/***************************************************/

function wats_ticket_listing_get_xml()
{

	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=tickets-list.xml;");
	header("Content-Type: application/ms-excel");
	header("Pragma: no-cache");
	header("Expires: 0");

	$output = '<?xml version="1.0"?>'."\n";
	$output .= '<?mso-application progid="Excel.Sheet"?>'."\n";
	$output .= '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" 
				xmlns:o="urn:schemas-microsoft-com:office:office" 
				xmlns:x="urn:schemas-microsoft-com:office:excel" 
				xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" 
				xmlns:html="http://www.w3.org/TR/REC-html40">'."\n";
				
	$output .= '<Styles>';
	$output .= '<Style ss:ID="Default" ss:Name="Normal"><Alignment ss:Vertical="Bottom"/><Borders/><Font/><Interior/><NumberFormat/><Protection/></Style>';
	$output .= '<Style ss:ID="s45"><Alignment ss:Horizontal="Center" ss:Vertical="Center"/><Borders> <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/></Borders><Font ss:FontName="Verdana" x:Family="Swiss" ss:Size="12" ss:Color="#333333" ss:Bold="1" ss:Underline="Single"/></Style>';
	$output .= '<Style ss:ID="s51"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/></Borders><Font ss:FontName="Verdana" x:Family="Swiss" ss:Size="8" ss:Bold="1"/><Interior ss:Color="#99CCFF" ss:Pattern="Solid"/></Style>';
	$output .= '<Style ss:ID="s52"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/></Borders><Font ss:FontName="Verdana" x:Family="Swiss" ss:Size="9" ss:Color="#333333"/><Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/></Style>';
	$output .= '<Style ss:ID="s53"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/></Borders><Font ss:FontName="Verdana" x:Family="Swiss" ss:Size="9" ss:Color="#0000FF" ss:Underline="Single"/><Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/></Style>';
	$output .= '<Style ss:ID="s54"><Alignment ss:Horizontal="Center" ss:Vertical="Center" ss:WrapText="1"/><Borders><Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/><Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2" ss:Color="#C0C0C0"/></Borders><Font ss:FontName="Verdana" x:Family="Swiss" ss:Size="9" ss:Color="#333333" /><Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/><NumberFormat ss:Format="Short Date"/></Style>';
	$output .= '</Styles>'."\n";
	$output .= "<Worksheet ss:Name='".__('Tickets listing','WATS')."'>\n";
	$output .= '<Table ss:ExpandedColumnCount="256" x:FullColumns="1" x:FullRows="1" ss:DefaultColumnWidth="60">'."\n";
	$output .= '<Column ss:AutoFitWidth="0" ss:Width="65.25" ss:Span="255"/>';

	$output .= wats_ticket_list_ajax_processing(2);
	$output .= "</Table></Worksheet></Workbook>\n";
	
	echo $output;
	die;
	
	return;
}

/*******************************************************/
/*                                                     */
/* Fonction de processing Ajax de la liste des tickets */
/* view 1 : listing ajax classique					   */
/* view 2 : fichier xml								   */
/* view 3 : listing ajax custom query				   */
/*                                                     */
/*******************************************************/

function wats_ticket_list_ajax_processing($view)
{
	global $wats_settings, $current_user;

	wats_load_settings();
	
	$query_on = 0;
	$idquery = isset($_POST['wats_select_custom_query_tl']) ? $_POST['wats_select_custom_query_tl'] : -1;
	if ($idquery > -1)
		$query_on = 1;

	if ($view != 2)
	{
		$view = $_POST['view'];
		check_ajax_referer('filter-wats-tickets-list');
		
		if ($view == 3)
			$view = 1;
	}
	
	if ($view == 1 || $view == 2)
	{
		$idnumber = isset($_POST['wats_input_ticket_number_tl']) ? $_POST['wats_input_ticket_number_tl'] : NULL;
		$idtype = isset($_POST['wats_select_ticket_type_tl']) ? $_POST['wats_select_ticket_type_tl'] : -1;
		$idpriority = isset($_POST['wats_select_ticket_priority_tl']) ? $_POST['wats_select_ticket_priority_tl'] : -1;
		$idstatus = isset($_POST['wats_select_ticket_status_tl']) ? $_POST['wats_select_ticket_status_tl'] : -1;
		$idstatusop = isset($_POST['wats_select_ticket_status_operator']) ? $_POST['wats_select_ticket_status_operator'] : -1;
		$idproduct = isset($_POST['wats_select_ticket_product_tl']) ? $_POST['wats_select_ticket_product_tl'] : -1;
		
		if (($wats_settings['visibility'] == 0) || ($wats_settings['visibility'] == 1 && is_user_logged_in()) || ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only')))))
		{
			$idauthor = isset($_POST['wats_select_ticket_author_tl']) ? stripslashes_deep($_POST['wats_select_ticket_author_tl']) : 0;
			if ($wats_settings['ticket_assign'] != 0)
				$idowner = isset($_POST['wats_select_ticket_owner_tl']) ? stripslashes_deep($_POST['wats_select_ticket_owner_tl']) : 0;
		}
		else if ($wats_settings['visibility'] == 2 && !current_user_can('administrator') && $wats_settings['ticket_visibility_same_company'] == 1)
		{
			if (wats_check_user_same_company($current_user->ID,wats_get_user_ID_from_user_login(stripslashes_deep($_POST['wats_select_ticket_author_tl']))) == true)
				$idauthor = isset($_POST['wats_select_ticket_author_tl']) ? stripslashes_deep($_POST['wats_select_ticket_author_tl']) : 0;
			else
				$idauthor = "0";
			$idowner = "0";
		}
		else
		{
			$idauthor = "0";
			$idowner = "0";
		}
		
		if ($wats_settings['ticket_assign'] == 0)
			$idowner = "0";
		
		if ((current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))) && $wats_settings['filter_ticket_listing'] == 1)
			$idauthormetavalue = stripslashes_deep($_POST['wats_select_ticket_author_meta_value_tl']);
		else
			$idauthormetavalue = "0";

		$categoryfilter = stripslashes_deep($_POST['categoryfilter']);
		$categorylistfilter = stripslashes_deep($_POST['categorylistfilter']);
		if ($view == 1)
		{
			$listecf = isset($_POST['liste']) ? json_decode(stripslashes($_POST['liste'])) : 0;
		
			if (is_array($listecf))
			foreach ($listecf as $key => $table)
			{
				foreach ($table as $subkey => $value)
					$liste[$subkey] = $value;
			}
			unset($listecf);
		}
		
		$wats_ticket_custom_field_values = (isset($wats_settings['wats_ticket_custom_fields'])) ? $wats_settings['wats_ticket_custom_fields'] : 0;
		
		$listecf = array();
		if (is_array($wats_ticket_custom_field_values))
		foreach ($wats_ticket_custom_field_values as $key => $table)
		{
			if ($table['ftlf'] == 1 || ($table['ftlf'] == 2 && current_user_can('administrator')))
			{
				if ($view == 1)
				{
					if (isset($liste['wats_cf_datepicker_'.$table['meta_key']]) && strlen($liste['wats_cf_datepicker_'.$table['meta_key']]) > 0)
					{
						if (wats_is_date($liste['wats_cf_datepicker_'.$table['meta_key']],2))
							$listecf[$table['meta_key']] = date("Y-m-d",strtotime($liste['wats_cf_datepicker_'.$table['meta_key']]));
						else
							$listecf[$table['meta_key']] = '';
					}
					else if (isset($liste['wats_cf_'.$table['meta_key']]) && strlen($liste['wats_cf_'.$table['meta_key']]) > 0)
						$listecf[$table['meta_key']] = $liste['wats_cf_'.$table['meta_key']];
					else if (isset($liste['wats_select_cf_'.$table['meta_key']]) && strlen($liste['wats_select_cf_'.$table['meta_key']]) > 0 && $liste['wats_select_cf_'.$table['meta_key']] != "0")
						$listecf[$table['meta_key']] = $liste['wats_select_cf_'.$table['meta_key']];
				}
				else if ($view == 2)
				{
					if (isset($_POST['wats_cf_datepicker_'.$table['meta_key']]) && strlen($_POST['wats_cf_datepicker_'.$table['meta_key']]) > 0)
					{
						if (wats_is_date($_POST['wats_cf_datepicker_'.$table['meta_key']],2))
							$listecf[$table['meta_key']] = date("Y-m-d",strtotime(stripslashes($_POST['wats_cf_datepicker_'.$table['meta_key']])));
						else
							$listecf[$table['meta_key']] = '';
					}
					else if (isset($_POST['wats_cf_'.$table['meta_key']]) && strlen($_POST['wats_cf_'.$table['meta_key']]) > 0)
						$listecf[$table['meta_key']] = stripslashes($_POST['wats_cf_'.$table['meta_key']]);
					else if (isset($_POST['wats_select_cf_'.$table['meta_key']]) && strlen($_POST['wats_select_cf_'.$table['meta_key']]) > 0 && $_POST['wats_select_cf_'.$table['meta_key']] != "0")
						$listecf[$table['meta_key']] = stripslashes($_POST['wats_select_cf_'.$table['meta_key']]);
				}
			}
		}

		if (isset($_POST['wats_page_list_tl']) && $_POST['wats_page_list_tl'] != 0)
			$selected_page = $_POST['wats_page_list_tl'];
		else
			$selected_page = 1;

		if (isset($_POST['wats_tickets_per_page_list_tl']) && $_POST['wats_tickets_per_page_list_tl'] !== 0)
			$tickets_per_page = $_POST['wats_tickets_per_page_list_tl'];
		else
			$tickets_per_page = 0;

		if ($query_on == 1)
		{
			$wats_ticket_listing_queries = (isset($wats_settings['wats_ticket_listing_queries'])) ? $wats_settings['wats_ticket_listing_queries'] : array();
			
			if (!isset($wats_ticket_listing_queries[$idquery]))
			{
				echo __('Error : query not found','WATS');
				exit;
			}
			else
			{
					if ($wats_settings['ticket_type_key_enabled'] == 1)
						$idtype = $wats_ticket_listing_queries[$idquery]['type'];
					else
						$idtype = 0;
					
					if ($wats_settings['ticket_priority_key_enabled'] == 1)
						$idpriority = $wats_ticket_listing_queries[$idquery]['priority'];
					else
						$idpriority = 0;
						
					if ($wats_settings['ticket_status_key_enabled'] == 1)
					{
						$idstatus = $wats_ticket_listing_queries[$idquery]['status'];
						$idstatusop = $wats_ticket_listing_queries[$idquery]['status_op'];
					}
					else
					{
						$idstatus = 0;
						$idstatusop = 0;
					}
						
					if ($wats_settings['ticket_product_key_enabled'] == 1)
						$idproduct = $wats_ticket_listing_queries[$idquery]['product'];
					else
						$idproduct = 0;
						
					if (($wats_settings['visibility'] == 0) || ($wats_settings['visibility'] == 1 && is_user_logged_in()) || ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only')))))
					{
						if ($wats_ticket_listing_queries[$idquery]['author'] == 1 && is_user_logged_in())
							$idauthor = $current_user->user_login;
						else
							$idauthor = 0;
						
						if ($wats_settings['ticket_assign'] != 0)
						{
							if ($wats_ticket_listing_queries[$idquery]['owner'] == '2' && is_user_logged_in())
								$idowner = $current_user->user_login;
							else if ($wats_ticket_listing_queries[$idquery]['owner'] == '1')
								$idowner = 1;
							else
								$idowner = 0;
						}
						else
							$idowner = 0;
					}
					else if ($wats_settings['visibility'] == 2 && !current_user_can('administrator') && $wats_settings['ticket_visibility_same_company'] == 1)
					{
						if ($wats_ticket_listing_queries[$idquery]['author'] == 1 && is_user_logged_in())
							$idauthor = $current_user->user_login;
						else
							$idauthor = 0;
						$idowner = 0;
					}
					else
					{
						$idauthor = 0;
						$idowner = 0;
					}
				}
		}

		$output = wats_list_tickets($categoryfilter, $categorylistfilter, $view, $idtype, $idpriority, $idstatus, $idproduct, $idowner, $idauthor, $idauthormetavalue, $idstatusop, $listecf, $selected_page, $tickets_per_page, $idnumber, -1);
		
		if ($view == 1)
		{
			echo $output;
			exit;
		}
		else if ($view == 2)
		{
			return $output;
		}
	}
	
	return;
}

/********************************************************************************/
/*                                                                              */
/* Fonction de filtrage sur le contenu pour l'affichage de la table des tickets */
/*                                                                              */
/********************************************************************************/

function wats_list_tickets_filter($content)
{
    return (preg_replace_callback(WATS_TICKET_LIST_REGEXP, 'wats_list_tickets_args', $content));
}

/********************************************************************************/
/*                                                                              */
/* Fonction de filtrage des param�tres pour l'affichage de la table des tickets */
/*                                                                              */
/********************************************************************************/

function wats_list_tickets_args($args)
{
	global $wpdb, $post, $wats_ticket_list_shortcode, $wats_settings, $current_user;
	
	$output = '';
	
	if (WATS_PREMIUM == false)
	{
		$output = __('The frontend ticket listing feature is only available in the premium release. Don\'t hesitate to <a href="http://www.ticket-system.net/order/">order it</a>!','WATS');
	}
	else
	{	
		wats_load_settings();
		
		$wats_ticket_list_shortcode = true;
		$args = explode(" ", rtrim($args[0], "]"));
		$cats = get_the_category($post->ID);
		
		$wats_ticket_listing_queries = (isset($wats_settings['wats_ticket_listing_queries'])) ? $wats_settings['wats_ticket_listing_queries'] : array();
			
		$catlist = array();
		foreach ($cats as $cat)
		{	
			$catlist[] = $cat->cat_ID;
		}
		
		if (is_array($catlist))
			$catlist = implode(',',$catlist);
		else
			$catlist = 1;
		
		$query = -1;
		if (isset($args[2]) && isset($wats_ticket_listing_queries[$args[2]]))
		{
			$default_query = $wats_ticket_listing_queries[$args[2]];
			$query = $args[2];
		}
		else
			$default_query = $wats_settings['wats_default_ticket_listing_default_query'];
		
		$idnumber = NULL;

		if ($wats_settings['ticket_type_key_enabled'] == 1)
			$type = $default_query['type'];
		else
			$type = 0;
		
		if ($wats_settings['ticket_priority_key_enabled'] == 1)
			$priority = $default_query['priority'];
		else
			$priority = 0;
			
		if ($wats_settings['ticket_status_key_enabled'] == 1)
		{
			$status = $default_query['status'];
			$status_op = $default_query['status_op'];
		}
		else
		{
			$status = 0;
			$status_op = 0;
		}
			
		if ($wats_settings['ticket_product_key_enabled'] == 1)
			$product = $default_query['product'];
		else
			$product = 0;
			
		if (($wats_settings['visibility'] == 0) || ($wats_settings['visibility'] == 1 && is_user_logged_in()) || ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only')))))
		{
			if ($default_query['author'] == 1 && is_user_logged_in())
				$author = $current_user->user_login;
			else
				$author = 0;
			
			if ($wats_settings['ticket_assign'] != 0)
			{
				if ($default_query['owner'] == '2' && is_user_logged_in())
					$owner = $current_user->user_login;
				else if ($default_query['owner'] == '1')
					$owner = 1;
				else
					$owner = 0;
			}
			else
				$owner = 0;
		}
		else if ($wats_settings['visibility'] == 2 && !current_user_can('administrator') && $wats_settings['ticket_visibility_same_company'] == 1)
		{
			if ($default_query['author'] == 1 && is_user_logged_in())
				$author = $current_user->user_login;
			else
				$author = 0;
			$owner = 0;
		}
		else
		{
			$author = 0;
			$owner = 0;
		}
		
		$output = wats_list_tickets($args[1],$catlist,0,$type,$priority,$status,$product,$owner,$author,0,$status_op,0,1,0,$idnumber,$query);
	}
	
	return ($output);
}

/**************************************************************/
/*                                                            */
/* Fonction d'affichage des filtres pour la liste des tickets */
/*                                                            */
/**************************************************************/

function wats_list_tickets_filters($idquery)
{
	global $wats_settings, $current_user;
	
	$wats_ticket_priority = isset($wats_settings['wats_priorities']) ? $wats_settings['wats_priorities'] : 0;
	$wats_ticket_type = isset($wats_settings['wats_types']) ? $wats_settings['wats_types'] : 0;
	$wats_ticket_status = isset($wats_settings['wats_statuses']) ? $wats_settings['wats_statuses'] : 0;
	$wats_ticket_product = isset($wats_settings['wats_products']) ? apply_filters('wats_product_list_filter',$wats_settings['wats_products']) : 0;
	
	$wats_default_ticket_listing_default_query = $wats_settings['wats_default_ticket_listing_default_query'];
	
	$result = array('authenticated' => 0, 'authentication_form' => '', 'form_start' => '', 'filters' => '', 'ticket_list' => '', 'form_end' => '');
	$output = '</p>';
	
	if (!is_user_logged_in() && $wats_settings['visibility'] != 0)
	{
		$result['authenticated'] = 0;
		$output .= __('Please authenticate yourself to view the tickets in the ticket list.','WATS').'<br /><br />';
		$output .= '<form action="'.site_url().'/wp-login.php" method="post">';
		$output .= '<table class="wats_submit_form_login_table"><tbody>';
		$output .= '<tr><td>'.__('User','WATS').'</td><td><input type="text" class="input" name="log" id="log" style="width:12em;" /></td></tr>';
		$output .= '<tr><td>'.__('Password','WATS').'</td><td><input type="password" class="input" name="pwd" id="pwd" style="width:12em;" /></td></tr>';
		$output .= '<tr><td><input type="submit" name="submit" value="'.__('Log In').'" class="button" /></td>';
		$output .= '<td><input name="rememberme" id="rememberme" type="checkbox" value="forever" /> '.__('Remember Me').'</td></tr></tbody></table>';
		$output .= '<input type="hidden" name="redirect_to" value="'.$_SERVER['REQUEST_URI'].'"/>';
		$output .= '</form><br />';
		$output = apply_filters('wats_filter_frontend_ticket_list_login_form',$output);
		$result['authentication_form'] = $output;
		$output = '';
	}
	
	if (is_user_logged_in() || $wats_settings['visibility'] == 0 || $wats_settings['display_list_not_authenticated'] == 1)
	{	
		$result['authenticated'] = 1;
		$result['form_start'] = $output.'<form id="wats_frontend_ticket_listing_form" action="" method="post">'."\n";
		$result['form_start'] .= wp_nonce_field('filter-wats-tickets-list','_wpnonce_ticket_list',true,false)."\n";
		$result['form_start'] .= '<div id="wats_frontend_ticket_listing_div">';
		$output = '<div id="wats_frontend_ticket_listing_filters_div">';
		
		$output .= '<div id="wats_ticket_number_tl">'."\n";
		$output .= __('Ticket number','WATS').' : '."\n";
		$output .= '<input type="text" id="wats_input_ticket_number_tl" name="wats_input_ticket_number_tl" value="" /><br />'."\n";
		$output .= '</div>'."\n";
				
		if ($wats_settings['ticket_type_key_enabled'] == 1)
		{
			$output .= '<div id="wats_ticket_type_tl">'."\n";
			$output .= __('Ticket type','WATS').' : '."\n";
			$output .= '<select name="wats_select_ticket_type_tl" id="wats_select_ticket_type_tl" class="wats_select">'."\n";
			$output .= '<option value="0"';
			if ($wats_default_ticket_listing_default_query['type'] == 0)
				$output .= ' selected ';
			$output .= '>'.esc_html__('Any','WATS').'</option>'."\n";
			if (is_array($wats_ticket_type))
			foreach ($wats_ticket_type as $key => $value)
			{	
				$output .= '<option value="'.$key.'"';
				if ($wats_default_ticket_listing_default_query['type'] == $key)
					$output .= ' selected ';	
				$output .= '>'.esc_html__($value,'WATS').'</option>'."\n";
			}
			$output .= '</select></div>'."\n";
		}
		
		if ($wats_settings['ticket_priority_key_enabled'] == 1)
		{
			$output .= '<div id="wats_ticket_priority_tl">'."\n";
			$output .= __('Ticket priority','WATS').' : '."\n";
			$output .= '<select name="wats_select_ticket_priority_tl" id="wats_select_ticket_priority_tl" class="wats_select">'."\n";
			$output .= '<option value="0"';
			if ($wats_default_ticket_listing_default_query['priority'] == 0)
				$output .= ' selected ';
			$output .= '>'.esc_html__('Any','WATS').'</option>'."\n";
			if (is_array($wats_ticket_priority))
			foreach ($wats_ticket_priority as $key => $value)
			{	
				$output .= '<option value="'.$key.'"';
				if ($wats_default_ticket_listing_default_query['priority'] == $key)
					$output .= ' selected ';	
				$output .= '>'.esc_html__($value,'WATS').'</option>'."\n";
			}
			$output .= '</select></div>'."\n";
		}
	
		if ($wats_settings['ticket_status_key_enabled'] == 1)
		{
			$output .= '<div id="wats_ticket_status_tl">'."\n";
			$output .=  __('Ticket status','WATS').' '."\n";
			$output .= '<select name="wats_select_ticket_status_operator" id="wats_select_ticket_status_operator" class="wats_select">'."\n";
			$output .= '<option value="0"';
			if ($wats_default_ticket_listing_default_query['status_op'] == 0)
				$output .= ' selected ';
			$output .= '>==</option>'."\n";
			$output .= '<option value="1"';
			if ($wats_default_ticket_listing_default_query['status_op'] == 1)
				$output .= ' selected ';
			$output .= '>!=</option>'."\n";
			$output .= '</select> '."\n";
			$output .= '<select name="wats_select_ticket_status_tl" id="wats_select_ticket_status_tl" class="wats_select">'."\n";
			$output .= '<option value="0"';
			if ($wats_default_ticket_listing_default_query['status'] == 0)
				$output .= ' selected ';
			$output .= '>'.esc_html__('Any','WATS').'</option>'."\n";
			if (is_array($wats_ticket_status))
			foreach ($wats_ticket_status as $key => $value)
			{	
				$output .= '<option value="'.$key.'"';
				if ($wats_default_ticket_listing_default_query['status'] == $key)
					$output .= ' selected ';	
				$output .= '>'.esc_html__($value,'WATS').'</option>'."\n";
			}
			$output .= '</select></div>'."\n";
		}
		
		if ($wats_settings['ticket_product_key_enabled'] == 1)
		{
			$output .= '<div id="wats_ticket_product_tl">'."\n";
			$output .= __('Ticket product','WATS').' : '."\n";
			$output .= '<select name="wats_select_ticket_product_tl" id="wats_select_ticket_product_tl" class="wats_select">'."\n";
			$output .= '<option value="0"';
			if ($wats_default_ticket_listing_default_query['product'] == 0)
				$output .= ' selected ';
			$output .= '>'.esc_html__('Any','WATS').'</option>'."\n";
			if (is_array($wats_ticket_product))
			foreach ($wats_ticket_product as $key => $value)
			{	
				$output .= '<option value="'.$key.'"';
				if ($wats_default_ticket_listing_default_query['product'] == $key)
					$output .= ' selected ';	
				$output .= '>'.esc_html__($value,'WATS').'</option>'."\n";
			}
			$output .= '</select></div>'."\n";
		}
		
		$wats_ticket_custom_field_values = (isset($wats_settings['wats_ticket_custom_fields'])) ? $wats_settings['wats_ticket_custom_fields'] : 0;
		if (is_array($wats_ticket_custom_field_values))
		foreach ($wats_ticket_custom_field_values as $key => $table)
		{
			if ($table['ftlf'] == 1 || ($table['ftlf'] == 2 && current_user_can('administrator')))
			{
				if (isset($table['type']) && $table['type'] == 1)
				{
					$code = '<select name="wats_select_cf_'.$table['meta_key'].'" id="wats_select_cf_'.$table['meta_key'].'" size="1" >'."\n";
					$values = $table['values'];
					$code .= '<option value="0" selected>'.__('Any','WATS').'</option>'."\n";
					foreach ($values as $key2 => $value)
					{
						$code .= '<option value="'.$key2.'"';
						/*if ($table['default_value'] == $key2)
							$code .= ' selected';*/
						$code .= '>'.esc_html($value).'</option>'."\n";
					}
					$code .= '</select>'."\n";
				}
				else if (isset($table['type']) && $table['type'] == 2)
					$code = '<input type="text" name="wats_cf_datepicker_'.$table['meta_key'].'" id="wats_cf_datepicker_'.$table['meta_key'].'" value="" />'."\n";
				else
					$code = '<input type="text" name="wats_cf_'.$table['meta_key'].'" id="wats_cf_'.$table['meta_key'].'" value="" />'."\n";
				$output .= '<div class="wats_frontend_ticket_custom_field">'."\n";
				$output .= esc_html($table['name']).' : '.$code.'</div>'."\n";
			}
		}
		
		if (($wats_settings['visibility'] == 0) || ($wats_settings['visibility'] == 1 && is_user_logged_in()) || ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || (!current_user_can('administrator') && $wats_settings['ticket_visibility_same_company'] == 1) || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only')))))
		{
			$display_author_ac = 0;
			if ($wats_settings['visibility'] == 2 && !current_user_can('administrator') && $wats_settings['ticket_visibility_same_company'] == 1)
			{
				$my_company = get_user_meta($current_user->ID,$wats_settings['company_meta_key_profile'],true);
				if (strlen($my_company) > 0)
					$userlist = wats_build_user_list_from_company(__('Any','WATS'),0,$my_company);
				else
					$userlist = array();
			}
			else
			{
				if (!isset($wats_settings['drop_down_user_selector_format']) || $wats_settings['drop_down_user_selector_format'] == 0)
					$userlist = wats_build_user_list(__('Any','WATS'),0);
				else
				{
					$userlist = array();
					$display_author_ac = 1;
				}
			}

			if (sizeof($userlist) > 2)
			{
				$output .= '<div id="wats_ticket_author_tl">'."\n";
				$output .= __('Ticket author','WATS').' : '."\n";
				$output .= '<select name="wats_select_ticket_author_tl" id="wats_select_ticket_author_tl" class="wats_select">'."\n";
				foreach ($userlist AS $userlogin => $username)
				{
					$output .= '<option value="'.esc_attr($userlogin).'"';
					if (($wats_default_ticket_listing_default_query['author'] == '0' && $userlogin == '0') || ($wats_default_ticket_listing_default_query['author'] == '1' && $userlogin == $current_user->user_login))
						$output .= ' selected ';
					$output .= '>'.esc_html($username).'</option>'."\n";
				}
				$output .= '</select></div>'."\n";
			}
			else if (isset($wats_settings['drop_down_user_selector_format']) && $wats_settings['drop_down_user_selector_format'] == 1 && $display_author_ac == 1)
			{
				$output .= '<div id="wats_ticket_author_tl">'."\n";
				$output .= __('Ticket author','WATS').' : '."\n";
				
				if ($wats_default_ticket_listing_default_query['author'] == '1')
				{
					$default_author = wats_build_formatted_name($current_user->ID);
					$default_author  = $default_author[$current_user->user_login];
					$default_author_value = esc_html($current_user->user_login);
				}
				else
				{
					$default_author = __('Any','WATS');
					$default_author_value = 0;
				}
				
				$output .= '<input type="text" id="wats_select_ticket_author_tl_ac" name="wats_select_ticket_author_tl_ac" value="'.$default_author.'" /><br />'."\n";
				$output .= '<input type="hidden" id="wats_select_ticket_author_tl" name="wats_select_ticket_author_tl" value="'.$default_author_value.'" />'."\n";
				$output .= '</div>'."\n";
			}
		
			if ((current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))) && $wats_settings['filter_ticket_listing'] == 1)
			{
				$output .= '<div id="wats_ticket_author_meta_tl">'."\n";
				$output .= __('Ticket author','WATS').' ('.$wats_settings['filter_ticket_listing_meta_key'].') : ';
				$metakeyvalues = wats_build_list_meta_values($wats_settings['filter_ticket_listing_meta_key']);
				$output .= '<select name="wats_select_ticket_author_meta_value_tl" id="wats_select_ticket_author_meta_value_tl" class="wats_select">'."\n";
				$output .= '<option value="0">'.__('Any','WATS').'</option>'."\n";
				foreach ($metakeyvalues AS $value)
				{
					$output .= '<option value="'.esc_attr($value).'">'.esc_html($value).'</option>'."\n";
				}
				$output .= '</select></div>'."\n";
			}
		
			if ($wats_settings['ticket_assign'] != 0 && (($wats_settings['visibility'] == 0) || ($wats_settings['visibility'] == 1 && is_user_logged_in()) || ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))))))
			{
				$output .= '<div id="wats_ticket_owner_tl">'."\n";
				$output .= __('Ticket owner','WATS').' : '."\n";
				if (!isset($wats_settings['drop_down_user_selector_format']) || $wats_settings['drop_down_user_selector_format'] == 0)
				{
					$userlist = wats_build_user_list(0,0);
					$output .= '<select name="wats_select_ticket_owner_tl" id="wats_select_ticket_owner_tl" class="wats_select">'."\n";
					$output .= '<option value="0"';
					if ($wats_default_ticket_listing_default_query['owner'] == 0)
						$output .= ' selected ';
					$output .= '>'.esc_html__('Any','WATS').'</option>'."\n";
					$output .= '<option value="1"';
					if ($wats_default_ticket_listing_default_query['owner'] == 1)
						$output .= ' selected ';
					$output .= '>'.esc_html__('None','WATS').'</option>'."\n";
					foreach ($userlist AS $userlogin => $username)
					{
						$output .= '<option value="'.esc_attr($userlogin).'"';
						if ($wats_default_ticket_listing_default_query['owner'] == '2' && $userlogin == $current_user->user_login)
							$output .= ' selected ';
						$output .= '>'.esc_html($username).'</option>'."\n";
					}
					$output .= '</select></div>'."\n";
				}
				else
				{
					if ($wats_default_ticket_listing_default_query['owner'] == 1)
					{
						$default_owner = __('None','WATS');
						$default_owner_value = 1;
					}
					else if ($wats_default_ticket_listing_default_query['owner'] == '2')
					{
						$default_owner = wats_build_formatted_name($current_user->ID);
						$default_owner  = $default_owner[$current_user->user_login];
						$default_owner_value = esc_html($current_user->user_login);
					}
					else
					{
						$default_owner = __('Any','WATS');
						$default_owner_value = 0;
					}
					
					$output .= '<input type="text" id="wats_select_ticket_owner_tl_ac" name="wats_select_ticket_owner_tl_ac" value="'.$default_owner.'" /><br />'."\n";
					$output .= '<input type="hidden" id="wats_select_ticket_owner_tl" name="wats_select_ticket_owner_tl" value="'.$default_owner_value.'" /><br /></div>'."\n";
				}
			}
		}
		
		$wats_ticket_listing_queries = (isset($wats_settings['wats_ticket_listing_queries'])) ? $wats_settings['wats_ticket_listing_queries'] : array();
		if (count($wats_ticket_listing_queries) > 0)
		{
			$output .= '<div id="wats_custom_query_tl">'."\n";
			$output .= __('Custom query','WATS').' : '."\n";
			$output .= '<select name="wats_select_custom_query_tl" id="wats_select_custom_query_tl" class="wats_select">'."\n";
			$output .= '<option value="-1"';
			if ($idquery == -1)
				$output .= ' selected';
			$output .= '></option>'."\n";
			foreach ($wats_ticket_listing_queries as $key => $table)
			{	
				$output .= '<option value="'.$key.'"';
				if ($idquery == $key)
					$output .= ' selected';
				$output .= '>'.esc_html($table['name']).'</option>'."\n";
			}
			$output .= '</select></div>'."\n";
		}
		
		$output .= '<div class="wats_submit_tl">'."\n";
		$output .= '<input class="button-primary" type="submit" id="filter" name="filter" value="'.__('Filter','WATS').'" />  ';
		$output .= '<input class="button-primary" type="submit" id="wats_export" name="wats_export" value="'.__('Export','WATS').'" />'."\n";
		$output .= '</div></div>'."\n";
		
		$result['filters'] = $output;
	}
	
	return($result);
}

/*********************************************************************/
/*                                                                   */
/* Fonction Ajax de chargement d'une ligne dans la liste des tickets */
/*                                                                   */
/*********************************************************************/

function wats_ticket_list_get_ticket_row()
{
	global $wats_settings,$wpdb;
	
	wats_load_settings();
	
	if (!current_user_can('administrator'))
		die('-1');
		
	check_ajax_referer('filter-wats-tickets-list');
	
	$idvalue = stripslashes_deep($_POST['idvalue']);
	
	if (get_post_type($idvalue) != 'ticket')
	{
		$message_result = array('success' => "FALSE", 'error' => __("Error : please select a valid ticket to modify!",'WATS'));
	}
	else
	{
		$wats_default_ticket_listing_active_columns = $wats_settings['wats_default_ticket_listing_active_columns'];
		$ticket = get_post($idvalue);
		
		$output = wats_ticket_list_get_row(3, $ticket, '<td>', '</td>',-1);
		
		$message_result = array('success' => "TRUE", 'output' => $output);
	}

	echo json_encode($message_result);
	exit;
}

/**********************************************************************/
/*                                                                    */
/* Fonction Ajax de mise � jour d'une ligne dans la liste des tickets */
/*                                                                    */
/**********************************************************************/

function wats_ticket_list_update_ticket_row()
{
	global $wats_settings,$wpdb;
	
	wats_load_settings();
	
	if (!current_user_can('administrator'))
		die('-1');
		
	check_ajax_referer('filter-wats-tickets-list');
	
	$postID = stripslashes_deep($_POST['idvalue']);
	$idtype = (isset($_POST['idtype']) && wats_is_numeric($_POST['idtype'])) ? intval(stripslashes_deep($_POST['idtype'])) : -1;
	$idpriority = (isset($_POST['idpriority']) && wats_is_numeric($_POST['idpriority'])) ? intval(stripslashes_deep($_POST['idpriority'])) : -1;
	$idstatus = (isset($_POST['idstatus']) && wats_is_numeric($_POST['idstatus'])) ? intval(stripslashes_deep($_POST['idstatus'])) : -1;
	$idproduct = (isset($_POST['idproduct']) && wats_is_numeric($_POST['idproduct'])) ? intval(stripslashes_deep($_POST['idproduct'])) : -1;
		
	if (get_post_type($postID) != 'ticket')
	{
		$message_result = array('success' => "FALSE", 'error' => __("Error : please select a valid ticket to modify!",'WATS'));
	}
	else
	{
		$newstatus = -1;
		if ($wats_settings['ticket_status_key_enabled'] == 1 && $idstatus > 0)
		{
			$status = get_post_meta($postID,'wats_ticket_status',true);
			
			if ($status != $idstatus)
			{
				update_post_meta($postID,'wats_ticket_status',$idstatus);
				$newstatus = $idstatus;
			}

			if ($status == wats_get_closed_status_id() && $newstatus != wats_get_closed_status_id())
				delete_post_meta($postID,'wats_ticket_closure_date');
			
			if ($newstatus == wats_get_closed_status_id())
				update_post_meta($postID,'wats_ticket_closure_date',current_time('mysql'));
		}
		
		$newtype = -1;
		if ($wats_settings['ticket_type_key_enabled'] == 1 && $idtype > 0)
		{
			$type = get_post_meta($postID,'wats_ticket_type',true);
			
			if ($type != $idtype)
			{
				update_post_meta($postID,'wats_ticket_type',$idtype);
				$newtype = $idtype;
			}
		}
		
		$newpriority = -1;
		if ($wats_settings['ticket_priority_key_enabled'] == 1 && $idpriority > 0)
		{
			$priority = get_post_meta($postID,'wats_ticket_priority',true);
			
			if ($priority != $idpriority)
			{
				update_post_meta($postID,'wats_ticket_priority',$idpriority);
				$newpriority = $idpriority;
			}
		}
		
		$newproduct = -1;
		if ($wats_settings['ticket_product_key_enabled'] == 1 && $idproduct > 0)
		{
			$product = get_post_meta($postID,'wats_ticket_product',true);
			
			if ($product != $idproduct)
			{
				update_post_meta($postID,'wats_ticket_product',$idproduct);
				$newproduct = $idproduct;
			}
		}
		
		$ticket = get_post($postID);
		
		$output = wats_ticket_list_get_row(4, $ticket, '<td>', '</td>', -1);
		
		wats_fire_ticket_update_notification($postID,$newstatus,$newtype,$newpriority,$newproduct,-1,'');
		
		$message_result = array('success' => "TRUE", 'output' => $output);
	}

	echo json_encode($message_result);
	exit;
}

/***************************************************/
/*                                                 */
/* Fonction de r�cup�ration de l'extrait d'un post */
/*                                                 */
/***************************************************/

function wats_get_the_excerpt($postID)
{
	global $post;  
  
	$temp_post = $post;
	$post = get_post($postID);
	setup_postdata($post);
	$output = get_the_excerpt();
	wp_reset_postdata();
	$post = $temp_post;
		
	return $output;
}

/********************************************************/
/*                                                      */
/* Fonction d'une ligne dans la table des tickets       */
/* View 0 : chargement HTML direct                      */
/* View 1 : chargement Ajax                             */
/* View 2 : rapport XML			                        */
/* View 3 : �dition Ajax   	                            */
/* View 4 : chargement Ajax pour �dition                */
/*                                                      */
/********************************************************/

function wats_ticket_list_get_row($view, $ticket, $starttag, $endtag, $colspan)
{
	global $wats_settings,$wpdb;

	$output = '';
	$wats_default_ticket_listing_active_columns = $wats_settings['wats_default_ticket_listing_active_columns'];
	$wats_ticket_custom_field_values = (isset($wats_settings['wats_ticket_custom_fields'])) ? $wats_settings['wats_ticket_custom_fields'] : 0;
	
	if ($wats_default_ticket_listing_active_columns['id'] == 1)
	{
		if (($wats_settings['numerotation'] == 1) || ($wats_settings['numerotation'] == 2))
			$output .= $starttag.wats_get_ticket_number($ticket->ID).$endtag;
	}
	
	if ($wats_default_ticket_listing_active_columns['title'] == 1)
	{
		$title = get_the_title($ticket->ID);
		$title = (strlen(esc_html($title)) > 0) ? esc_html($title) : __('Blank','WATS');
		if ($view != 2)
			$output .= $starttag.'<a href="'.get_post_permalink($ticket->ID).'">'.$title.'</a>'.$endtag;
		else
			$output .=  '<Cell ss:StyleID="s53" ss:HRef="'.get_post_permalink($ticket->ID).'"><Data ss:Type="String">'.$title.$endtag;
	}

	if ($wats_default_ticket_listing_active_columns['category'] == 1)
	{
		$categories = get_the_category($ticket->ID);
		if (!empty($categories))
		{
			$out = array();
			foreach ($categories as $c)
			{
				$out[] = esc_html(sanitize_term_field('name', $c->name, $c->term_id, 'category', 'display'));
	
			}
			$output .= $starttag.join(', ',$out).$endtag;
		} 
		else
		{
			$output .= $starttag.__('Uncategorized','WATS').$endtag;
		}
	}
	
	if ($wats_default_ticket_listing_active_columns['author'] == 1)
	{
		if (strlen(get_post_meta($ticket->ID,'wats_ticket_author_name',true)))
			$output .= $starttag.get_post_meta($ticket->ID,'wats_ticket_author_name',true).$endtag;
		else if (function_exists('get_the_author_meta'))
			$output .= $starttag.get_the_author_meta('nickname',$ticket->post_author).$endtag;
		else
			$output .= $starttag.get_the_author($ticket->post_author).$endtag;
	}
		
	if ($wats_settings['meta_column_ticket_listing'] == 1 && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))))
	{
		if ($wats_settings['meta_column_ticket_listing_meta_key'] == "user_email")
			$output .= $starttag.esc_html(get_the_author_meta('user_email',$ticket->post_author)).$endtag;
		else
			$output .= $starttag.esc_html(get_user_meta($ticket->post_author,$wats_settings['meta_column_ticket_listing_meta_key'],true)).$endtag;
	}

	if ($wats_default_ticket_listing_active_columns['owner'] == 1)
	{
		if ($wats_settings['ticket_assign'] != 0)
		{
			$ticket_owner = get_post_meta($ticket->ID,'wats_ticket_owner',true);
			if (strlen($ticket_owner) > 0)
			{
				$ticket_owner = get_user_by('login', $ticket_owner);
				if (isset($ticket_owner->ID))
				{
					if (function_exists('get_the_author_meta'))
						$output .= $starttag.get_the_author_meta('nickname',$ticket_owner->ID).$endtag;
					else
						$output .= $starttag.get_the_author($ticket_owner->ID).$endtag;
				}
				else
					$output .= $starttag.__('None','WATS').$endtag;
			}
			else
				$output .= $starttag.__('None','WATS').$endtag;
		}
	}
	
	if ($wats_default_ticket_listing_active_columns['creation_date'] == 1)
	{
		if ($view != 2)
			$output .= $starttag.get_post_time('M d, Y',false,$ticket,false).$endtag;
		else
			$output .= '<Cell ss:StyleID="s54"><Data ss:Type="String">'.get_post_time('M d, Y',false,$ticket,false).$endtag;
	}
	
	if ($wats_default_ticket_listing_active_columns['modification_date'] == 1)
	{
		$comments = $wpdb->get_row($wpdb->prepare("SELECT comment_ID, comment_date FROM $wpdb->comments WHERE comment_post_ID = %d ORDER BY comment_date DESC LIMIT 1",$ticket->ID));
		if (!is_object($comments))
			$date = 0;
		else
			$date = $comments->comment_date;
		
		if (strtotime($ticket->post_modified) > strtotime($date))
			$last_modification_date = mysql2date('M d, Y',$ticket->post_modified,false);
		else
			$last_modification_date = mysql2date('M d, Y',$comments->comment_date,false);
		if ($view != 2)
			$output .= $starttag.$last_modification_date.$endtag;
		else
			$output .= '<Cell ss:StyleID="s54"><Data ss:Type="String">'.$last_modification_date.$endtag;
	}
	
	if ($wats_default_ticket_listing_active_columns['last_updater'] == 1)
	{
		if (!is_object($comments))
			$comments = $wpdb->get_row($wpdb->prepare("SELECT comment_ID, comment_date FROM $wpdb->comments WHERE comment_post_ID = %d ORDER BY comment_date DESC LIMIT 1",$ticket->ID));
		
		if (!is_object($comments))
		{
			if (function_exists('get_the_author_meta'))
				$output .= $starttag.get_the_author_meta('nickname',$ticket->post_author).$endtag;
			else
				$output .= $starttag.get_the_author($ticket->post_author).$endtag;
		}
		else
		{
			$output .= $starttag.get_comment_author($comments->comment_ID).$endtag;
		}
	}
	
	if ($wats_default_ticket_listing_active_columns['ticket_age'] == 1)
	{
		$age = wats_ticket_get_age($ticket);
		$output .= $starttag;
		if ($age['days'] > 1)
			$output .= $age['days'].' '.__('days','WATS');
		else
			$output .= $age['days'].' '.__('day','WATS');
		$output .= ' '.$age['hours'].' '.__('h','WATS');
		$output .= ' '.$age['minutes'].' '.__('m','WATS');
						
		$output .= $endtag;
	}
	
	if ($wats_default_ticket_listing_active_columns['closure_date'] == 1)
	{
		if ($view != 2)
			$output .= $starttag.wats_ticket_get_closure_date($ticket).$endtag;
		else
			$output .= '<Cell ss:StyleID="s54"><Data ss:Type="String">'.wats_ticket_get_closure_date($ticket).$endtag;
	}
		
	if ($wats_default_ticket_listing_active_columns['type'] == 1 && $wats_settings['ticket_type_key_enabled'] == 1)
	{
		if ($view != 3)
			$output .= $starttag.wats_ticket_get_type($ticket).$endtag;
		else if ($view == 3)
		{
			$wats_ticket_type = isset($wats_settings['wats_types']) ? $wats_settings['wats_types'] : 0;
			$ticket_type = get_post_meta($ticket->ID,'wats_ticket_type',true);
			$output .= '<td><select name="wats_select_ticket_type_'.$ticket->ID.'" id="wats_select_ticket_type_'.$ticket->ID.'" class="wats_select">';
			if (is_array($wats_ticket_type))
			foreach ($wats_ticket_type as $key => $value)
			{
				$output .= '<option value='.$key;
				if ($key == $ticket_type || (!$ticket_type && $key == $wats_settings['default_ticket_type']))
					$output .= ' selected';
				$output .= '>'.esc_html__($value,'WATS').'</option>';
			}
			$output .= '</select></td>';
		}
	}
	
	if ($wats_default_ticket_listing_active_columns['priority'] == 1 && $wats_settings['ticket_priority_key_enabled'] == 1)
	{
		if ($view != 3)
		{
			if ($view == 2)
				$output .= $starttag.wats_ticket_get_priority($ticket).$endtag;
			else
			{
				$priority_id = get_post_meta($ticket->ID,'wats_ticket_priority',true);
				if (wats_is_numeric($priority_id))
					$output .= $starttag.'<span class="wats_table_label wats_span_priority_'.$priority_id.'">'.wats_ticket_get_priority($ticket).'</span>'.$endtag;
				else
					$output .= $starttag.wats_ticket_get_priority($ticket).$endtag;
			}
		}
		else if ($view == 3)
		{
			$wats_ticket_priority = isset($wats_settings['wats_priorities']) ? $wats_settings['wats_priorities'] : 0;
			$ticket_priority = get_post_meta($ticket->ID,'wats_ticket_priority',true);
			$output .= '<td><select name="wats_select_ticket_priority_'.$ticket->ID.'" id="wats_select_ticket_priority_'.$ticket->ID.'" class="wats_select">';
			if (is_array($wats_ticket_priority))
			foreach ($wats_ticket_priority as $key => $value)
			{
				$output .= '<option value='.$key;
				if ($key == $ticket_priority || (!$ticket_priority && $key == $wats_settings['default_ticket_priority']))
					$output .= ' selected';
				$output .= '>'.esc_html__($value,'WATS').'</option>';
			}
			$output .= '</select></td>';
		}
	}
	
	if ($wats_default_ticket_listing_active_columns['status'] == 1 && $wats_settings['ticket_status_key_enabled'] == 1)
	{
		if ($view != 3)
			$output .= $starttag.wats_ticket_get_status($ticket).$endtag;
		else if ($view == 3)
		{
			$wats_ticket_status = isset($wats_settings['wats_statuses']) ? $wats_settings['wats_statuses'] : 0;
			$ticket_status = get_post_meta($ticket->ID,'wats_ticket_status',true);
			$output .= '<td><select name="wats_select_ticket_status_'.$ticket->ID.'" id="wats_select_ticket_status_'.$ticket->ID.'" class="wats_select">';
			if (is_array($wats_ticket_status))
			foreach ($wats_ticket_status as $key => $value)
			{
				$output .= '<option value='.$key;
				if ($key == $ticket_status || (!$ticket_status && $key == $wats_settings['default_ticket_status']))
					$output .= ' selected';
				$output .= '>'.esc_html__($value,'WATS').'</option>';
			}
			$output .= '</select></td>';
		}
	}
		
	if ($wats_default_ticket_listing_active_columns['product'] == 1 && $wats_settings['ticket_product_key_enabled'] == 1)
	{
		if ($view != 3)
			$output .= $starttag.wats_ticket_get_product($ticket).$endtag;
		else if ($view == 3)
		{
			$wats_ticket_product = isset($wats_settings['wats_products']) ? apply_filters('wats_product_list_filter',$wats_settings['wats_products']) : 0;
			$ticket_product = get_post_meta($ticket->ID,'wats_ticket_product',true);
			$output .= '<td><select name="wats_select_ticket_product_'.$ticket->ID.'" id="wats_select_ticket_product_'.$ticket->ID.'" class="wats_select">';
			if (is_array($wats_ticket_product))
			foreach ($wats_ticket_product as $key => $value)
			{
				$output .= '<option value='.$key;
				if ($key == $ticket_product || (!$ticket_product && $key == $wats_settings['default_ticket_product']))
					$output .= ' selected';
				$output .= '>'.esc_html__($value,'WATS').'</option>';
			}
			$output .= '</select></td>';
		}
	}
		
	if (is_array($wats_ticket_custom_field_values))
	foreach ($wats_ticket_custom_field_values as $key => $table)
	{
		if ($table['ftltc'] == 1 || ($table['ftltc'] == 2 && current_user_can('administrator')))
		{
			if (isset($table['type']) && $table['type'] == 1)
			{
				$values = $table['values'];
				$current_value = get_post_meta($ticket->ID,$table['meta_key'],true);
				if (isset($values[$current_value]))
					$code = esc_html($values[$current_value]);
				else
					$code = '';
			}
			else if (isset($table['type']) && $table['type'] == 2)
			{
				$code = mysql2date('M d, Y',esc_html(get_post_meta($ticket->ID,$table['meta_key'],true)),false);
			}
			else
				$code = esc_html(get_post_meta($ticket->ID,$table['meta_key'],true));
			$output .= $starttag.$code.$endtag;
		}
	}
	
	if (isset($wats_default_ticket_listing_active_columns['edit']) && $wats_default_ticket_listing_active_columns['edit'] == 1 && $view != 2 && $view != 3 && current_user_can('administrator'))
	{
		$output .= $starttag.'<input class="button-primary" type="submit" id="wats_edit_ticket_row_'.$ticket->ID.'" name="wats_edit_ticket_row_'.$ticket->ID.'" value="'.__('Edit','WATS').'" />'.$endtag;
	}
	else if (isset($wats_default_ticket_listing_active_columns['edit']) && $wats_default_ticket_listing_active_columns['edit'] == 1 && $view == 3 && current_user_can('administrator'))
	{
		$output .= '<td>'.'<input class="button-primary" type="submit" id="wats_save_ticket_row_'.$ticket->ID.'" name="wats_save_ticket_row_'.$ticket->ID.'" value="'.__('Save','WATS').'" /></td>';
	}
	
	if (isset($wats_default_ticket_listing_active_columns['description']) && $wats_default_ticket_listing_active_columns['description'] == 1)
	{
		if ($view == 3 || $view == 4)
			$output .= '<td>'.'<input class="button-primary" type="submit" id="wats_expand_ticket_row_'.$ticket->ID.'" name="wats_expand_ticket_row_'.$ticket->ID.'" value="'.__('Expand','WATS').'" /></td>';
		else if ($view != 2)
			$output .= '<td>'.'<input class="button-primary" type="submit" id="wats_expand_ticket_row_'.$ticket->ID.'" name="wats_expand_ticket_row_'.$ticket->ID.'" value="'.__('Expand','WATS').'" /></td></tr><tr id="wats_tr_expanded_'.$ticket->ID.'" style="display:none;"><td colspan="'.$colspan.'">'.wats_get_the_excerpt($ticket->ID).'</td>';
		else
		{
			$freespan = $colspan - 1;
			$output .= '</Row><Row ss:AutoFitHeight="0" ss:Height="38.25">'."\n".'<Cell ss:MergeAcross="'.$freespan.'" ss:StyleID="s52"><Data ss:Type="String">'."\n".wats_get_the_excerpt($ticket->ID).$endtag;
		}
	}
	
	return $output;
}

/********************************************************/
/*                                                      */
/* Fonction d'affichage du listing des tickets          */
/* Argument 1 : filtre cat�gorie (0 : all, 1 : current) */
/* View 0 : chargement HTML direct                      */
/* View 1 : chargement Ajax                             */
/* View 2 : rapport XML			                        */
/*                                                      */
/********************************************************/

function wats_list_tickets($filtercategory, $catlist, $view, $idtype, $idpriority, $idstatus, $idproduct, $idowner, $idauthor, $idauthormetavalue, $idstatusop, $listecf, $selected_page, $tickets_per_page, $idnumber, $idquery)
{
	global $wpdb, $wats_settings, $current_user, $wats_default_ticket_listing_columns;

	wats_load_settings();

	$joinoptions = 0;
	$leftjoin = "";
	$where = "";
	if ($view == 0 || $view == 1 || $view == 2)
	{
	
		if ($idtype > 0 && $wats_settings['ticket_type_key_enabled'] == 1)
		{
			$leftjoin = " LEFT JOIN $wpdb->postmeta AS wp1 ON $wpdb->posts.ID = wp1.post_id ";
			$where = " AND (wp1.meta_key = 'wats_ticket_type' AND wp1.meta_value = '$idtype')";
			$joinoptions = 1;
		}
		
		if ($idpriority > 0 && $wats_settings['ticket_priority_key_enabled'] == 1)
		{
			$leftjoin .= " LEFT JOIN $wpdb->postmeta AS wp2 ON $wpdb->posts.ID = wp2.post_id ";
			$where .= " AND (wp2.meta_key = 'wats_ticket_priority' AND wp2.meta_value = '$idpriority')";
			$joinoptions = 1;
		}
		
		if ($idstatus > 0 && $wats_settings['ticket_status_key_enabled'] == 1)
		{
			if ($idstatusop == 1)
				$idstatusop = '!=';
			else
				$idstatusop = '=';
			$leftjoin .= " LEFT JOIN $wpdb->postmeta AS wp3 ON $wpdb->posts.ID = wp3.post_id ";
			$where .= " AND (wp3.meta_key = 'wats_ticket_status' AND wp3.meta_value ".$idstatusop." '$idstatus')";
			$joinoptions = 1;
		}
		
		if ($idproduct > 0 && $wats_settings['ticket_product_key_enabled'] == 1)
		{
			$leftjoin .= " LEFT JOIN $wpdb->postmeta AS wp6 ON $wpdb->posts.ID = wp6.post_id ";
			$where .= " AND (wp6.meta_key = 'wats_ticket_product' AND wp6.meta_value = '$idproduct')";
			$joinoptions = 1;
		}
		
		if ($idauthor != "0")
		{
			$idauthor = wats_get_user_ID_from_user_login($idauthor);
			$where .= " AND $wpdb->posts.post_author = '$idauthor'";
			$joinoptions = 1;
		}
		
		if ($idowner != "0" && $idowner != "1")
		{
			$leftjoin .= " LEFT JOIN $wpdb->postmeta AS wp4 ON $wpdb->posts.ID = wp4.post_id ";
			$where .= " AND (wp4.meta_key = 'wats_ticket_owner' AND wp4.meta_value = '".esc_sql($idowner)."')";
			$joinoptions = 1;
		}
		else if ($idowner == "1")
		{
			$leftjoin .= " LEFT JOIN $wpdb->postmeta AS wp4 ON $wpdb->posts.ID = wp4.post_id ";
			$where .= " AND ((wp4.meta_key = 'wats_ticket_owner' AND wp4.meta_value = '0') OR NOT EXISTS (SELECT * FROM $wpdb->postmeta AS wp7 WHERE $wpdb->posts.ID = wp7.post_id AND wp7.meta_key = 'wats_ticket_owner'))";
			$joinoptions = 1;
		}
		
		if ($idauthormetavalue != "0")
		{
			$key = $wats_settings['filter_ticket_listing_meta_key'];
			$leftjoin .= " LEFT JOIN $wpdb->usermeta AS wp5 ON $wpdb->posts.post_author = wp5.user_id ";
			$where .= " AND (wp5.meta_key = '$key' AND wp5.meta_value = '".esc_sql($idauthormetavalue)."')";
			$joinoptions = 1;
		}
		
		if ($idnumber !== NULL && strlen($idnumber) > 0)
		{
			$value = esc_sql($wpdb->esc_like($idnumber));
			if (strpos($value,'-'))
			{
				$value = strstr($value,'-');
				$value = ltrim($value,'-');
			}
			$value = ltrim($value,'0');
			$leftjoin .= " LEFT JOIN $wpdb->postmeta AS wp7 ON $wpdb->posts.ID = wp7.post_id ";
			$where .= " AND (wp7.meta_key = 'wats_ticket_number' AND wp7.meta_value LIKE '%%".$value."%%')";
			$joinoptions = 1;
		}
		
		if (is_array($listecf))
		{
			$joinid = 10;

			foreach ($listecf as $key => $value)
			{
				$leftjoin .= " LEFT JOIN $wpdb->postmeta AS wp".$joinid." ON $wpdb->posts.ID = wp".$joinid.".post_id ";
				$where .= " AND (wp".$joinid.".meta_key = '".esc_sql($key)."' AND wp".$joinid.".meta_value = '".esc_sql($value)."')";
				$joinoptions = 1;
				$joinid++;
			}
		}
	}
	$group_by = ' GROUP BY ID';
	$order_by = ' ORDER BY post_date DESC';
	
	if (!wats_is_numeric($selected_page))
		$selected_page = 1;

	if ((!wats_is_numeric($tickets_per_page) && $tickets_per_page != "ALL") || $tickets_per_page === 0)
		$tickets_per_page = 10;

	if ($view != 2 && $tickets_per_page != "ALL")
	{
		$offset = ($selected_page * $tickets_per_page) - $tickets_per_page;
		$limit = ' LIMIT '.$offset.','.$tickets_per_page;
	}
	else $limit = '';

	if (current_user_can('administrator'))
		$post_status = " ($wpdb->posts.post_status = 'publish' OR $wpdb->posts.post_status = 'pending')";
	else
		$post_status = " $wpdb->posts.post_status = 'publish'";

	remove_filter('the_title','wats_title_insert_ticket_number');
		
	if ($filtercategory == 0)
	{
		if ($wats_settings['visibility'] == 0)
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts".$leftjoin." WHERE $wpdb->posts.post_type = %s AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
		else if ($wats_settings['visibility'] == 1 && is_user_logged_in())
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts".$leftjoin." WHERE $wpdb->posts.post_type = %s AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))))
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts".$leftjoin." WHERE $wpdb->posts.post_type = %s AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && $wats_settings['ticket_visibility_same_company'] == 1)
		{
			$liste = "'".implode("','",wats_build_user_array_from_company($current_user->ID))."'";
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts".$leftjoin." WHERE $wpdb->posts.post_type = %s AND $wpdb->posts.post_author IN(".$liste.") AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
		}
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in())
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts".$leftjoin." WHERE $wpdb->posts.post_type = %s AND $wpdb->posts.post_author = $current_user->ID AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
	}
	else if ($filtercategory == 1)
	{
		if ($wats_settings['visibility'] == 0)
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts LEFT JOIN $wpdb->term_relationships ON $wpdb->posts.ID = $wpdb->term_relationships.object_id LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_taxonomy_id = $wpdb->term_relationships.term_taxonomy_id ".$leftjoin." WHERE  $wpdb->posts.post_type = %s AND $wpdb->term_taxonomy.taxonomy = 'category' AND $wpdb->term_taxonomy.term_id IN(".esc_sql($catlist).") AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
		else if ($wats_settings['visibility'] == 1 && is_user_logged_in())
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts LEFT JOIN $wpdb->term_relationships ON $wpdb->posts.ID = $wpdb->term_relationships.object_id LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_taxonomy_id = $wpdb->term_relationships.term_taxonomy_id ".$leftjoin." WHERE  $wpdb->posts.post_type = %s AND $wpdb->term_taxonomy.taxonomy = 'category' AND $wpdb->term_taxonomy.term_id IN(".esc_sql($catlist).") AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))))
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts LEFT JOIN $wpdb->term_relationships ON $wpdb->posts.ID = $wpdb->term_relationships.object_id LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_taxonomy_id = $wpdb->term_relationships.term_taxonomy_id ".$leftjoin." WHERE  $wpdb->posts.post_type = %s AND $wpdb->term_taxonomy.taxonomy = 'category' AND $wpdb->term_taxonomy.term_id IN(".esc_sql($catlist).") AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && $wats_settings['ticket_visibility_same_company'] == 1)
		{
			$liste = "'".implode("','",wats_build_user_array_from_company($current_user->ID))."'";
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts LEFT JOIN $wpdb->term_relationships ON $wpdb->posts.ID = $wpdb->term_relationships.object_id LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_taxonomy_id = $wpdb->term_relationships.term_taxonomy_id ".$leftjoin." WHERE  $wpdb->posts.post_type = %s AND $wpdb->posts.post_author IN(".$liste.") AND $wpdb->term_taxonomy.taxonomy = 'category' AND $wpdb->term_taxonomy.term_id IN(".esc_sql($catlist).") AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
		}
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in())
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS ID, post_title, post_author, post_date, post_modified FROM $wpdb->posts LEFT JOIN $wpdb->term_relationships ON $wpdb->posts.ID = $wpdb->term_relationships.object_id LEFT JOIN $wpdb->term_taxonomy ON $wpdb->term_taxonomy.term_taxonomy_id = $wpdb->term_relationships.term_taxonomy_id ".$leftjoin." WHERE  $wpdb->posts.post_type = %s AND $wpdb->posts.post_author = $current_user->ID AND $wpdb->term_taxonomy.taxonomy = 'category' AND $wpdb->term_taxonomy.term_id IN(".esc_sql($catlist).") AND".$post_status.$where.$group_by.$order_by.$limit,'ticket'));
	}
	
	if (isset($tickets))
	{
		$found_rows = $wpdb->get_var("SELECT FOUND_ROWS()");
		if ($tickets_per_page != "ALL" && $tickets_per_page > 0)
			$numberofpages = ceil($found_rows/$tickets_per_page);
		else
			$numberofpages = 1;
	}
	else
		$numberofpages = 1;
	
	$output = "";
	if ($view == 0)
	{
		$result = wats_list_tickets_filters($idquery);
		
		if (is_user_logged_in() || $wats_settings['visibility'] == 0 || $wats_settings['display_list_not_authenticated'] == 1)
		{
			$output .= '<input class="button-primary" type="hidden" id="categoryfilter" name="categoryfilter" value="'.esc_attr($filtercategory).'" />';
			$output .= '<input class="button-primary" type="hidden" id="categorylistfilter" name="categorylistfilter" value="'.esc_attr($catlist).'" />';
			$output .= '<div id="resultticketlist">';
		}
	}
	
	if (is_user_logged_in() || $wats_settings['visibility'] == 0 || $wats_settings['display_list_not_authenticated'] == 1)
	{
		if ($view != 2)
		{
			$ticketsperpagearray = array("10" => "10","20" => "20","50" => "50","100" => "100","ALL" => __('All','WATS'));
			$ticketsperpageselector = ' <select id="wats_tickets_per_page_list_tl" name="wats_tickets_per_page_list_tl" class="wats_select">'.wats_fill_drop_down_no_echo($ticketsperpagearray,$tickets_per_page).'</select> ';
			$output .= '<div id="wats_tickets_per_page_selector">'.__('Display','WATS').$ticketsperpageselector.__('tickets','WATS').'</div>';
			if ($numberofpages > 1)
			{
				$pagearray = wats_build_numeric_array(1,$numberofpages);
				$pageselector = ' <select id="wats_page_list_tl" name="wats_page_list_tl" class="wats_select">'.wats_fill_drop_down_no_echo($pagearray,$selected_page).'</select> ';
				$output .= '<div id="wats_page_selector">'.__('Page','WATS').$pageselector.__('of','WATS').' '.$numberofpages.'</div><br />';
			}
		}
		
		$colspan = 0;
		
		if ($view != 2)
		{
			$output .= '<table class="wats_table" cellspacing="0" id="tableticket" style="text-align:center;"><thead><tr class="thead">';
			$starttag = '<th scope="col"><div style="text-align:center;">';
			$endtag = '</div></th>';
		}
		else
		{
			$output .= '<Row ss:AutoFitHeight="0" ss:Height="37.5">'."\n";
			$starttag = '<Cell ss:StyleID="s51"><Data ss:Type="String">';
			$endtag = '</Data></Cell>'."\n";
		}
		
		$wats_default_ticket_listing_active_columns = $wats_settings['wats_default_ticket_listing_active_columns'];

		if ($wats_default_ticket_listing_active_columns['id'] == 1)
		{
			if (($wats_settings['numerotation'] == 1) || ($wats_settings['numerotation'] == 2))
			{
				$output .= $starttag.'ID'.$endtag;
				$colspan++;
			}
		}
		
		if ($wats_default_ticket_listing_active_columns['title'] == 1)
		{
			$output .= $starttag.__('Title','WATS').$endtag;
			$colspan++;
		}
		
		if ($wats_default_ticket_listing_active_columns['category'] == 1)
		{
			$output .= $starttag.__('Category','WATS').$endtag;
			$colspan++;	
		}
		
		if ($wats_default_ticket_listing_active_columns['author'] == 1)
		{
			$output .= $starttag.__('Author','WATS').$endtag;
			$colspan++;
		}
		
		if ($wats_settings['meta_column_ticket_listing'] == 1 && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))))
		{
			$output .= $starttag.$wats_settings['meta_column_ticket_listing_meta_key'].$endtag;
			$colspan++;
		}
		
		if ($wats_default_ticket_listing_active_columns['owner'] == 1)
		{
			if ($wats_settings['ticket_assign'] != 0)
			{
				$output .= $starttag.__('Owner','WATS').$endtag;
				$colspan++;
			}
		}
		
		if ($wats_default_ticket_listing_active_columns['creation_date'] == 1)
		{
			$output .= $starttag.__('Creation date','WATS').$endtag;
			$colspan++;
		}
			
		if ($wats_default_ticket_listing_active_columns['modification_date'] == 1)
		{
			$output .= $starttag.__('Last modification date','WATS').$endtag;
			$colspan++;
		}
		
		if ($wats_default_ticket_listing_active_columns['last_updater'] == 1)
		{
			$output .= $starttag.__('Last modification author','WATS').$endtag;
			$colspan++;
		}
		
		if ($wats_default_ticket_listing_active_columns['ticket_age'] == 1)
		{
			if ($view != 2)
				$output .= '<th class="{sorter: '."'ages'".'}" scope="col"><div style="text-align:center;">'.__('Ticket age','WATS').$endtag;
			else
				$output .= $starttag.__('Ticket age','WATS').$endtag;
			$colspan++;
		}
		
		if ($wats_default_ticket_listing_active_columns['closure_date'] == 1)
		{
			$output .= $starttag.__('Closure date','WATS').$endtag;
			$colspan++;
		}

		if ($wats_default_ticket_listing_active_columns['type'] == 1 && $wats_settings['ticket_type_key_enabled'] == 1)
		{
			$output .= $starttag.__('Type','WATS').$endtag;
			$colspan++;
		}
		
		if ($wats_default_ticket_listing_active_columns['priority'] == 1 && $wats_settings['ticket_priority_key_enabled'] == 1)
		{
			$output .= $starttag.__('Priority','WATS').$endtag;
			$colspan++;
		}
		
		if ($wats_default_ticket_listing_active_columns['status'] == 1 && $wats_settings['ticket_status_key_enabled'] == 1)
		{
			$output .= $starttag.__('Status','WATS').$endtag;
			$colspan++;
		}
		
		if ($wats_default_ticket_listing_active_columns['product'] == 1 && $wats_settings['ticket_product_key_enabled'] == 1)
		{
			$output .= $starttag.__('Product','WATS').$endtag;
			$colspan++;
		}
		
		$wats_ticket_custom_field_values = (isset($wats_settings['wats_ticket_custom_fields'])) ? $wats_settings['wats_ticket_custom_fields'] : 0;
		if (is_array($wats_ticket_custom_field_values))
		foreach ($wats_ticket_custom_field_values as $key => $table)
		{
			if ($table['ftltc'] == 1 || ($table['ftltc'] == 2 && current_user_can('administrator')))
			{
				$output .= $starttag.esc_html($table['name']).$endtag;
				$colspan++;
			}
		}
		
		if (isset($wats_default_ticket_listing_active_columns['edit']) && $wats_default_ticket_listing_active_columns['edit'] == 1 && $view != 2 && current_user_can('administrator'))
		{
			$output .= $starttag.__('Edit','WATS').$endtag;
			$colspan++;
		}
		
		if (isset($wats_default_ticket_listing_active_columns['description']) && $wats_default_ticket_listing_active_columns['description'] == 1 && $view != 2)
		{
			$output .= $starttag.__('Description','WATS').$endtag;
			$colspan++;
		}
		
		if ($view != 2)
		{
			$output .= '</tr></thead><tbody>';
			$rowstarttag = '<tr>';
			$starttag = '<td>';
			$endtag = '</td>';
			$rowendtag = '</tr>';
		}
		else
		{
			$output .= '</Row>'."\n";
			$rowstarttag = '<Row ss:AutoFitHeight="1">'."\n";
			$starttag = '<Cell ss:StyleID="s52"><Data ss:Type="String">';
			$endtag = '</Data></Cell>'."\n";
			$rowendtag = '</Row>'."\n";
		}

		$alt = false;
		
		$x = 0;
		if (isset($tickets))
		foreach ($tickets as $ticket)
		{
			$x = 1;
		
			if ($view != 2 && $alt == true)
				$output .= '<tr class="alternate">';
			else
				$output .= $rowstarttag;
			
			$output .= wats_ticket_list_get_row($view,$ticket,$starttag,$endtag,$colspan);
				
			$output .= $rowendtag;
			$alt = !$alt;
		}
		
		if ($x == 0)
		{
			if ($view != 2)
			{
				$output .= '<tr valign="middle"><td colspan="'.$colspan.'" style="text-align:center">'.__('No entry','WATS').'</td></tr>';
			}
			else
			{
				$freespan = $colspan - 1;
				$output .= '<Row ss:AutoFitHeight="0" ss:Height="38.25">'."\n".'<Cell ss:MergeAcross="'.$freespan.'" ss:StyleID="s52"><Data ss:Type="String">'."\n";
				$output .= __('No entry','WATS');
				$output .= "\n".'</Data></Cell></Row>'."\n";
			}
		}
		
		if ($view != 2)
			$output .= '</tbody></table><br />';
		else
		{
			$freespan = $colspan - 1;
			$output = '<Row ss:AutoFitHeight="0" ss:Height="38.25">'."\n".'<Cell ss:MergeAcross="'.$freespan.'" ss:StyleID="s45"><Data ss:Type="String">'."\n".__('Ticket Listing', 'WATS')."\n".'</Data></Cell></Row>'."\n".$output;
		}

		$form_end = '';
		if ($view == 0)
		{
			$output .= '</div>';
			$form_end .= '</div>';
		}
		if ($view != 2)
			$form_end .= '</form><p>';
		$result['form_end'] = $form_end;
	}
	
	$result['ticket_list'] = $output;
	
	$result = apply_filters('wats_frontend_ticket_listing_result_filter',$result);
	
	$output = '';
	foreach ($result as $key => $value)
	{
		if ($key != "authenticated")
			$output .= $value;
	}

	add_filter('the_title','wats_title_insert_ticket_number',10,2);
	
	return($output);
}

/************************************************************************************************/
/*                                                                                              */
/* Fonction de filtrage sur le contenu pour l'affichage du formulaire de soumission des tickets */
/*                                                                                              */
/************************************************************************************************/

function wats_ticket_submit_form_filter($content)
{
	return (preg_replace_callback(WATS_TICKET_SUBMIT_FORM, 'wats_ticket_submit_form', $content));
}

/****************************************************************/
/*                                                              */
/* Fonction d'affichage du formulaire de soumission des tickets */
/*                                                              */
/****************************************************************/

function wats_ticket_submit_form()
{
	global $current_user, $wats_settings, $wats_frontend_submission_form_shortcode;
	
	$wats_frontend_submission_form_shortcode = true;

	if (WATS_PREMIUM == false)
	{
		$output = __('The frontend submission form feature is only available in the premium release. Don\'t hesitate to <a href="http://www.ticket-system.net/order/">order it</a>!','WATS');
	}
	else
	{
		if ($wats_settings['frontend_submit_form_access'] == 1 || ($wats_settings['frontend_submit_form_access'] == 2 && is_user_logged_in()))
		{
			$output = '<form action="" method="post" id="wats_frontend_ticket_submission_form">';
			$output .= wp_nonce_field('filter-wats-submit-form','_wpnonce_ticket_submit_form',true,false);
		 
			$code = '<div id="wats_fsf_user_details"><div class="wats_ticket_form_title">'.__('User details','WATS').'</div>';
			if (is_user_logged_in())
				$code .= '<div class="wats_logged_in_fsf">'.__('Logged in as ', 'WATS').$current_user->display_name.' (<a href="'.wp_logout_url(get_permalink()).'" title="Logout">'.__('Logout','WATS').'</a>)</div></div><br />';
			else
			{
				if ($wats_settings['fsf_unauthenticated_name_mandatory'] == 1)
					$code .= '<div class="wats_name_fsf"><label class="wats_label">'.__('Name', 'WATS').' '.__('(required)','WATS').' : </label> <input type="text" name="name" id="name" value="" size="22" /></div>';
				else
					$code .= '<div class="wats_name_fsf"><label class="wats_label">'.__('Name', 'WATS').' : </label> <input type="text" name="name" id="name" value="" size="22" /></div>';
					
				if ($wats_settings['fsf_unauthenticated_email_mandatory'] == 1)
					$code .= '<div class="wats_mail_fsf"><label class="wats_label">'.__('Email', 'WATS').' '.__('(required)', 'WATS').' : </label> <input type="text" name="email" id="email" value="" size="22" /></div>';
				else
					$code .= '<div class="wats_mail_fsf"><label class="wats_label">'.__('Email', 'WATS').' : </label> <input type="text" name="email" id="email" value="" size="22" /></div>';
					
				if ($wats_settings['fsf_unauthenticated_website_mandatory'] == 1)
					$code .= '<div class="wats_website_fsf"><label class="wats_label">'.__('Website', 'WATS').' '.__('(required)', 'WATS').' : </label> <input type="text" name="url" id="url" value="" size="22" /></div></div><br />';
				else
					$code .= '<div class="wats_website_fsf"><label class="wats_label">'.__('Website', 'WATS').' : </label> <input type="text" name="url" id="url" value="" size="22" /></div></div><br />';
			}
			$output_array['user_details'] = $code;

			$code = '<div class="wats_select_ticket_details_frontend wats_ticket_form_title">'.__('Ticket details','WATS').'</div><br />';
			$code .= wats_ticket_details_meta_box(null,1);
			
			$output_array['ticket_metas'] = $code;
			
			$code = '<div class="wats_select_ticket_category_frontend"><label class="wats_label">'.__('Category', 'WATS').' : </label>';
			add_filter('list_terms_exclusions','wats_list_terms_exclusions');
			$code .= wp_dropdown_categories('type=post&hide_empty=0&hierarchical=1&id=wats_cat_list&echo=0&orderby=name');
			remove_filter('list_terms_exclusions','wats_list_terms_exclusions');
			$code .= '</div><br />';
			$output_array['category'] = $code;
					
			$code = '<div class="wats_ticket_form_title wats_ticket_frontend_submission_form_title">'.__('Ticket title', 'WATS').'<br />';
			$code .= '<input type="text" name="ticket_title" id="ticket_title" value="" size="50" /></div><br />';
			
			$output_array['ticket_title'] = $code;

			$code = '<div class="wats_ticket_form_title wats_ticket_frontend_submission_form_description">'.__('Ticket description', 'WATS').'<br />';
			if ($wats_settings['fsf_enable_tinymce'] == 0)
				$code .= '<textarea name="ticket_content" id="ticketcontent" cols="60" rows="10"></textarea>';
			else
			{
				ob_start();
				wp_editor('', 'ticketcontent',array("media_buttons" => false,"textarea_rows" => 10));
				$code .= ob_get_clean();
			}
			$code .= '</div><br />';
			$output_array['ticket_description'] = $code;
			
/*			wp_enqueue_media();
			$output_array['ticket_attachments'] = '<div class="wats_attach_fsf"><label class="wats_label">'.__('Attachments','WATS').':</label><br /><input id="wats_upload_files" type="hidden" size="36" name="wats_upload_files" value="" /><input id="wats_upload_button" class="wats_upload_button" type="button" value="'.__('Upload files','WATS').'" /></div><br />';
	*/	
			$output_array = apply_filters('wats_ticket_submit_form_output_array',$output_array);
			
			foreach ($output_array as $key => $value)
			{
				$output .= $value;
			}
		
			$output .= '<input name="wats_submit_ticket" type="submit" id="wats_submit_ticket" value="'.__('Submit ticket', 'WATS').'" />';
			$output .= '<div id="resultticketsubmitform"></div>';
			$output .= '</form><br />';
		}
		else if ($wats_settings['frontend_submit_form_access'] == 2)
		{
			$output = __('Please authenticate yourself to be able to access the ticket submission form.','WATS');
			$output .= '<form action="'.site_url().'/wp-login.php" method="post">';
			$output .= '<table class="wats_submit_form_login_table"><tbody>';
			$output .= '<tr><td>'.__('User','WATS').'</td><td><input type="text" class="input" name="log" id="log" style="width:12em;" /></td></tr>';
			$output .= '<tr><td>'.__('Password','WATS').'</td><td><input type="password" class="input" name="pwd" id="pwd" style="width:12em;" /></td></tr>';
			$output .= '<tr><td><input type="submit" name="submit" value="'.__('Log In').'" class="button" /></td>';
			$output .= '<td><input name="rememberme" id="rememberme" type="checkbox" value="forever" /> '.__('Remember Me').'</td></tr></tbody></table>';
			$output .= '<input type="hidden" name="redirect_to" value="'.$_SERVER['REQUEST_URI'].'"/>';
			$output .= '</form>';
			$output = apply_filters('wats_filter_frontend_submission_login_form',$output);
		}
		else if ($wats_settings['frontend_submit_form_access'] == 0)
			$output = __('Sorry, the ticket submission form access has been disabled by the admin.','WATS');
	}
	
	return ($output);
}

/*********************************************************/
/*                                                       */
/* Fonction de processing Ajax de soumission d'un ticket */
/*                                                       */
/*********************************************************/

function wats_ticket_submit_form_ajax_processing()
{
	global $wats_settings, $current_user;

	wats_load_settings();
	check_ajax_referer('filter-wats-submit-form');
	$create_metas = 0;
	$wats_ticket_assign = $wats_settings['ticket_assign'];
	$role = array_shift($current_user->roles);
	$user_can_assign = 0;
	if (isset($role) && isset($wats_settings['ticket_assignment_'.$role]) && $wats_settings['ticket_assignment_'.$role] == 1)
		$user_can_assign = 1;

	if ($_POST['view'] == 1 && ($wats_settings['frontend_submit_form_access'] == 1 || ($wats_settings['frontend_submit_form_access'] == 2 && is_user_logged_in())))
	{
		$error = '';
		$post_title = stripslashes_deep(strip_tags($_POST['ticket_title']));
		$post_title = apply_filters('wats_filter_submission_form_processing_title_check',$post_title);
		if (is_array($post_title))
			$error .= $post_title['error'];
		
		if ($wats_settings['fsf_enable_tinymce'] == 0)
			$post_content = stripslashes_deep(strip_tags($_POST['ticket_content'], '<br><i><b><u><strong>'));
		else
			$post_content = stripslashes_deep($_POST['ticket_content']);
		$post_content = apply_filters('wats_filter_submission_form_processing_content_check',$post_content);
		if (is_array($post_content))
			$error .= $post_content['error'];
		
		$listecf = isset($_POST['liste']) ? json_decode(stripslashes($_POST['liste'])) : 0;
		
		if ($wats_settings['fsf_unauthenticated_title_mandatory'] == 1 && !strlen(trim($post_title)))
			$error .= __('The ticket title is empty or contains invalid characters. ','WATS');
		
		if ($wats_settings['fsf_unauthenticated_description_mandatory'] == 1 && !strlen(trim($post_content)))
			$error .= __('The ticket description is empty or contains invalid characters. ','WATS');
		
		$post_category = wats_is_numeric($_POST['category']) ? array($_POST['category']) : array(get_option('default_email_category'));
		$post_type = 'ticket';
		
		if (is_user_logged_in())
		{
			if (current_user_can('administrator') && $wats_settings['call_center_ticket_creation'] == 1)
				$post_author = wats_get_user_ID_from_user_login(stripslashes_deep($_POST['author']));
			else
				$post_author = $current_user->ID;
		}
		else
		{
			$name = esc_html($_POST['name']);
			$email = esc_html($_POST['email']);
			$url = esc_html($_POST['url']);

			if ($wats_settings['fsf_unauthenticated_name_mandatory'] == 1)
			{
				if (strlen($name) > 0 && !wats_is_string(stripslashes($name)))
					$error .= __('The name contains invalid characters. ','WATS');
				else if (strlen(trim($name)) == 0)
					$error .= __('Please enter a name. ','WATS');
			}
			
			if (is_email($email))
			{
				$userdata = get_user_by('email', $email);
				if ($userdata)
					$post_author = $userdata->ID;
				else
				{
					$post_author = wats_get_user_ID_from_user_login($wats_settings['submit_form_default_author']);
					$create_metas = 1;
				}
			}
			else if ($wats_settings['fsf_unauthenticated_email_mandatory'] == 1)
			{
				if (strlen($email) > 0)
					$error .= __('The email contains invalid characters. ','WATS');
				else if (strlen(trim($email)) == 0)
					$error .= __('Please enter an email. ','WATS');
			}
			
			if ($wats_settings['fsf_unauthenticated_website_mandatory'] == 1)
			{
				if (strlen(trim($url)) == 0)
					$error .= __('Please enter a website. ','WATS');
			}
		}
		
		if (is_array($listecf))
		{
			$liste = array();
			foreach ($listecf as $key => $table)
			{
				foreach ($table as $subkey => $value)
					$liste[$subkey] = $value;
			}

			$liste = apply_filters('wats_filter_submission_form_processing_custom_fields_check',$liste);
			if (is_array($liste) && isset($liste['error']))
				$error .= $liste['error'];
		}
		
		if ($wats_settings['frontend_submit_form_ticket_status'] == 0)
			$post_status = 'pending';
		else if ($wats_settings['frontend_submit_form_ticket_status'] == 1)
		{
			if (is_user_logged_in())
				$post_status = 'publish';
			else
				$post_status = 'pending';
		}
		else if ($wats_settings['frontend_submit_form_ticket_status'] == 2)
		{
			if (is_user_logged_in())
			{
				$user = new WP_User($post_author);
				$post_status = ($user->has_cap('publish_posts')) ? 'publish' : 'pending';
			}
			else
				$post_status = 'pending';
		}
		else if ($wats_settings['frontend_submit_form_ticket_status'] == 3)
			$post_status = 'publish';
		else
			$post_status = 'pending';

		$post_data = compact('post_content','post_title','post_author','post_category', 'post_status', 'post_type');
		$post_data = add_magic_quotes($post_data);

		if (strlen($error))
			echo json_encode(array('result' => 'FALSE', 'message' => __('Error : ','WATS').$error));
		else
		{
			$post_ID = wp_insert_post($post_data, new WP_Error);
			if (is_wp_error($post_ID))
				echo json_encode(array('result' => 'FALSE', 'message' => $post_ID->get_error_message()));
			else
			{
				if ($wats_settings['ticket_status_key_enabled'] == 1 && isset($_POST['idstatus']) && $_POST['idstatus'] > 0)
					add_post_meta($post_ID,'wats_ticket_status',$_POST['idstatus']);
				if ($wats_settings['ticket_type_key_enabled'] == 1 && isset($_POST['idtype']) && $_POST['idtype'] > 0)
					add_post_meta($post_ID,'wats_ticket_type',$_POST['idtype']);
				if ($wats_settings['ticket_priority_key_enabled'] == 1 && isset($_POST['idpriority']) && $_POST['idpriority'] > 0)
					add_post_meta($post_ID,'wats_ticket_priority',$_POST['idpriority']);
				if ($wats_settings['ticket_product_key_enabled'] == 1 && isset($_POST['idproduct']) && $_POST['idproduct'] > 0)
					add_post_meta($post_ID,'wats_ticket_product',$_POST['idproduct']);
				//add_post_meta($post_ID,'wats_ticket_number',wats_get_latest_ticket_number()+1);
				if ($create_metas == 1)
				{
					add_post_meta($post_ID,'wats_ticket_author_name',$name);
					add_post_meta($post_ID,'wats_ticket_author_email',$email);
					add_post_meta($post_ID,'wats_ticket_author_url',$url);
				}
				
				if ((($wats_settings['ticket_notification_custom_list'] == 2 && current_user_can('administrator')) || $wats_settings['ticket_notification_custom_list'] == 1) && isset($_POST['wats_update_notification_mailing_list']))
				{
					$mailing_list = str_replace(";",",",$_POST['wats_update_notification_mailing_list']);
					if (strlen($mailing_list) == 0)
						delete_post_meta($post_ID,'wats_update_notification_mailing_list');
					else
						update_post_meta($post_ID,'wats_update_notification_mailing_list',$mailing_list);
				}
				
				if ($wats_ticket_assign == 1 || ($wats_ticket_assign == 2 && $user_can_assign == 1))
				{
					if (isset($_POST['idowner']))
						add_post_meta($post_ID,'wats_ticket_owner',$_POST['idowner']);
				}
				
				if (is_array($listecf))
				{
					$wats_ticket_custom_field_values = $wats_settings['wats_ticket_custom_fields'];
					
					if (is_array($wats_ticket_custom_field_values))
					foreach ($wats_ticket_custom_field_values as $key => $table)
					{
						if ($table['fsf'] == 4 || ($table['fsf'] == 5 && current_user_can('administrator')))
						{
							if (isset($table['type']) && $table['type'] == 1 && isset($liste['wats_select_cf_'.$table['meta_key']]))
								update_post_meta($post_ID,$table['meta_key'],$liste['wats_select_cf_'.$table['meta_key']]);
							if (isset($table['type']) && $table['type'] == 2 && isset($liste['wats_cf_datepicker_'.$table['meta_key']]))
							{
								if (wats_is_date($liste['wats_cf_datepicker_'.$table['meta_key']],2))
									update_post_meta($post_ID,$table['meta_key'],date("Y-m-d",strtotime($liste['wats_cf_datepicker_'.$table['meta_key']])));
							}
							else if (isset($liste['wats_cf_'.$table['meta_key']]))
								update_post_meta($post_ID,$table['meta_key'],$liste['wats_cf_'.$table['meta_key']]);
						}
					}
				}

				$ticketnumber = wats_get_ticket_number($post_ID);
				if ($ticketnumber != 0)
					$output = __('Ticket ','WATS').$ticketnumber.__(' has been successfully created!','WATS').'<br />';
				else
					$output = __('Ticket has been successfully created!','WATS').'<br />';
				if ($post_status == 'publish')
					$output .= __('You can access it ','WATS').'<a href="'.get_permalink($post_ID).'">'.__('here','WATS').'</a>.';
				else
					$output .= __('You will be able to access it ','WATS').'<a href="'.get_permalink($post_ID).'">'.__('here','WATS').'</a> '.__('when an admin would have approved it','WATS').'.';
				$output = apply_filters('wats_filter_submission_form_successfull_submission',$output);
				echo json_encode(array('result' => 'TRUE', 'message' => $output));
				wats_fire_admin_notification($post_ID);
				
				do_action('wats_ticket_frontend_submission_saved_meta',$post_ID);
			}
		}
	}
	else
		echo json_encode(array('result' => 'FALSE', 'message' => __('Error : can\'t submit form','WATS')));
	
	exit;
}

/****************************************/
/*                                      */
/* Fonction de v�rification d'un ticket */
/*                                      */
/****************************************/

function wats_is_ticket($post)
{
	if (get_post_type($post) == "ticket")
		return true;
	
	return false;
}

/******************************/
/*                            */
/* Fonction d'ajout du footer */
/*                            */
/******************************/

function wats_wp_footer()
{
	/*if (WATS_PREMIUM == false && is_front_page() && (!is_paged()))
		echo '<div style="text-align:center;">Wordpress advanced <a href="'.WATS_BACKLINK.'">'.WATS_ANCHOR.'</a></div>';*/
		
	return;
}

/*********************************************************/
/*                                                       */
/* Fonction de redirection de la template pour un ticket */
/*                                                       */
/*********************************************************/

function wats_ticket_template_loader($template)
{
	global $wp_query, $wats_settings;

	if (is_singular() && wats_is_ticket($wp_query->post) == true)
	{
		if (wats_check_visibility_rights())
		{
			if ($wats_settings['template_selector'] == 0)
			{
				if (get_single_template())
					$template = str_replace('single-ticket','single',get_single_template());
				add_filter('the_content','wats_single_ticket_content_filter',10,1);
			}
			else
			{
				if (file_exists(get_stylesheet_directory().'/single-ticket.php')) $template = get_stylesheet_directory().'/single-ticket.php';
				else $template = WATS_THEME_PATH.'/single-ticket.php';
			}
		}
		else
		{
			if (file_exists(get_stylesheet_directory().'/ticket-access-denied.php')) $template = get_stylesheet_directory().'/ticket-access-denied.php';
			else $template = WATS_THEME_PATH.'/ticket-access-denied.php';
		}
	}
	
	return($template);
}

/**************************************************************/
/*                                                            */
/* Fonction d'affichage du message d'acc�s interdit au ticket */
/*                                                            */
/**************************************************************/

function wats_ticket_access_denied()
{
	global $post;

	if (!is_user_logged_in())
	{
		$output = '<div id="wats_single_ticket_access_denied"><p>'.__('Please authenticate yourself to view this ticket.', 'WATS').'</p>';
		$output .= '<form action="'.site_url().'/wp-login.php" method="post">';
		$output .= '<table class="wats_submit_form_login_table"><tbody>';
		$output .= '<tr><td>'.__('User','WATS').'</td><td><input type="text" class="input" name="log" id="log" style="width:12em;" /></td></tr>';
		$output .= '<tr><td>'.__('Password','WATS').'</td><td><input type="password" class="input" name="pwd" id="pwd" style="width:12em;" /></td></tr>';
		$output .= '<tr><td><input type="submit" name="submit" value="'.__('Log In').'" class="button" /></td>';
		$output .= '<td><input name="rememberme" id="rememberme" type="checkbox" value="forever" /> '.__('Remember Me').'</td></tr></tbody></table>';
		$output .= '<input type="hidden" name="redirect_to" value="'.$_SERVER['REQUEST_URI'].'"/>';
		$output .= '</form></div>';
		echo apply_filters('wats_filter_single_ticket_access_login_form',$output,$post);
	}
	else
	{
		$output = '<div id="wats_single_ticket_access_denied"><blockquote>'.__('Sorry, you don\'t have the rights to browse this ticket.','WATS').' ';
		$output .= __('If you believe that you should have access to it, please contact the website administrator.','WATS').'<blockquote></div>';
		echo apply_filters('wats_filter_single_ticket_access_denied',$output,$post);
	}
	
	return;
}

/****************************************************/
/*                                                  */
/* Fonction de filtrage du contenu du single ticket */
/*                                                  */
/****************************************************/

function wats_single_ticket_content_filter($content)
{
	global $wats_settings, $post;

	$output = '';
	if (wats_check_visibility_rights())
	{
		$output .= '<div id="wats_single_ticket_metas">';
		if ($wats_settings['ticket_priority_key_enabled'] == 1)
			$output .= '<div id="wats_single_ticket_priority" class="wats_priority_'.get_post_meta($post->ID,'wats_ticket_priority',true).'"><label class="wats_label">'.__("Current priority : ",'WATS').'</label>'.wats_ticket_get_priority($post).'</div>';
		if ($wats_settings['ticket_status_key_enabled'] == 1)
			$output .= '<div id="wats_single_ticket_status" class="wats_status_'.get_post_meta($post->ID,'wats_ticket_status',true).'"><label class="wats_label">'.__("Current status : ",'WATS').'</label>'.wats_ticket_get_status($post).'</div>';
		if ($wats_settings['ticket_type_key_enabled'] == 1)
			$output .= '<div id="wats_single_ticket_type" class="wats_type_'.get_post_meta($post->ID,'wats_ticket_type',true).'"><label class="wats_label">'.__("Ticket type : ",'WATS').'</label>'.wats_ticket_get_type($post).'</div>';
		if ($wats_settings['ticket_product_key_enabled'] == 1)
			$output .= '<div id="wats_single_ticket_product" class="wats_product_'.get_post_meta($post->ID,'wats_ticket_product',true).'"><label class="wats_label">'.__("Ticket product : ",'WATS').'</label>'.wats_ticket_get_product($post).'</div>';
		$output .= wats_ticket_get_custom_fields_frontend_ticket_template($post);
		$output .= '<div id="wats_single_ticket_originator"><label class="wats_label">'.__("Ticket originator : ",'WATS').'</label>'.get_the_author().'</div>';
		if ($wats_settings['ticket_assign'] != 0)
			$output .= '<div id="wats_single_ticket_owner"><label class="wats_label">'.__("Current ticket owner : ",'WATS').'</label>'.wats_ticket_get_owner($post).'</div>';
		if (current_user_can('administrator'))
		{
			$ticket_author_name = get_post_meta($post->ID,'wats_ticket_author_name',true);
			if ($ticket_author_name)
				$output .= '<div id="wats_single_ticket_author_name"><label class="wats_label">'.__('Ticket author name : ','WATS').'</label>'.$ticket_author_name.'</div>';
			$ticket_author_email = get_post_meta($post->ID,'wats_ticket_author_email',true);
			if ($ticket_author_email)
				$output .= '<div id="wats_single_ticket_author_email"><label class="wats_label">'.__('Ticket author email : ','WATS').'</label>'.'<a href="mailto:'.$ticket_author_email.'">'.$ticket_author_email.'</a></div>';
			$ticket_author_url = get_post_meta($post->ID,'wats_ticket_author_url',true);
			if ($ticket_author_url)
				$output .= '<div id="wats_single_ticket_author_url"><label class="wats_label">'.__('Ticket author url : ','WATS').'</label>'.'<a href="'.$ticket_author_url.'">'.$ticket_author_url.'</a></div>';
		}
		$output .= '</div>';
		$output = apply_filters('wats_single_ticket_content_metas_output_filter',$output);
		$content = $output.$content;
		remove_filter('the_content','wats_single_ticket_content_filter');
	}
	else
	{
		wp_die(__('You are not allowed to view this ticket.','WATS'));
	}

	return $content;
}

/*************************************************/
/*                                               */
/* Fonction de filtrage pour inclure les tickets */
/*                                               */
/*************************************************/

function wats_posts_where($where)
{
	global $wpdb, $wats_settings, $current_user, $wp_query;
	
	if ((!is_home() || $wats_settings['wats_home_display'] == 1) && (!is_admin()) && (!is_page()) && (!is_search()))
	{
		if ($wats_settings['visibility'] == 0)
			$where = str_replace($wpdb->posts.".post_type = 'post' AND","(".$wpdb->posts.".post_type = 'post' OR ".$wpdb->posts.".post_type = 'ticket') AND", $where);
		else if ($wats_settings['visibility'] == 1 && is_user_logged_in())
			$where = str_replace($wpdb->posts.".post_type = 'post' AND","(".$wpdb->posts.".post_type = 'post' OR ".$wpdb->posts.".post_type = 'ticket') AND", $where);
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))))
			$where = str_replace($wpdb->posts.".post_type = 'post' AND","(".$wpdb->posts.".post_type = 'post' OR ".$wpdb->posts.".post_type = 'ticket') AND", $where);
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && !is_admin() && $wats_settings['ticket_visibility_same_company'] == 1)
		{
			$liste = "'".implode("','",wats_build_user_array_from_company($current_user->ID))."'";
			$where = str_replace($wpdb->posts.".post_type = 'post' AND","(".$wpdb->posts.".post_type = 'post' OR (".$wpdb->posts.".post_type = 'ticket' AND ".$wpdb->posts.".post_author IN(".$liste."))) AND", $where);
		}
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in())
			$where = str_replace($wpdb->posts.".post_type = 'post' AND","(".$wpdb->posts.".post_type = 'post' OR (".$wpdb->posts.".post_type = 'ticket' AND ".$wpdb->posts.".post_author = ".$current_user->ID.")) AND", $where);
	}
	
	if (is_admin() && isset($_GET['post_type']) && $_GET['post_type'] == 'ticket')
	{
		if ($wats_settings['visibility'] == 2 && !current_user_can('administrator'))
		{
			if ($wats_settings['ticket_visibility_same_company'] == 1)
			{
				$liste = "'".implode("','",wats_build_user_array_from_company($current_user->ID))."'";
				$where = str_replace($wpdb->posts.".post_type = 'ticket' AND"," (".$wpdb->posts.".post_type = 'ticket' AND ".$wpdb->posts.".post_author IN(".$liste.")) AND",$where);
			}
			else
				$where = str_replace($wpdb->posts.".post_type = 'ticket' AND",$wpdb->posts.".post_type = 'ticket' AND ".$wpdb->posts.".post_author = ".$current_user->ID." AND", $where);
		}
	}
	
	if (is_search())
	{
		if ($wats_settings['visibility'] == 1 && !is_user_logged_in())
			$where = str_replace(", 'ticket'","", $where);
		else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && !current_user_can('administrator') && ($wats_settings['ticket_visibility_read_only_capability'] == 0 || !current_user_can('wats_ticket_read_only')))
		{
			$where = str_replace(", 'ticket'","", $where);
			$count = 0;
			$where = str_replace($wpdb->posts.".post_type IN","((".$wpdb->posts.".post_type IN", $where, $count);
			if (!is_admin() && $wats_settings['ticket_visibility_same_company'] == 1)
			{
				$liste = "'".implode("','",wats_build_user_array_from_company($current_user->ID))."'";
				if ($count == 1)
					$where .= ") OR (".$wpdb->posts.".post_type = 'ticket' AND ".$wpdb->posts.".post_author IN(".$liste.")))";
				else
					$where .= " OR (".$wpdb->posts.".post_type = 'ticket' AND ".$wpdb->posts.".post_author IN(".$liste."))";
			}
			else
			{
				if ($count == 1)
					$where .= ") OR (".$wpdb->posts.".post_type = 'ticket' AND ".$wpdb->posts.".post_author = ".$current_user->ID."))";
				else
					$where .= " OR (".$wpdb->posts.".post_type = 'ticket' AND ".$wpdb->posts.".post_author = ".$current_user->ID.")";
			}
		}
		else if ($wats_settings['visibility'] == 2 && !is_user_logged_in())
		{
			$where = str_replace(", 'ticket'","", $where);
		}
	}

	return($where);
}

/*******************************************************************/
/*                                                                 */
/* Fonction de filtrage pour inclure les tickets dans les archives */
/*                                                                 */
/*******************************************************************/

function wats_get_archives($where)
{
	$where = str_replace( " post_type = 'post' AND", " (post_type = 'post' OR post_type = 'ticket') AND", $where);

	return($where);
}

/****************************************************************************/
/*                                                                          */
/* Fonction de redirection de la template pour les commentaires d'un ticket */
/*                                                                          */
/****************************************************************************/

function wats_comments_template($template)
{
	global $wp_query, $wats_settings;

	if (wats_is_ticket($wp_query->post) == true)
	{
		if (wats_check_visibility_rights())
		{
			if ($wats_settings['template_selector'] == 0)
			{
				add_filter('comments_open','wats_ticket_comments_open',10,2);
				add_action('comment_form_comments_closed','wats_ticket_comments_closed',10);
			
				if (wats_get_ticket_update_rights() == true)
					add_filter('comment_form_field_comment','wats_comment_form_after_fields',10,1);
			}
			else
			{
				if (file_exists(get_stylesheet_directory().'/comments-ticket.php')) $template = get_stylesheet_directory().'/comments-ticket.php';
				else $template = WATS_THEME_PATH.'/comments-ticket.php';
			}
		}
		else
		{
			wp_die(__('You are not allowed to view this ticket.','WATS'));
		}
	}

	add_filter('comment_class','wats_comment_class');
	
	return($template);
}

/****************************************************************************/
/*                                                                          */
/* Fonction de fermeture des commentaires WP */
/*                                                                          */
/****************************************************************************/

function wats_ticket_comments_open($open,$post_id)
{
	if (wats_get_ticket_update_rights() == false)
		return false;
	else
		return true;
}

/****************************************************************************/
/*                                                                          */
/* Fonction d'affichage de la raison de la fermeture des commentaires sur le ticket */
/*                                                                          */
/****************************************************************************/

function wats_ticket_comments_closed()
{
	echo apply_filters('wats_get_ticket_update_rights_message_filter',wats_get_ticket_update_rights_message());
	
	return;
}

/****************************************************************************/
/*                                                                          */
/* Fonction d'affichage des tickets metas dans le formulaire des commentaires */
/*                                                                          */
/****************************************************************************/

function wats_comment_form_after_fields($args)
{
	global $post;
	
	wats_ticket_details_meta_box($post);
	
	return $args;
}

/********************************************************************/
/*                                                                  */
/* Fonction d'ajout d'une classe CSS pour les commentaires internes */
/*                                                                  */
/********************************************************************/

function wats_comment_class($classes)
{

	if (get_comment_meta(get_comment_ID(),'wats_internal_update',true) == 1)
	{
		$classes[] = 'wats_internal_update';
	}
	
	return $classes;
}

/**************************************************/
/*                                                */
/* Fonction de filtrage des champs de commentaire */
/*                                                */
/**************************************************/

function wats_comment_form_defaults($args)
{
	global $wats_settings;
	
	if ($wats_settings['ftuf_enable_tinymce'] == 1)
	{
		ob_start();
		wp_editor('','comment',array("media_buttons" => false,"textarea_rows" => 10));
		$args['comment_field'] = ob_get_clean();
	}
	
	return $args;
}

/************************************/
/*                                  */
/* Fonction d'ajout d'une taxonomie */
/*                                  */
/************************************/

function wats_register_taxonomy()
{
	global $wats_settings;

	$taxonomies[] =  'category';
	if ($wats_settings['tickets_tagging'] == 1)
		$taxonomies[] = 'post_tag';

	$plugin_url = trailingslashit(get_option('siteurl')) . 'wp-content/plugins/' . basename(dirname(__FILE__)) .'/';
	$labels = array('name' => __('Tickets','WATS'),
					'singular_name' => __('ticket','WATS'),
					'add_new' => __('Add New','WATS'),
					'add_new_item' => __('Add New Ticket','WATS'),
					'edit_item' => __('Edit Ticket','WATS'),
					'new_item' => __('New Ticket','WATS'),
					'view_item' => __('View Ticket','WATS'),
					'search_items' => __('Search Ticket','WATS'),
					'not_found' =>  __('No tickets found','WATS'),
					'not_found_in_trash' => __('No tickets found in Trash','WATS'), 
					'parent_item_colon' => '');
	$args = array('labels' => $labels,
				  'public' => true,
				  'publicly_queryable' => true,
				  'show_ui' => true, 
				  'query_var' => true,
				  'rewrite' => true,
				  'capability_type' => 'post',
				  'hierarchical' => false,
				  'menu_position' => null,
				  'menu_icon' => $plugin_url.'img/support.png',
				  'supports' => array('title','editor','comments'),
				  'register_meta_box_cb' => 'wats_ticket_meta_boxes',
				  'taxonomies' => $taxonomies);
	register_post_type('ticket',$args);
	
	return;
}

/*********************************************************/
/*                                                       */
/* Fonction de calcul du nombre d'�l�ments par cat�gorie */
/*                                                       */
/*********************************************************/

function wats_update_ticket_term_count($terms)
{
	global $wpdb;
 
    foreach ((array) $terms as $term)
	{
        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $wpdb->term_relationships, $wpdb->posts WHERE $wpdb->posts.ID = $wpdb->term_relationships.object_id AND post_status = 'publish' AND (post_type = 'ticket' OR post_type = 'post') AND term_taxonomy_id = %d", $term));
        $wpdb->update($wpdb->term_taxonomy, compact('count'), array('term_taxonomy_id' => $term));
    }
}

/******************************************************/
/*                                                    */
/* Fonction d'ajout du num�ro de ticket dans le titre */
/*                                                    */
/******************************************************/

function wats_title_insert_ticket_number($title, $postID = 0)
{
	global $wats_printing_inline_data;

	if (get_post_type($postID) == "ticket" && $wats_printing_inline_data == false)
	{
		$value = wats_get_ticket_number($postID);
		
		if ($value)
			return($value." ".$title);
	}
	
	if (is_admin() && $wats_printing_inline_data == false)
		$wats_printing_inline_data = true;

	return ($title);
}

/*******************************************************/
/*                                                     */
/* Fonction de modification des liens previous et next */
/*                                                     */
/*******************************************************/

function wats_ticket_get_previous_next_post_where($where)
{
	global $wats_settings, $current_user;

	$searched_pattern = array(" AND p.post_type = 'ticket'"," AND p.post_type = 'post'");
	if ($wats_settings['visibility'] == 0)
		$where = str_replace($searched_pattern, " AND (p.post_type = 'post' OR p.post_type = 'ticket')", $where);
	else if ($wats_settings['visibility'] == 1 && is_user_logged_in())
		$where = str_replace($searched_pattern, " AND (p.post_type = 'post' OR p.post_type = 'ticket')", $where);
	else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && (current_user_can('administrator') || ($wats_settings['ticket_visibility_read_only_capability'] == 1 && current_user_can('wats_ticket_read_only'))))
		$where = str_replace($searched_pattern, " AND (p.post_type = 'post' OR p.post_type = 'ticket')", $where);
	else if ($wats_settings['visibility'] == 2 && is_user_logged_in() && !is_admin() && $wats_settings['ticket_visibility_same_company'] == 1)
	{
		$liste = "'".implode("','",wats_build_user_array_from_company($current_user->ID))."'";
		$where = str_replace($searched_pattern, " AND (p.post_type = 'post' OR (p.post_type = 'ticket' AND p.post_author IN(".$liste.")))", $where);
	}
	else if ($wats_settings['visibility'] == 2 && is_user_logged_in())
		$where = str_replace($searched_pattern, " AND (p.post_type = 'post' OR (p.post_type = 'ticket' AND p.post_author = ".$current_user->ID."))", $where);

	return ($where);
}

/***************************************/
/*                                     */
/* Fonction de filtrage des cat�gories */
/*                                     */
/***************************************/

function wats_list_terms_exclusions($args)
{
	global $wats_settings;
	
	$where = "";
	if (isset($wats_settings['wats_categories']))
	{
		$list = $wats_settings['wats_categories'];
		$catlist = array();
		foreach ($list as $key => $value)
		{
			$catlist[] = $key;
		}
		if (count($catlist))
		{
			$catlist = implode(',',$catlist);
			$where = " AND t.term_id IN ($catlist)";
		}
		else
			$where = " AND t.term_id IN ('')";
	}
	
	return $where;
}

/****************************************************/
/*                                                  */
/* Fonction de filtrage du flux RSS des commentaire */
/*                                                  */
/****************************************************/

function wats_filter_comments_rss($cwhere)
{

	$cwhere = $cwhere." AND post_type != 'ticket'";
	
	return $cwhere;
}

/****************************************************/
/*                                                  */
/* Fonction pour ajouter des colonnes personnalis�e */
/*                                                  */
/****************************************************/

function wats_edit_post_column($defaults)
{
	global $wats_settings;

	if ($defaults)
	{
		if ($wats_settings['ticket_type_key_enabled'] == 1)
			$defaults['type'] = __('Type','WATS');
		if ($wats_settings['ticket_priority_key_enabled'] == 1)
			$defaults['priority'] = __('Priority','WATS');
		if ($wats_settings['ticket_status_key_enabled'] == 1)
			$defaults['status'] = __('Status','WATS');
		$defaults['title'] = __('Ticket','WATS');
		if ($wats_settings['ticket_product_key_enabled'] == 1)
			$defaults['product'] = __('Product','WATS');
		unset($defaults['tags']);
		return $defaults;
	}
	
	return;
}

/*****************************************************/
/*                                                   */
/* Fonction pour remplir les colonnes personnalis�es */
/*                                                   */
/*****************************************************/

function wats_edit_post_custom_column($column_name, $post_id)
{
	global $wats_settings;
	
	$wats_ticket_priority = isset($wats_settings['wats_priorities']) ? $wats_settings['wats_priorities'] : 0;
	$wats_ticket_type = isset($wats_settings['wats_types']) ? $wats_settings['wats_types'] : 0;
	$wats_ticket_status = isset($wats_settings['wats_statuses']) ? $wats_settings['wats_statuses'] : 0;
	$wats_ticket_product = isset($wats_settings['wats_products']) ?  $wats_settings['wats_products'] : 0;
	
	if ($column_name == 'priority')
	{
		$ticket_priority = get_post_meta($post_id,'wats_ticket_priority',true);
		if (wats_is_numeric($ticket_priority) && isset($wats_ticket_priority[$ticket_priority]))
			echo $wats_ticket_priority[$ticket_priority];
	}
	else if ($column_name == 'status')
	{
		$ticket_status = get_post_meta($post_id,'wats_ticket_status',true);
		if (wats_is_numeric($ticket_status) && isset($wats_ticket_status[$ticket_status]))
			echo $wats_ticket_status[$ticket_status];
	}
	else if ($column_name == 'type')
	{
		$ticket_type = get_post_meta($post_id,'wats_ticket_type',true);
		if (wats_is_numeric($ticket_type) && isset($wats_ticket_type[$ticket_type]))
			echo $wats_ticket_type[$ticket_type];
	}
	else if ($column_name == 'product')
	{
		$ticket_product = get_post_meta($post_id,'wats_ticket_product',true);
		if (wats_is_numeric($ticket_product) && isset($wats_ticket_product[$ticket_product]))
			echo $wats_ticket_product[$ticket_product];
	}
	
	return;
}

/*************************************************/
/*                                               */
/* Fonction de rewrite du title dans le frontend */
/*                                               */
/*************************************************/

function wats_wp_title($title)
{
	global $post;

	if (is_single() && $post->post_type == 'ticket')
	{
		$title = $post->post_title." | ";
	}
	
	return $title;
}

/*************************************************/
/*                                               */
/* Fonction de filtrage des posts rows actions */
/*                                               */
/*************************************************/

function wats_post_row_actions($actions, $post)
{
	global $wats_printing_inline_data;
	
	$wats_printing_inline_data = false;

	return $actions;
}

/*****************************************/
/*                                       */
/* Fonction de filtrage des commentaires */
/*                                       */
/*****************************************/

function wats_get_comments_clauses($clauses)
{
	global $wpdb, $wats_settings, $current_user;

	if (!current_user_can('administrator'))
	{
		$clauses['where'] = str_replace('comment_approved','wp1.comment_approved',$clauses['where']);
		$clauses['where'] = str_replace('comment_post_ID','wp1.comment_post_ID',$clauses['where']);
		$clauses['where'] = str_replace($wpdb->posts.'.post_status','wp3.post_status',$clauses['where']);
		
		if ($wats_settings['visibility'] == 2 && is_user_logged_in())
		{
				
			$clauses['join'] = " AS wp1 LEFT JOIN ".$wpdb->posts." AS wp3 ON wp1.comment_post_id = wp3.ID ";
			$where = '';
			if ($wats_settings['ticket_visibility_same_company'] == 1)
			{
				$clauses['where'] = str_replace('user_id','wp1.user_id',$clauses['where']);
				$clauses['join'] .= " LEFT JOIN ".$wpdb->usermeta." as wp4 ON wp3.post_author = wp4.user_id ";
				$clauses['join'] .= " LEFT JOIN ".$wpdb->usermeta." as wp5 ON wp5.user_id = ".$current_user->ID." ";
				$where = " OR (wp4.meta_key = '".$wats_settings['company_meta_key_profile']."' AND wp5.meta_key = '".$wats_settings['company_meta_key_profile']."' AND wp4.meta_value = wp5.meta_value) ";
				$clauses['groupby'] = "wp1.comment_ID";
			}
				
			$clauses['where'] .= " AND wp3.post_status = 'publish' AND (wp3.post_author = ".$current_user->ID." ".$where." OR wp3.post_type != 'ticket') AND NOT EXISTS (SELECT * FROM ".$wpdb->commentmeta." AS wp2 WHERE wp1.comment_ID = wp2.comment_id AND wp2.meta_key = 'wats_internal_update' AND wp2.meta_value = 1) ";
			$clauses['orderby'] = "wp1.comment_date_gmt ASC, wp1.comment_ID ASC ";
		}
		else if (($wats_settings['visibility'] == 1 && is_user_logged_in()) || $wats_settings['visibility'] == 0)
		{
			$clauses['join'] = " AS wp1 LEFT JOIN ".$wpdb->posts." AS wp3 ON wp1.comment_post_id = wp3.ID";
			$clauses['where'] .= " AND wp3.post_status = 'publish' AND NOT EXISTS (SELECT * FROM ".$wpdb->commentmeta." AS wp2 WHERE wp1.comment_ID = wp2.comment_id AND wp2.meta_key = 'wats_internal_update' AND wp2.meta_value = 1) ";
			$clauses['orderby'] = "wp1.comment_date_gmt ASC, wp1.comment_ID ASC";
		}
		else
		{
			$clauses['join'] = " AS wp1 LEFT JOIN ".$wpdb->posts." AS wp3 ON wp1.comment_post_id = wp3.ID ";
			$clauses['where'] .= " AND wp3.post_status = 'publish' AND wp3.post_type != 'ticket' AND NOT EXISTS (SELECT * FROM ".$wpdb->commentmeta." AS wp2 WHERE wp1.comment_ID = wp2.comment_id AND wp2.meta_key = 'wats_internal_update' AND wp2.meta_value = 1) ";
			$clauses['orderby'] = "wp1.comment_date_gmt ASC, wp1.comment_ID ASC";
		}
	}

	return $clauses;
}

function wats_comments_array($comments,$post_id)
{
	if (!current_user_can('administrator'))
	{
		foreach ($comments AS $key => $comment)
		{
			if (get_comment_meta($comment->comment_ID,'wats_internal_update',true) == 1)
			{
				unset($comments[$key]);
			}
		}
	}
	
	return $comments;	
}

function wats_get_comments_number($count, $post_id)
{
	global $wpdb;

	if (!current_user_can('administrator'))
	{
		$count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".$wpdb->posts." AS wp1 LEFT JOIN ".$wpdb->comments." AS wp2 ON wp1.ID = wp2.comment_post_ID WHERE wp2.comment_post_ID = %d AND NOT EXISTS (SELECT * FROM ".$wpdb->commentmeta." AS wp3 WHERE wp2.comment_ID = wp3.comment_id AND wp3.meta_key = 'wats_internal_update' AND wp3.meta_value = 1)",$post_id));
	}
	
	return $count;
}

?>