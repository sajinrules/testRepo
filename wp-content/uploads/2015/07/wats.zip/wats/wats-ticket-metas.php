<?php

/********************************************/
/*                                          */
/* Fonction de r�cup�ration du ticket owner */
/*                                          */
/********************************************/

function wats_ticket_get_owner($post)
{
	global $wats_settings;
	
	$output = '';
	if ($wats_settings['ticket_assign'] != 0)
	{
		$ticket_owner = get_post_meta($post->ID,'wats_ticket_owner',true);
		if (strlen($ticket_owner) > 0)
		{
			$ticket_owner = get_user_by('login', $ticket_owner);
			if (isset($ticket_owner->ID))
			{
				if (function_exists('get_the_author_meta'))
					$output = get_the_author_meta('nickname',$ticket_owner->ID);
				else
					$output = get_the_author($ticket_owner->ID);
			}
			else
				$output = __('None','WATS');
		}
		else
			$output = __('None','WATS');
	}

	return($output);
}


/*******************************************************/
/*                                                     */
/* Fonction de r�cup�ration de la priorit� d'un ticket */
/*                                                     */
/*******************************************************/

function wats_ticket_get_priority($post)
{
	global $wats_settings;
	
	$wats_ticket_priority = isset($wats_settings['wats_priorities']) ? $wats_settings['wats_priorities'] : 0;
	
	$priority = get_post_meta($post->ID,'wats_ticket_priority',true);
	
	if (wats_is_numeric($priority) && isset($wats_ticket_priority[$priority]))
		$output = esc_html__($wats_ticket_priority[$priority],'WATS');
	else
		$output = '';
	
	return($output);
}

/************************************************/
/*                                              */
/* Fonction de r�cup�ration du type d'un ticket */
/*                                              */
/************************************************/

function wats_ticket_get_type($post)
{
	global $wats_settings;
	
	$wats_ticket_type = isset($wats_settings['wats_types']) ? $wats_settings['wats_types'] : 0;

	$type = get_post_meta($post->ID,'wats_ticket_type',true);
	
	if (wats_is_numeric($type) && isset($wats_ticket_type[$type]))
		$output = esc_html__($wats_ticket_type[$type],'WATS');
	else
		$output = '';
	
	return($output);
}

/**************************************************/
/*                                                */
/* Fonction de r�cup�ration du status d'un ticket */
/*                                                */
/**************************************************/

function wats_ticket_get_status($post)
{
	global $wats_settings;
	
	$wats_ticket_status = isset($wats_settings['wats_statuses']) ? $wats_settings['wats_statuses'] : 0;
	
	$status = get_post_meta($post->ID,'wats_ticket_status',true);
	
	if (wats_is_numeric($status) && isset($wats_ticket_status[$status]))
		$output = esc_html__($wats_ticket_status[$status],'WATS');
	else
		$output = '';
	
	return($output);
}

/***************************************************/
/*                                                 */
/* Fonction de r�cup�ration du produit d'un ticket */
/*                                                 */
/***************************************************/

function wats_ticket_get_product($post)
{
	global $wats_settings;
	
	$wats_ticket_product = isset($wats_settings['wats_products']) ? $wats_settings['wats_products'] : 0;
	
	$product = get_post_meta($post->ID,'wats_ticket_product',true);
	
	if (wats_is_numeric($product) && isset($wats_ticket_product[$product]))
		$output = esc_html__($wats_ticket_product[$product],'WATS');
	else
		$output = '';
	
	return($output);
}

/****************************************************************/
/*                                                              */
/* Fonction de r�cup�ration de la date de fermeture d'un ticket */
/*                                                              */
/****************************************************************/

function wats_ticket_get_closure_date($post)
{
	global $wats_settings;

	$output = mysql2date('M d, Y',get_post_meta($post->ID,'wats_ticket_closure_date',true),false);
	
	return($output);
}

/*******************************************/
/*                                         */
/* Fonction de calcul de l'�ge d'un ticket */
/*                                         */
/*******************************************/

function wats_ticket_get_age($post)
{
	global $wpdb,$wats_settings;
	
	$age = array();
	if ($wats_settings['ticket_status_key_enabled'] == 1 && get_post_meta($post->ID,'wats_ticket_status',true) != wats_get_closed_status_id())
	{
		$total = strtotime(date('Y-m-d  h:i:s A')) - strtotime(get_post_time('Y-m-d  h:i:s A',true,$post->ID,false));
		$age['days'] = floor($total / (60 * 60 * 24));
		$age['hours'] = floor(($total - ($age['days'] * 24 * 60 * 60)) / (60 * 60));
		$age['minutes'] = floor(($total - ($age['days'] * 24 * 60 * 60) - ($age['hours'] * 60 * 60)) / 60);
	}
	else if ($wats_settings['ticket_status_key_enabled'] == 1 && get_post_meta($post->ID,'wats_ticket_status',true) == wats_get_closed_status_id())
	{
		$closure_date = get_post_meta($post->ID,'wats_ticket_closure_date',true);
		if (!strlen($closure_date))
		{
			$comments = $wpdb->get_row($wpdb->prepare("SELECT comment_ID, comment_date FROM $wpdb->comments WHERE comment_post_ID = %d ORDER BY comment_date DESC LIMIT 1",$post->ID));
			if (!is_object($comments))
				$closure_date = date('Y-m-d  h:i:s A');
			else
				$closure_date = mysql2date('Y-m-d  h:i:s A',$comments->comment_date,false);
		}
		else
			$closure_date = mysql2date('Y-m-d  h:i:s A',$closure_date,false);
		$total = strtotime($closure_date) - strtotime(get_post_time('Y-m-d  h:i:s A',true,$post->ID,false));
		$age['days'] = floor($total / (60 * 60 * 24));
		$age['hours'] = floor(($total - ($age['days'] * 24 * 60 * 60)) / (60 * 60));
		$age['minutes'] = floor(($total - ($age['days'] * 24 * 60 * 60) - ($age['hours'] * 60 * 60)) / 60);
	}

	return $age;
}

/***************************************************************/
/*                                                             */
/* Fonction de r�cup�ration des custom fields li�s aux tickets */
/*                                                             */
/***************************************************************/

function wats_ticket_get_custom_fields_frontend_ticket_template($post)
{
	global $wats_settings;
	
	$output = '';
	$wats_ticket_custom_field_values = (isset($wats_settings['wats_ticket_custom_fields'])) ? $wats_settings['wats_ticket_custom_fields'] : 0;
	if (is_array($wats_ticket_custom_field_values))
	foreach ($wats_ticket_custom_field_values as $key => $table)
	{
		if ($table['ftdt'] == 1 || ($table['ftdt'] == 2 && current_user_can('administrator')))
		{
			if (isset($table['type']) && $table['type'] == 1)
			{
				$values = $table['values'];
				$current_value = get_post_meta($post->ID,$table['meta_key'],true);
				if (isset($values[$current_value]))
					$code = esc_html($values[$current_value]);
				else
					$code = '';
			}
			else if (isset($table['type']) && $table['type'] == 2)
				$code = mysql2date('M d, Y',esc_html(get_post_meta($post->ID,$table['meta_key'],true)),false);
			else
				$code = esc_html(get_post_meta($post->ID,$table['meta_key'],true));
			$output .= '<div class="wats_single_ticket_custom_field" id="wats_cf_'.$table['meta_key'].'"><label class="wats_label">'.esc_html($table['name'])." : </label>".$code.'</div>';
		}
	}

	return($output);
}

/*************************************************/
/*                                               */
/* Fonction de mise � jour des metas d'un ticket */
/*                                               */
/*************************************************/

function wats_comment_update_meta($comment_id)
{
	global $wats_settings;
	
	wats_load_settings();
	
	$comment = get_comment($comment_id); 
	$status = $comment->comment_approved; 
	$post_id =  $comment->comment_post_ID;
	if ($status !== "spam" && wats_is_ticket($post_id))
	{
		wats_ticket_save_meta($post_id,get_post($post_id),$comment->comment_author_email);
		
		if (current_user_can('administrator') && $wats_settings['internal_comment_visibility'] == 1 && isset($_POST['wats_internal_update']))
			update_comment_meta($comment_id,'wats_internal_update',1);
	}

	return;
}

/******************************************************/
/*                                                    */
/* Fonction de preprocessing d'un nouveau commentaire */
/*                                                    */
/******************************************************/

function wats_pre_comment_on_post($comment_post_id)
{
	global $wats_settings, $current_user;
	
	$post = get_post($comment_post_id);
	if ($post->post_type == 'ticket')
	{
		if ($wats_settings['ticket_status_key_enabled'] == 1 && get_post_meta($comment_post_id,'wats_ticket_status',true) == wats_get_closed_status_id() && !current_user_can('administrator'))
			wp_die(__('Sorry, you can\'t update this ticket.','WATS'));
		else if ($wats_settings['visibility'] == 1 && !is_user_logged_in())
			wp_die(__('Sorry, you must be logged in to update this ticket.','WATS'));
		else if ($wats_settings['visibility'] == 2 && (!is_user_logged_in() || (is_user_logged_in() && !current_user_can('administrator') && $current_user->ID != $post->post_author && ($wats_settings['ticket_visibility_same_company'] == 0 || wats_check_user_same_company($current_user->ID,$post->post_author) == false))))
			wp_die(__('Sorry, you don\'t have the rights to update this ticket.','WATS'));
	}
		
	return;
}

/*************************************************/
/*                                               */
/* Fonction de filtrage d'un nouveau commentaire */
/*                                               */
/*************************************************/

function wats_preprocess_comment($commentdata)
{
	global $wats_settings, $current_user;
	
	wats_load_settings();
	
	if (!is_admin() && current_user_can('administrator') && $wats_settings['call_center_ticket_update'] == 1 && isset($_POST['wats_select_ticket_updater']) && get_post_type($commentdata['comment_post_ID']) == 'ticket' && $current_user->user_login != $_POST['wats_select_ticket_updater'])
	{
		$commentdata['user_ID'] = intval(wats_get_user_ID_from_user_login($_POST['wats_select_ticket_updater']));
		$commentdata['comment_author'] = $_POST['wats_select_ticket_updater'];
		$user = new WP_user($commentdata['user_ID']);
		$commentdata['comment_author_email'] = $user->user_email;
		$commentdata['comment_author_url'] = $user->user_url;
	}

	return $commentdata;
}

/************************************************/
/*                                              */
/* Fonction de sauvegarde des metas d'un ticket */
/*                                              */
/************************************************/

function wats_ticket_save_meta($postID,$post,$comment_author_email = '')
{
	global $wats_settings, $wpdb;

	wats_load_settings();
	
	if ($post->post_type == 'ticket')
	{

		$newticket = 0;

		if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || $post->post_status == 'auto-draft' || $post->post_status == 'trash')
		{
			return $postID;
		}
				
		$newstatus = -1;
		if ($wats_settings['ticket_status_key_enabled'] == 1 && isset($_POST['wats_select_ticket_status']))
		{
			$status = get_post_meta($postID,'wats_ticket_status',true);

			if (get_post_meta($postID,'wats_ticket_status',true) != wats_get_closed_status_id() || current_user_can('administrator'))
			{
				if ($status != $_POST['wats_select_ticket_status'])
					$newstatus = $_POST['wats_select_ticket_status'];
					
				if ($status == wats_get_closed_status_id() && $newstatus != wats_get_closed_status_id())
					delete_post_meta($postID,'wats_ticket_closure_date');

				if ($_POST['wats_select_ticket_status'] > 0)
					update_post_meta($postID,'wats_ticket_status',$_POST['wats_select_ticket_status']);
					
				if ($newstatus == wats_get_closed_status_id())
					update_post_meta($postID,'wats_ticket_closure_date',current_time('mysql'));
			}
		}

		$newtype = -1;
		if ($wats_settings['ticket_type_key_enabled'] == 1 && isset($_POST['wats_select_ticket_type']))
		{
			$type = get_post_meta($postID,'wats_ticket_type',true);
			if ($type != $_POST['wats_select_ticket_type'])
				$newtype = $_POST['wats_select_ticket_type'];
			
			if ($_POST['wats_select_ticket_type'] > 0)
				update_post_meta($postID,'wats_ticket_type',$_POST['wats_select_ticket_type']);
		}
			
		$newpriority = -1;
		if ($wats_settings['ticket_priority_key_enabled'] == 1 && isset($_POST['wats_select_ticket_priority']))
		{
			$priority = get_post_meta($postID,'wats_ticket_priority',true);
			if ($priority != $_POST['wats_select_ticket_priority'])
				$newpriority = $_POST['wats_select_ticket_priority'];
			
			if ($_POST['wats_select_ticket_priority'] > 0)
				update_post_meta($postID,'wats_ticket_priority',$_POST['wats_select_ticket_priority']);
		}
		
		$newproduct = -1;
		if ($wats_settings['ticket_product_key_enabled'] == 1 && isset($_POST['wats_select_ticket_product']))
		{
			$product = get_post_meta($postID,'wats_ticket_product',true);
			if ($product != $_POST['wats_select_ticket_product'])
				$newproduct = $_POST['wats_select_ticket_product'];
			
			if ($_POST['wats_select_ticket_product'] > 0)
				update_post_meta($postID,'wats_ticket_product',$_POST['wats_select_ticket_product']);
		}
		
		$newowner = -1;
		if (isset($_POST['wats_select_ticket_owner']))
		{
			$owner = get_post_meta($postID,'wats_ticket_owner',true);
			if ($owner != $_POST['wats_select_ticket_owner'])
				$newowner = $_POST['wats_select_ticket_owner'];
			
			update_post_meta($postID,'wats_ticket_owner',$_POST['wats_select_ticket_owner']);
		}
		
		if ((($wats_settings['ticket_notification_custom_list'] == 2 && current_user_can('administrator')) || $wats_settings['ticket_notification_custom_list'] == 1) && isset($_POST['wats_update_notification_mailing_list']))
		{
			$mailing_list = str_replace(";",",",$_POST['wats_update_notification_mailing_list']);
			if (strlen($mailing_list) == 0)
				delete_post_meta($postID,'wats_update_notification_mailing_list');
			else
				update_post_meta($postID,'wats_update_notification_mailing_list',$mailing_list);
		}
		
		$wats_ticket_custom_field_values = (isset($wats_settings['wats_ticket_custom_fields'])) ? $wats_settings['wats_ticket_custom_fields'] : 0;
		if (is_array($wats_ticket_custom_field_values))
		foreach ($wats_ticket_custom_field_values as $key => $table)
		{
			if ((is_admin() && (($table['atef'] == 3 && current_user_can('administrator')) || $table['atef'] == 4 || ($table['atef'] == 5 && current_user_can('administrator'))))
			|| (!is_admin() && ($table['ftuf'] == 4 || ($table['ftuf'] == 5 && current_user_can('administrator')))))
			{
				if (isset($table['type']) && $table['type'] == 1 && isset($_POST['wats_select_cf_'.$table['meta_key']]))
					update_post_meta($postID,$table['meta_key'],$_POST['wats_select_cf_'.$table['meta_key']]);
				else if (isset($table['type']) && $table['type'] == 2 && isset($_POST['wats_cf_datepicker_'.$table['meta_key']]))
				{
					if (wats_is_date($_POST['wats_cf_datepicker_'.$table['meta_key']],2))
						update_post_meta($postID,$table['meta_key'],date("Y-m-d",strtotime($_POST['wats_cf_datepicker_'.$table['meta_key']])));
				}
				else if (isset($_POST['wats_cf_'.$table['meta_key']]))
					update_post_meta($postID,$table['meta_key'],$_POST['wats_cf_'.$table['meta_key']]);
			}
		}
		
		if (!get_post_meta($postID,'wats_ticket_number',true))
		{
			add_post_meta($postID,'wats_ticket_number',wats_get_latest_ticket_number()+1);
			$newticket = 1;
		}
		
		if ($newticket == 1)
		{
			if (!isset($_POST['view']) || (isset($_POST['view']) && $_POST['view'] != 1))
			{
				wats_fire_admin_notification($postID);
				do_action('wats_ticket_admin_submission_saved_meta',$postID);
			}
		}
		else
		{
			if (!isset($_POST['wats_update_no_notification']) || !current_user_can('administrator'))
				wats_fire_ticket_update_notification($postID,$newstatus,$newtype,$newpriority,$newproduct,$newowner,$comment_author_email);
		}
		
		do_action('wats_ticket_saved_meta',$postID);
	}
	
	return;
}

/*****************************************************/
/*                                                   */
/* Fonction de hook durant la sauvegarde d'un ticket */
/*                                                   */
/*****************************************************/

function wats_insert_post_data($data)
{
	global $wats_settings, $current_user;

	if (current_user_can('administrator') && $wats_settings['call_center_ticket_creation'] == 1 && isset($_POST['wats_select_ticket_originator']) && $data['post_type'] == "ticket")
		$data['post_author'] = wats_get_user_ID_from_user_login($_POST['wats_select_ticket_originator']);

	if ($data['post_type'] == "ticket")
		$data['comment_status'] = 'open';
	
	return $data;
}

/************************************************************************/
/*                                                                      */
/* Fonction de filtrage du mail de l'exp�diteur du mail de notification */
/*                                                                      */
/************************************************************************/

function wats_mail_from()
{
	global $wats_settings, $current_user, $wats_current_post_author;
	
	wats_load_settings();
	
	if ($wats_settings['source_email_address'] == 0)
		$mail = get_option('admin_email');
	else if ($wats_current_post_author > 0)
	{
		$user_info = get_userdata($wats_current_post_author);
		$mail = $user_info->user_email;
	}
	else
		$mail = $current_user->user_email;
		
	if (!is_email($mail))
	{
		$sitename = strtolower($_SERVER['SERVER_NAME']);
		if (substr($sitename,0,4) == 'www.')
			$sitename = substr($sitename,4);
		$mail = 'wordpress@'.$sitename;
	}
	
	return $mail;
}

/***********************************************************************/
/*                                                                     */
/* Fonction de filtrage du nom de l'exp�diteur du mail de notification */
/*                                                                     */
/***********************************************************************/

function wats_mail_from_name()
{
	return get_option('blogname');
}

/*******************************************************/
/*                                                     */
/* Fonction de notification de mise � jour d'un ticket */
/*                                                     */
/*******************************************************/

function wats_fire_ticket_update_notification($postID,$newstatus,$newtype,$newpriority,$newproduct,$newowner,$comment_author_email)
{
	global $wats_settings, $wpdb, $wats_current_post_author, $current_user;

	wats_load_settings();

	$updates = '';
	if ($newstatus != -1)
	{
		$wats_ticket_status = $wats_settings['wats_statuses'];
		$updates .= __('Ticket status has been changed to : ','WATS').esc_html__($wats_ticket_status[$newstatus],'WATS').".\r\n";
	}
	if ($newtype != -1)
	{
		$wats_ticket_types = $wats_settings['wats_types'];
		$updates .= __('Ticket type has been changed to : ','WATS').esc_html__($wats_ticket_types[$newtype],'WATS').".\r\n";
	}
	if ($newpriority != -1)
	{
		$wats_ticket_priority = $wats_settings['wats_priorities'];
		$updates .= __('Ticket priority has been changed to : ','WATS').esc_html__($wats_ticket_priority[$newpriority],'WATS').".\r\n";
	}
	if ($newproduct != -1)
	{
		$wats_ticket_product = $wats_settings['wats_products'];
		$updates .= __('Ticket product has been changed to : ','WATS').esc_html__($wats_ticket_product[$newproduct],'WATS').".\r\n";
	}	
	if ($newowner != -1)
	{
		if ($newowner == "0")
			$updates .= __('Ticket owner has been removed','WATS').".\r\n";
		else
		{
			$newowner = get_user_by('login', $newowner);
			if (isset($newowner->ID))
			{
				$newowner = get_the_author_meta('nickname',$newowner->ID);
				$updates .= __('Ticket owner has been assigned to : ','WATS').esc_html__($newowner,'WATS').".\r\n";
			}
		}
	}
	
	wats_fire_rules_notification($postID, $updates, 2);
	
	$ticket_author_id = 0;
	$post = get_post($postID);
	$userid = $post->post_author;
	$wats_current_post_author = 0;
	add_filter('wp_mail_from', 'wats_mail_from');
	add_filter('wp_mail_from_name', 'wats_mail_from_name');

	$ticketnumber = wats_get_ticket_number($postID);
	if ($ticketnumber == 0)
		$ticketnumber = '';

	$notified_list = array();
	$notified_list[] = $current_user->user_email;
	if (strlen($comment_author_email) > 0)
		$notified_list[] = $comment_author_email;
		
	if ($wats_settings['ticket_update_notification_my_tickets'] == 1)
	{
		// Registered author notification
		$user = new WP_user($userid);
		$notifications = get_user_meta($user->ID,'wats_notifications',true);
		
		if (($wats_settings['ticket_notification_bypass_mode'] == 0 || !isset($notifications['ticket_update_notification_my_tickets']) || $notifications['ticket_update_notification_my_tickets'] != 0) && !in_array($user->user_email,$notified_list,true))
		{
			$ticket_author_id = $userid;
			$subject = __('Ticket ','WATS').$ticketnumber.__(' has been updated','WATS');
			$output = __('Hello ','WATS').get_the_author_meta('nickname',$user->ID).",\r\n\r\n";
			$output .= __('Ticket ','WATS').$ticketnumber.__(' has been updated.','WATS');
			$output .= __('You can view it here :','WATS')."\r\n";
			if (!$user->has_cap('subscriber'))
			{
				if (get_post_status($postID) == 'publish')
					$output .= __('+ Frontend side : ','WATS').get_permalink($postID)."\r\n\r\n";
				$output .= __('+ Admin side : ','WATS').wats_get_edit_ticket_link($postID, 'mail')."\r\n\r\n";
			}
			else
				$output .= get_permalink($postID)."\r\n\r\n";
			$output .= $updates."\r\n";
			$output = apply_filters('wats_fire_ticket_update_notification_filter',$output,$postID);
			$output .= wats_get_mail_notification_signature();
			$subject = apply_filters('wats_fire_ticket_update_notification_title_filter',$subject,$postID);
			wp_mail($user->user_email,$subject,$output);
			$notified_list[] = $user->user_email;
		}
		
		// Non registered author notification
		if ($ticket_author_email = get_post_meta($post->ID,'wats_ticket_author_email',true))
		{
			if (!in_array($ticket_author_email,$notified_list,true))
			{
				$subject = __('Ticket ','WATS').$ticketnumber.__(' has been updated','WATS');
				$output = __('Hello ','WATS').get_post_meta($post->ID,'wats_ticket_author_name',true).",\r\n\r\n";
				$output .= __('Ticket ','WATS').$ticketnumber.__(' has been updated.','WATS');
				$output .= __('You can view it here :','WATS')."\r\n";
					$output .= get_permalink($postID)."\r\n\r\n";
				$output .= $updates."\r\n";
				$output = apply_filters('wats_fire_ticket_update_notification_filter',$output,$postID);
				$output .= wats_get_mail_notification_signature();
				$subject = apply_filters('wats_fire_ticket_update_notification_title_filter',$subject,$postID);
				wp_mail($ticket_author_email,$subject,$output);
				$notified_list[] = $ticket_author_email;
			}
		}
		
		// Registered updaters notification
		$users = $wpdb->get_results($wpdb->prepare("SELECT DISTINCT user_id FROM $wpdb->comments WHERE comment_post_ID = %d",$postID));
		foreach ($users AS $user_entry)
		{
			if ($user_entry->user_id != $ticket_author_id)
			{
				$user = new WP_user($user_entry->user_id);
				if (!in_array($user->user_email,$notified_list,true))
				{
					$notifications = get_user_meta($user->ID,'wats_notifications',true);
					if ($wats_settings['ticket_notification_bypass_mode'] == 0 || !isset($notifications['ticket_update_notification_my_tickets']) || $notifications['ticket_update_notification_my_tickets'] != 0)
					{
						$subject = __('Ticket ','WATS').$ticketnumber.__(' has been updated','WATS');
						$output = __('Hello ','WATS').get_the_author_meta('nickname',$user->ID).",\r\n\r\n";
						$output .= __('Ticket ','WATS').$ticketnumber.__(' has been updated.','WATS');
						$output .= __('You can view it here :','WATS')."\r\n";
						if (!$user->has_cap('subscriber'))
						{
							if (get_post_status($postID) == 'publish')
								$output .= __('+ Frontend side : ','WATS').get_permalink($postID)."\r\n\r\n";
							$output .= __('+ Admin side : ','WATS').wats_get_edit_ticket_link($postID, 'mail')."\r\n\r\n";
						}
						else
							$output .= get_permalink($postID)."\r\n\r\n";
						$output .= $updates."\r\n";
						$output = apply_filters('wats_fire_ticket_update_notification_filter',$output,$postID);
						$output .= wats_get_mail_notification_signature();
						$subject = apply_filters('wats_fire_ticket_update_notification_title_filter',$subject,$postID);
						wp_mail($user->user_email,$subject,$output);
						$notified_list[] = $user->user_email;
					}
				}
			}
		}
		
		// Registered owner notification
		if ($wats_settings['ticket_assign'] != 0)
		{
			$ticket_owner = get_post_meta($post->ID,'wats_ticket_owner',true);
			if (strlen($ticket_owner) > 0)
			{
				$ticket_owner = get_user_by('login', $ticket_owner);
				if (isset($ticket_owner->ID) && !in_array($ticket_owner->user_email,$notified_list,true))
				{
					$notifications = get_user_meta($ticket_owner->ID,'wats_notifications',true);
					if ($wats_settings['ticket_notification_bypass_mode'] == 0 || !isset($notifications['ticket_update_notification_my_tickets']) || $notifications['ticket_update_notification_my_tickets'] != 0)
					{
						$subject = __('Ticket ','WATS').$ticketnumber.__(' has been updated','WATS');
						$output = __('Hello ','WATS').get_the_author_meta('nickname',$ticket_owner->ID).",\r\n\r\n";
						$output .= __('Ticket ','WATS').$ticketnumber.__(' has been updated.','WATS');
						$output .= __('You can view it here :','WATS')."\r\n";
						if (!$user->has_cap('subscriber'))
						{
							if (get_post_status($postID) == 'publish')
								$output .= __('+ Frontend side : ','WATS').get_permalink($postID)."\r\n\r\n";
							$output .= __('+ Admin side : ','WATS').wats_get_edit_ticket_link($postID, 'mail')."\r\n\r\n";
						}
						else
							$output .= get_permalink($postID)."\r\n\r\n";
						$output .= $updates."\r\n";
						$output = apply_filters('wats_fire_ticket_update_notification_filter',$output,$postID);
						$output .= wats_get_mail_notification_signature();
						$subject = apply_filters('wats_fire_ticket_update_notification_title_filter',$subject,$postID);
						wp_mail($ticket_owner->user_email,$subject,$output);
						$notified_list[] = $ticket_owner->user_email;
					}
				}
			}
		}
	}
	
	if ($wats_settings['ticket_update_notification_all_tickets'] == 1)
	{

		/*$users = $wpdb->get_results($wpdb->prepare("SELECT ID FROM $wpdb->users WHERE user_login NOT LIKE %s",'%unverified__%'));*/
		if (class_exists('WP_User_Query'))
		{
			$wp_user_search = new WP_User_Query(array('role'=>'administrator'));
			$users = $wp_user_search->get_results();
		}
		else
		{
			$users = $wpdb->get_results("SELECT ID FROM $wpdb->users");
		}
		
		foreach ($users AS $user_entry)
		{
			if ($user_entry->ID != $ticket_author_id)
			{
				$user = new WP_User($user_entry->ID);
				if (!in_array($user->user_email,$notified_list,true))
				{
					$notifications = get_user_meta($user->ID,'wats_notifications',true);
					if ($user->has_cap('administrator') && ($wats_settings['ticket_notification_bypass_mode'] == 0 || !isset($notifications['ticket_update_notification_all_tickets']) || $notifications['ticket_update_notification_all_tickets'] != 0))
					{
						$subject = __('Ticket ','WATS').$ticketnumber.__(' has been updated','WATS');
						$output = __('Hello ','WATS').get_the_author_meta('nickname',$user->ID).",\r\n\r\n";
						$output .= __('Ticket ','WATS').$ticketnumber.__(' has been updated.','WATS');
						$output .= __('You can view it here :','WATS')."\r\n";
						if (!$user->has_cap('subscriber'))
						{
							if (get_post_status($postID) == 'publish')
								$output .= __('+ Frontend side : ','WATS').get_permalink($postID)."\r\n\r\n";
							$output .= __('+ Admin side : ','WATS').wats_get_edit_ticket_link($postID, 'mail')."\r\n\r\n";
						}
						else
							$output .= get_permalink($postID)."\r\n\r\n";
						$output .= $updates."\r\n";
						$output = apply_filters('wats_fire_ticket_update_notification_filter',$output,$postID);
						$output .= wats_get_mail_notification_signature();
						$subject = apply_filters('wats_fire_ticket_update_notification_title_filter',$subject,$postID);
						wp_mail($user->user_email,$subject,$output);
						$notified_list[] = $user->user_email;
					}
				}
			}
		}
	}
	
	if ($wats_settings['ticket_notification_custom_list'] != 0)
	{
		$ticket_update_mailing_list = get_post_meta($postID,'wats_update_notification_mailing_list',true);
		$ticket_update_mailing_list = apply_filters('wats_ticket_update_custom_mailing_list_filter',$ticket_update_mailing_list,$postID);
		
		if (strlen($ticket_update_mailing_list) > 0)
		{
			$subject = __('Ticket ','WATS').$ticketnumber.__(' has been updated','WATS');
			$output = __('Hello ','WATS')."\r\n\r\n";
			$output .= __('Ticket ','WATS').$ticketnumber.__(' has been updated.','WATS');
			$output .= __('You can view it here :','WATS')."\r\n";
			$output .= get_permalink($postID)."\r\n\r\n";
			$output .= $updates."\r\n";
			$output = apply_filters('wats_fire_ticket_update_notification_filter',$output,$postID);
			$output .= wats_get_mail_notification_signature();
			$subject = apply_filters('wats_fire_ticket_update_notification_title_filter',$subject,$postID);
			wp_mail($ticket_update_mailing_list,$subject,$output);
		}
	}

	return;
}

/*******************************************************************************/
/*                                                                             */
/* Fonction de g�n�ration p�riodique des notifications relatives aux due dates */
/*                                                                             */
/*******************************************************************************/

function wats_check_rules_notification_due_date()
{
	global $wpdb,$wats_settings;

	wats_load_settings();
	
	$wats_notification_rules = get_option('wats_notification_rules');
	
	$result = 0;
	if (is_array($wats_notification_rules))
	{
		foreach (array_keys($wats_notification_rules) AS $key)
		{
			foreach ($wats_notification_rules[$key] AS $rule => $list)
			{
				$rule = wats_admin_build_notification_rule($rule);

				if (!isset($rule['scope']))
					$rule['scope'] = 1;

				foreach ($rule AS $key => $value)
				{
					if ($key == 'scope' && $value == 3)
						$result = 1;
				}
			}
		}
		
		if ($result == 1)
		{
			$tickets = $wpdb->get_results($wpdb->prepare("SELECT wp1.ID FROM $wpdb->posts AS wp1 LEFT JOIN $wpdb->postmeta AS wp2 ON wp1.ID = wp2.post_id WHERE wp2.meta_key = %s and wp2.meta_value != %s",'wats_ticket_status',wats_get_closed_status_id()));

			foreach ($tickets as $ticket)
			{
				wats_fire_rules_notification($ticket->ID,'',3);
			}
		}
	}

	return;
}

/************************************************************************/
/*                                                                      */
/* Fonction d'envoi des notifications bas�es sur les r�gles sp�cifiques */
/* view = 1 : new ticket												*/
/* view = 2 : ticket update											    */
/* view = 3 : due date											        */
/*                                                                      */
/************************************************************************/

function wats_fire_rules_notification($postID, $details, $view)
{
	global $wats_settings, $wpdb;
	
	$wats_notification_rules = get_option('wats_notification_rules');
	if (is_array($wats_notification_rules))
	{
		$status = get_post_meta($postID,'wats_ticket_status',true);
		$priority = get_post_meta($postID,'wats_ticket_priority',true);
		$type = get_post_meta($postID,'wats_ticket_type',true);
		$product = get_post_meta($postID,'wats_ticket_product',true);
		$post = get_post($postID);
		$country = get_user_meta($post->post_author,$wats_settings['country_meta_key_profile'],true);
		$company = get_user_meta($post->post_author,$wats_settings['company_meta_key_profile'],true);
		$categories = array();
		$ticket_number = wats_get_ticket_number($postID);
		if ($ticket_number == 0)
			$ticket_number = '';
		foreach ((get_the_category($postID)) as $category)
			$categories[] = $category->cat_ID;

		foreach (array_keys($wats_notification_rules) AS $key)
		{
			foreach ($wats_notification_rules[$key] AS $rule => $list)
			{
				$rule = wats_admin_build_notification_rule($rule);
				$result = 1;
				
				if (!isset($rule['scope']))
					$rule['scope'] = 1;
				
				$notification_liste = array();
				$notification_liste[] = $list;
				$due_date = -1;
				$due_date_start = -1;
				$due_date_interval = -1;
				
				foreach ($rule AS $key => $value)
				{
					if ($view == 1 && $key == 'scope' && ($value == 2 || $value == 3))
						$result = 0;
					if ($view == 2 && $key == 'scope' && ($value == 1 || $value == 3))
						$result = 0;
					if ($view == 3 && $key == 'scope' && ($value != 3))
						$result = 0;
					if ($key == 'priority' && $value != $priority && $value != "0")
						$result = 0;
					if ($key == 'status' && $value != $status && $value != "0")
						$result = 0;
					if ($key == 'type' && $value != $type && $value != "0")
						$result = 0;
					if ($key == 'product' && $value != $product && $value != "0")
						$result = 0;
					if ($key == 'country' && $value != $country && $value != "0")
						$result = 0;
					if ($key == 'company' && $value != $company && $value != "0")
						$result = 0;
					if ($key == 'category' && !in_array($value,$categories,true) && $value != "0")
						$result = 0;
					if ($key == 'notify_author' && $value == 'true')
					{
						$author_email = get_the_author_meta('user_login',$post->post_author);
						if ($wats_settings['wats_guest_user'] != $author_email && is_email($author_email) && !in_array($admin->user_email,$notification_liste,true))
							$notification_liste[] = $author_email;
					}
					if ($key == 'notify_owner' && $value == 'true')
					{
						$ticket_owner = get_post_meta($post->ID,'wats_ticket_owner',true);
						if (strlen($ticket_owner) > 0)
						{
							$ticket_owner = get_user_by('login', $ticket_owner);
							if (isset($ticket_owner->ID))
							{
								$ticket_owner_email = get_the_author_meta('user_email',$ticket_owner->ID);
								if (is_email($ticket_owner_email) && !in_array($ticket_owner_email,$notification_liste,true))
									$notification_liste[] = $ticket_owner_email;
							}
						}
					}
					if ($key == 'notify_admins' && $value == 'true')
					{
						$admins = get_users(array('role' => 'administrator'));
						foreach ($admins as $admin) 
						{
							if (is_email($admin->user_email) && !in_array($admin->user_email,$notification_liste,true))
								$notification_liste[] = $admin->user_email;
						}
					}
					if ($key == 'notify_updaters' && $value == 'true')
					{
						$users = $wpdb->get_results($wpdb->prepare("SELECT DISTINCT user_id FROM $wpdb->comments WHERE comment_post_ID = %d",$postID));
						foreach ($users AS $user_entry)
						{
							$user = new WP_user($user_entry->user_id);
							if (is_email($user->user_email) && !in_array($user->user_email,$notification_liste,true))
							{
								$notification_liste[] = $user->user_email;
							}
						}
					}
					if ($key == 'duedatefield' && $view == 3)
						$due_date = get_post_meta($postID,$value,true);
					if ($key == 'duedatestart' && $view == 3)
						$due_date_start = $value;
					if ($key == 'duedateinterval' && $view == 3)
						$due_date_interval = $value;
				}
				
				if ($view == 3)
				{
					if (!wats_is_date($due_date,1) || $due_date_start == -1 || !wats_is_numeric($due_date_start) || $due_date_interval == -1 || !wats_is_numeric($due_date_interval))
						$result = 0;
					else
					{
						$now = strtotime(date("d/m/Y"));
						$due_date_notification_stamp = strtotime($due_date) - ($due_date_start*24*60*60);
						if ($now > $due_date_notification_stamp)
						{
							$current_interval = ($now - $due_date_notification_stamp)/(24*60*60);
							if ($current_interval % $due_date_interval > 0)
								$result = 0;
						}
						else
							$result = 0;
					}
				}
				
				if ($result == 1)
				{
					$subject = '';
					if ($view == 1 && strlen($ticket_number))
						$subject = __('New ticket submitted','WATS').' ('.$ticket_number.')';
					else if ($view == 1)
						$subject = __('New ticket submitted','WATS');
					else if ($view == 2 && strlen($ticket_number))
						$subject = __('Ticket ','WATS').$ticket_number.__(' has been updated','WATS');
					else if ($view == 2)
						$subject = __('Ticket ','WATS').__(' has been updated','WATS');
					else if ($view == 3 && strlen($ticket_number))
						$subject = __('Please update Ticket ','WATS').$ticket_number;
					else if ($view == 3)
						$subject = __('Please update Ticket!','WATS');
					$output = __('Hello','WATS').",\r\n\r\n";
					if ($view == 1)
						$output .= __('A new ticket has been submitted into the system.','WATS')."\r\n\r\n";
					else if ($view == 2)
						$output .= __('Ticket ','WATS').$ticket_number.__(' has been updated.','WATS')."\r\n\r\n";
					else if ($view == 3)
					{
						$output .= __('The due date for this ticket is : ','WATS').mysql2date('M d, Y',$due_date,false).'.'."\r\n\r\n";
					}
					$output .= $details;
					$output .= __('You can view it here :','WATS')."\r\n";
					if (get_post_status($postID) == 'publish')
						$output .= __('+ Frontend side : ','WATS').get_permalink($postID)."\r\n\r\n";
					$output .= __('+ Admin side : ','WATS').wats_get_edit_ticket_link($postID, 'mail')."\r\n\r\n";
					$output = apply_filters('wats_fire_rules_notification_filter',$output,$postID);
					$output .= wats_get_mail_notification_signature();
					$subject = apply_filters('wats_fire_rules_notification_title_filter',$subject,$postID);
					
					foreach ($notification_liste as $entry)
					{
						if (strlen($entry))
							wp_mail($entry,$subject,$output);
					}
				}
			}
		}
	}
	
	return;
}

/****************************************************/
/*                                                  */
/* Fonction de notification de cr�ation d'un ticket */
/*                                                  */
/****************************************************/

function wats_fire_admin_notification($postID)
{
	global $wats_settings, $wpdb, $wats_current_post_author;

	wats_load_settings();
	
	$wats_ticket_priority = isset($wats_settings['wats_priorities']) ? $wats_settings['wats_priorities'] : 0;
	$wats_ticket_type = isset($wats_settings['wats_types']) ? $wats_settings['wats_types'] : 0;
	$wats_ticket_status = isset($wats_settings['wats_statuses']) ? $wats_settings['wats_statuses'] : 0;
	$wats_ticket_product = isset($wats_settings['wats_products']) ? $wats_settings['wats_products'] : 0;
	$post = get_post($postID);
	$wats_current_post_author = $post->post_author;
	
	$details = __('Here are the ticket details :','WATS')."\r\n";
	if ($wats_settings['ticket_type_key_enabled'] == 1 && isset($wats_ticket_type[get_post_meta($postID,'wats_ticket_type',true)]))
		$details .= __('+ Ticket type : ','WATS').$wats_ticket_type[get_post_meta($postID,'wats_ticket_type',true)]."\r\n";
	if ($wats_settings['ticket_priority_key_enabled'] == 1 && isset($wats_ticket_priority[get_post_meta($postID,'wats_ticket_priority',true)]))
		$details .= __('+ Ticket priority : ','WATS').$wats_ticket_priority[get_post_meta($postID,'wats_ticket_priority',true)]."\r\n";
	if ($wats_settings['ticket_status_key_enabled'] == 1 && isset($wats_ticket_status[get_post_meta($postID,'wats_ticket_status',true)]))
		$details .= __('+ Ticket status : ','WATS').$wats_ticket_status[get_post_meta($postID,'wats_ticket_status',true)]."\r\n";
	if ($wats_settings['ticket_product_key_enabled'] == 1 && isset($wats_ticket_product[get_post_meta($postID,'wats_ticket_product',true)]))
		$details .= __('+ Ticket product : ','WATS').$wats_ticket_product[get_post_meta($postID,'wats_ticket_product',true)]."\r\n";
	$ticket_number = wats_get_ticket_number($postID);
	if ($ticket_number != 0)
		$details .= __('+ Ticket number : ','WATS').$ticket_number."\r\n";
	$details .= __('+ Ticket title : ','WATS').get_the_title($postID)."\r\n\r\n";

	add_filter('wp_mail_from','wats_mail_from');
	add_filter('wp_mail_from_name', 'wats_mail_from_name');
	
	wats_fire_rules_notification($postID, $details, 1);
	
	if ($wats_settings['new_ticket_notification_admin'] == 1)
	{
		if (class_exists('WP_User_Query'))
		{
			$wp_user_search = new WP_User_Query(array('role'=>'administrator'));
			$users = $wp_user_search->get_results();
		}
		else
		{
			$users = $wpdb->get_results("SELECT ID FROM $wpdb->users");
		}
				
		foreach ($users AS $user_entry)
		{
			$user = new WP_user($user_entry->ID);
			
			if ($user->has_cap('administrator'))
			{
				$notifications = get_user_meta($user->ID,'wats_notifications',true);
				if ($wats_settings['ticket_notification_bypass_mode'] == 0 || !isset($notifications['new_ticket_notification_admin']) || $notifications['new_ticket_notification_admin'] != 0)
				{
					if ($ticket_number != 0)
						$subject = __('New ticket submitted','WATS').' ('.$ticket_number.')';
					else
						$subject = __('New ticket submitted','WATS');
					$output = __('Hello ','WATS').get_the_author_meta('nickname',$user->ID).",\r\n\r\n";
					$output .= __('A new ticket has been submitted into the system.','WATS')."\r\n\r\n";
					$output .= $details;
					$output .= __('You can view it here :','WATS')."\r\n";
					if (get_post_status($postID) == 'publish')
						$output .= __('+ Frontend side : ','WATS').get_permalink($postID)."\r\n\r\n";
					$output .= __('+ Admin side : ','WATS').wats_get_edit_ticket_link($postID, 'mail')."\r\n\r\n";
					$output = apply_filters('wats_fire_admin_notification_filter',$output,$postID);
					$output .= wats_get_mail_notification_signature();
					$subject = apply_filters('wats_fire_admin_notification_title_filter',$subject,$postID);
					wp_mail($user->user_email,$subject,$output);
				}
			}
		}
	}
	
	return;
}

/************************************************/
/*                                              */
/* Fonction d'ajout des meta boxes dans l'admin */
/*                                              */
/************************************************/

function wats_ticket_meta_boxes()
{
	global $wp_meta_boxes, $wats_settings;

	remove_meta_box('commentsdiv', 'ticket', 'normal');
	remove_meta_box('commentstatusdiv', 'ticket', 'normal');
	add_meta_box('ticketdetailsdiv',__('Ticket details','WATS'),'wats_ticket_details_meta_box','ticket','normal','default',array('view' => 0));
	add_meta_box('categorydiv', __('Categories'), 'post_categories_meta_box', 'ticket', 'side', 'core');
	if ($wats_settings['tickets_custom_fields'] == 1)
		add_meta_box('postcustom', __('Custom Fields'), 'post_custom_meta_box', 'ticket', 'normal', 'core');
	if ($wats_settings['tickets_tagging'] == 1)
		add_meta_box('tagsdiv-post_tag', __('Tags'), 'post_tags_meta_box', 'ticket', 'side', 'core');
	
	return;
}

/***************************************************************/
/*                                                             */
/* Fonction d'affichage de l'historique d'un ticket (meta box) */
/*                                                             */
/***************************************************************/

function wats_ticket_history_meta_box($post)
{

	echo __('Here is the ticket history','WATS');

	return;
}

/***************************************************************/
/*                                                             */
/* Fonction de filtrage des messages dans la page d'�dition des tickets */
/*                                                             */
/***************************************************************/

function wats_post_updated_messages($messages)
{

	if ((isset($_GET['post_type']) && $_GET['post_type'] == 'ticket') || (isset($_GET['post']) && get_post_type($_GET['post']) == 'ticket'))
	{
		if (isset($_GET['post']))
		{
			$messages['post'][10] = sprintf(__('Ticket draft updated. Please don\'t forget to submit it when edition is complete! <a target="_blank" href="%s">Preview ticket</a>','WATS'), esc_url(add_query_arg('preview','true',get_permalink($_GET['post']))));
		}
	}
	
	return $messages;
}

/***********************************************************/
/*                                                         */
/* Fonction d'affichage des d�tails d'un ticket (meta box) */
/* view : 0 (comment form et ticket edit/creation admin)    */
/* view : 1 (ticket creation frontend) 					   */
/*                                                         */
/***********************************************************/

function wats_ticket_details_meta_box($post,$view=0)
{
	global $wats_settings, $current_user, $pagenow;

	if (is_array($view))
		$view = $view['args']['view'];

	$wats_ticket_priority = isset($wats_settings['wats_priorities']) ? $wats_settings['wats_priorities'] : 0;
	$wats_ticket_type = isset($wats_settings['wats_types']) ? $wats_settings['wats_types'] : 0;
	$wats_ticket_status = isset($wats_settings['wats_statuses']) ? $wats_settings['wats_statuses'] : 0;
	$wats_ticket_product = isset($wats_settings['wats_products']) ? apply_filters('wats_product_list_filter',$wats_settings['wats_products']) : 0;
	$wats_ticket_assign = $wats_settings['ticket_assign'];
	
	$role = array_shift($current_user->roles);
	$user_can_assign = 0;
	if (isset($role) && isset($wats_settings['ticket_assignment_'.$role]) && $wats_settings['ticket_assignment_'.$role] == 1)
		$user_can_assign = 1;
	
	if (is_object($post))
	{
		$ticket_priority = get_post_meta($post->ID,'wats_ticket_priority',true);
		$ticket_status = get_post_meta($post->ID,'wats_ticket_status',true);
		$ticket_type = get_post_meta($post->ID,'wats_ticket_type',true);
		$ticket_owner = get_post_meta($post->ID,'wats_ticket_owner',true);
		$ticket_product = get_post_meta($post->ID,'wats_ticket_product',true);
	}
	else
	{
		$ticket_priority = 0;
		$ticket_status = 0;
		$ticket_type = 0;
		$ticket_owner = 0;
		$ticket_product = 0;
	}
	
	$output = '';
	
	if ($wats_settings['ticket_type_key_enabled'] == 1)
	{
		if ($view == 1)
			$output .= '<div class="wats_select_ticket_type_frontend">';
			
		if ($view == 0 && !is_admin())
			$output .= '<div class="wats_select_ticket_type_frontend_update_form">';
			
		if (is_admin())
			$output.= '<br />';
		$output .= '<label class="wats_label">'.__('Ticket type','WATS').' : </label>';
		$output .= '<select name="wats_select_ticket_type" id="wats_select_ticket_type" class="wats_select">';
		if (is_array($wats_ticket_type))
		foreach ($wats_ticket_type as $key => $value)
		{
			$output .= '<option value='.$key;
			if ($key == $ticket_type || (!$ticket_type && $key == $wats_settings['default_ticket_type']))
				$output .= ' selected';
			$output .= '>'.esc_html__($value,'WATS').'</option>';
		}
		$output .= '</select><br /><br />';
		if ($view == 1 || ($view == 0 && !is_admin()))
			$output .= '</div>';
	}
	
	if ($wats_settings['ticket_priority_key_enabled'] == 1)
	{
		if ($view == 1)
			$output .= '<div class="wats_select_ticket_priority_frontend">';
		
		if ($view == 0 && !is_admin())
			$output .= '<div class="wats_select_ticket_priority_frontend_update_form">';
		
		$output .= '<label class="wats_label">'.__('Ticket priority','WATS').' : </label>';
		$output .= '<select name="wats_select_ticket_priority" id="wats_select_ticket_priority" class="wats_select">';
		if (is_array($wats_ticket_priority))
		foreach ($wats_ticket_priority as $key => $value)
		{
			$output .= '<option value='.$key;
			if ($key == $ticket_priority || (!$ticket_priority && $key == $wats_settings['default_ticket_priority']))
				$output .= ' selected';
			$output .= '>'.esc_html__($value,'WATS').'</option>';
		}
		$output .= '</select><br /><br />';
		
		if ($view == 1 || ($view == 0 && !is_admin()))
			$output .= '</div>';
	}
	
	if ($wats_settings['ticket_status_key_enabled'] == 1)
	{
		if ($view == 1)
			$output .= '<div class="wats_select_ticket_status_frontend">';
		
		if ($view == 0 && !is_admin())
			$output .= '<div class="wats_select_ticket_status_frontend_update_form">';
		
		if (is_admin() && is_object($post) && get_post_meta($post->ID,'wats_ticket_status',true) == wats_get_closed_status_id() && !current_user_can('administrator'))
		{
			$output .= __('Ticket status','WATS').' : '.$wats_ticket_status[wats_get_closed_status_id()].'<br /><br />';
		}
		else
		{
			$output .= '<label class="wats_label">'.__('Ticket status','WATS').' : </label>';
			$output .= '<select name="wats_select_ticket_status" id="wats_select_ticket_status" class="wats_select">';
			if (is_array($wats_ticket_status))
			foreach ($wats_ticket_status as $key => $value)
			{
				$output .= '<option value='.$key;
				if ($key == $ticket_status || (!$ticket_status && $key == $wats_settings['default_ticket_status']))
					$output .= ' selected';
				$output .= '>'.esc_html__($value,'WATS').'</option>';
			}
			$output .= '</select><br /><br />';
		}
		
		if ($view == 1 || ($view == 0 && !is_admin()))
			$output .= '</div>';
	}
	
	if ($wats_settings['ticket_product_key_enabled'] == 1)
	{
		if ($view == 1)
			$output .= '<div class="wats_select_ticket_product_frontend">';
		
		if ($view == 0 && !is_admin())
			$output .= '<div class="wats_select_ticket_product_frontend_update_form">';
		
		$output .= '<label class="wats_label">'.__('Ticket product','WATS').' : </label>';
		$output .= '<select name="wats_select_ticket_product" id="wats_select_ticket_product" class="wats_select">';
		if (is_array($wats_ticket_product))
		foreach ($wats_ticket_product as $key => $value)
		{
			$output .= '<option value='.$key;
			if ($key == $ticket_product || (!$ticket_product && $key == $wats_settings['default_ticket_product']))
				$output .= ' selected';
			$output .= '>'.esc_html__($value,'WATS').'</option>';
		}
		$output .= '</select><br /><br />';
		
		if ($view == 1 || ($view == 0 && !is_admin()))
			$output .= '</div>';
	}
	
	$wats_ticket_custom_field_values = (isset($wats_settings['wats_ticket_custom_fields'])) ? $wats_settings['wats_ticket_custom_fields'] : 0;
	if (is_array($wats_ticket_custom_field_values))
	foreach ($wats_ticket_custom_field_values as $key => $table)
	{
		if (is_admin())
		{
			if ($table['atef'] == 1 || ($table['atef'] == 2 && current_user_can('administrator')) || ($table['atef'] == 3 && !current_user_can('administrator')))
			{
				if (isset($table['type']) && $table['type'] == 1)
				{
					$values = $table['values'];
					$current_value = get_post_meta($post->ID,$table['meta_key'],true);
					if (isset($values[$current_value]))
						$code = esc_html($values[$current_value]);
					else
						$code = '';
				}
				else
					$code = esc_html(get_post_meta($post->ID,$table['meta_key'],true));
				$output .= '<label class="wats_label">'.esc_html($table['name'])." : </label>".$code.'<br /><br />';
			}
			else if (($table['atef'] == 3 && current_user_can('administrator')) || $table['atef'] == 4 || ($table['atef'] == 5 && current_user_can('administrator')))
			{
				if (isset($table['type']) && $table['type'] == 1) // select
				{
					$current_value = esc_attr(get_post_meta($post->ID,$table['meta_key'],true));
					$code = '<select name="wats_select_cf_'.$table['meta_key'].'" id="wats_select_cf_'.$table['meta_key'].'" size="1" >';
					$values = $table['values'];
					foreach ($values as $key2 => $value)
					{
						$code .= '<option value="'.$key2.'"';
						if ($current_value == $key2)
							$code .= ' selected';
						$code .= '>'.esc_html($value).'</option>';
					}
					$code .= '</select>';
				}
				else if (isset($table['type']) && $table['type'] == 2) // datepicker
				{
					$datefield = esc_attr(get_post_meta($post->ID,$table['meta_key'],true));
					$custom_value = strlen($datefield) ? date('m/d/Y',strtotime($datefield)) : '';
					$code = '<input type="text" name="wats_cf_datepicker_'.$table['meta_key'].'" id="wats_cf_datepicker_'.$table['meta_key'].'" value="'.$custom_value.'" />';
				}
				else
				{
					$custom_value = esc_attr(get_post_meta($post->ID,$table['meta_key'],true));
					$code = '<input type="text" name="wats_cf_'.$table['meta_key'].'" id="wats_cf_'.$table['meta_key'].'" value="'.$custom_value.'" />';
				}
				$output .= '<label class="wats_label">'.esc_html($table['name']).' : </label>'.$code.'<br /><br />';
			}
		}
		else
		{
			if (($view == 1 && ($table['fsf'] == 4 || ($table['fsf'] == 5 && current_user_can('administrator'))))
			|| ($view == 0 && ($table['ftuf'] == 4 || ($table['ftuf'] == 5 && current_user_can('administrator')))))
			{
				$output .= '<div class="wats_frontend_ticket_custom_field" id="div_wats_cf_'.$table['meta_key'].'">';
				if (isset($table['type']) && $table['type'] == 1) // select
				{
					$code = '<select name="wats_select_cf_'.$table['meta_key'].'" id="wats_select_cf_'.$table['meta_key'].'" size="1" >';
					$values = $table['values'];
					$selected_value = is_object($post) ? esc_attr(get_post_meta($post->ID,$table['meta_key'],true)) : $table['default_value'];
					foreach ($values as $key2 => $value)
					{
						$code .= '<option value="'.$key2.'"';
						if ($selected_value == $key2)
							$code .= ' selected';
						$code .= '>'.esc_html($value).'</option>';
					}
					$code .= '</select>';
				}
				else if (isset($table['type']) && $table['type'] == 2) // datepicker
				{
					$datefield = is_object($post) ? esc_attr(get_post_meta($post->ID,$table['meta_key'],true)) : '';
					$custom_value = strlen($datefield) ? date('m/d/Y',strtotime($datefield)) : '';
					$code = '<input type="text" name="wats_cf_datepicker_'.$table['meta_key'].'" id="wats_cf_datepicker_'.$table['meta_key'].'" value="'.$custom_value.'" />';
				}
				else
				{
					$custom_value = is_object($post) ? esc_attr(get_post_meta($post->ID,$table['meta_key'],true)) : '';
					$code = '<input type="text" name="wats_cf_'.$table['meta_key'].'" id="wats_cf_'.$table['meta_key'].'" value="'.$custom_value.'" />';
				}
				$output .= '<label class="wats_label">'.esc_html($table['name']).' : </label>'.$code.'</div><br />';
			}
		}
	}
	
	if ($wats_ticket_assign == 1 || ($wats_ticket_assign == 2 && $user_can_assign == 1))
	{
		if ($view == 1)
			$output .= '<div class="wats_select_ticket_owner_frontend">';
		
		if ($view == 0 && !is_admin())
		{
			$output .= wp_nonce_field('wats-single-ticket','_wpnonce_wats_single_ticket',true,false);
			$output .= '<div class="wats_select_ticket_owner_frontend_update_form">';
		}
		
		$output .= '<label class="wats_label">'.__('Ticket owner','WATS').' : </label>';
		if (!isset($wats_settings['drop_down_user_selector_format']) || $wats_settings['drop_down_user_selector_format'] == 0)
		{
			if ($wats_settings['ticket_assign_user_list'] == 0)
			{
				$userlist = wats_build_user_list(__("None",'WATS'),0);
			}
			else if ($wats_settings['ticket_assign_user_list'] == 1)
			{
				$userlist = wats_build_user_list(__("None",'WATS'),'administrator');
				if (is_object($post) && $post->ID && !in_array(get_the_author(),$userlist))
				{
					$namelist = wats_build_formatted_name(get_the_author_meta('ID'));
					foreach ($namelist AS $login => $name)
						$userlist[$login] = $name;
				}
			}
			else if ($wats_settings['ticket_assign_user_list'] == 2)
			{
				$userlist = wats_build_user_list(__("None",'WATS'),'wats_ticket_ownership');
				if (is_object($post) && $post->ID && !in_array(get_the_author(),$userlist))
				{
					$namelist = wats_build_formatted_name(get_the_author_meta('ID'));
					foreach ($namelist AS $login => $name)
						$userlist[$login] = $name;
				}
			}
			else if ($wats_settings['ticket_assign_user_list'] == 3)
			{
				$namelist = wats_build_user_list(__("None",'WATS'),'wats_ticket_ownership');
				$namelist = array_merge($namelist,wats_build_user_list(0,'administrator'));
				foreach ($namelist AS $login => $name)
					$userlist[$login] = $name;
			}
			
			$output .= '<select name="wats_select_ticket_owner" id="wats_select_ticket_owner" class="wats_select">';
			foreach ($userlist AS $userlogin => $username)
			{
				$output .= '<option value="'.$userlogin.'" ';
				if ($userlogin === $ticket_owner) $output .= 'selected';
				$output .= '>'.$username.'</option>';
			}
			$output .= '</select><br /><br />';
		}
		else
		{
			if ($view != 1)
			{
				$ticket_owner_formatted = get_user_by('login',$ticket_owner);
				if (is_object($ticket_owner_formatted))
				{
					$ticket_owner_formatted = wats_build_formatted_name($ticket_owner_formatted->ID);
					$ticket_owner_formatted  = $ticket_owner_formatted[$ticket_owner];
					$output .= '<input type="text" id="wats_select_ticket_owner_ac" name="wats_select_ticket_owner_ac" value="'.$ticket_owner_formatted.'" /><br />';
					$output .= '<input type="hidden" id="wats_select_ticket_owner" name="wats_select_ticket_owner" value="'.$ticket_owner.'" /><br />';
				}
				else
				{
					$output .= '<input type="text" id="wats_select_ticket_owner_ac" name="wats_select_ticket_owner_ac" value="'.__('None','WATS').'" /><br />';
					$output .= '<input type="hidden" id="wats_select_ticket_owner" name="wats_select_ticket_owner" value="0" /><br />';
				}
			}
			else
			{
				$output .= '<input type="text" id="wats_select_ticket_owner_ac" name="wats_select_ticket_owner_ac" value="'.__('None','WATS').'" /><br />';
				$output .= '<input type="hidden" id="wats_select_ticket_owner" name="wats_select_ticket_owner" value="0" /><br />';
			}
		}
		
		if ($view == 1 || ($view == 0 && !is_admin()))
			$output .= '</div>';
	}
	
	if (is_object($post))
		setup_postdata($post);

	if (is_admin())
		$output .= wp_nonce_field('wats-edit-ticket','_wpnonce_wats_edit_ticket',true,false)."\n";

	if (((is_admin() || $view == 1) && current_user_can('administrator') && $wats_settings['call_center_ticket_creation'] == 1) || (!is_admin() && $view == 0 && current_user_can('administrator') && $wats_settings['call_center_ticket_update'] == 1))
	{
		if (is_object($post) && is_admin())
		{
			if ($post->post_author === '0')
				$selected_login = $current_user->user_login;
			else
				$selected_login = get_the_author_meta('user_login', $post->post_author);
		}
		else
			$selected_login = $current_user->user_login;

		if (!is_admin() && $view == 0 && current_user_can('administrator') && $wats_settings['call_center_ticket_update'] == 1)
			$output .= '<div id="wats_div_ticket_updater"><label class="wats_label">'.__('Ticket updater : ','WATS').'</label>';
		else
			$output .= '<div id="wats_div_ticket_originator"><label class="wats_label">'.__('Ticket originator : ','WATS').'</label>';
		
		if (!isset($wats_settings['drop_down_user_selector_format']) || $wats_settings['drop_down_user_selector_format'] == 0)
		{
			if ($wats_settings['profile_company_enabled'] == 1 && function_exists('wats_build_company_list'))
			{
				$company_list = wats_build_company_list(2);
				$my_company = get_user_meta(wats_get_user_ID_from_user_login($selected_login),$wats_settings['company_meta_key_profile'],true);
				if ($my_company == '')
					$my_company = 0;
				$output .= '<br /><br /><label class="wats_label">+ '.__('Company','WATS').' : </label>';
				$output .= '<select name="wats_company_list" id="wats_company_list">';
				foreach ($company_list AS $key => $value)
				{
					$output .= '<option value="'.esc_attr($key).'"';
					if ($my_company === $key) 
						$output .= " selected";
					if ($key == '0')
						$output .= '>'.esc_html($value).'</option>';
					else
						$output .= '>'.esc_html($key).'</option>';
				}
				$output .= '</select>';
				if (!is_admin() && $view == 0 && current_user_can('administrator') && $wats_settings['call_center_ticket_update'] == 1)
					$output .= '<br /><br /><div id="wats_div_ticket_updater_from_company"><label class="wats_label">+ '.__('User','WATS').' : </label>';
				else
					$output .= '<br /><br /><div id="wats_div_ticket_originator_from_company"><label class="wats_label">+ '.__('User','WATS').' : </label>';
				$userlist = wats_build_user_list_from_company(0,0,$my_company);
			}
			else
			{
				$userlist = wats_build_user_list(0,0);
			}
			
			if (!is_admin() && $view == 0 && current_user_can('administrator') && $wats_settings['call_center_ticket_update'] == 1)
				$output .= '<select name="wats_select_ticket_updater" id="wats_select_ticket_updater" class="wats_select">';
			else
				$output .= '<select name="wats_select_ticket_originator" id="wats_select_ticket_originator" class="wats_select">';

			foreach ($userlist AS $userlogin => $username)
			{
				$output .= '<option value="'.$userlogin.'" ';
				if ($selected_login == $userlogin) $output .= " selected";
				$output .= '>'.$username.'</option>';
			}
			$output .=  '</select>';
			
			if ($wats_settings['profile_company_enabled'] == 1 && function_exists('wats_build_company_list'))
				$output .= '</div>';
		}
		else
		{
			$selected_login_formatted = get_user_by('login',$selected_login);
			if (is_object($selected_login_formatted))
			{
				$selected_login_formatted = wats_build_formatted_name($selected_login_formatted->ID);
				$selected_login_formatted  = $selected_login_formatted[$selected_login];
				if (!is_admin() && $view == 0 && current_user_can('administrator') && $wats_settings['call_center_ticket_update'] == 1)
				{
					$output .= '<input type="text" id="wats_select_ticket_updater_ac" name="wats_select_ticket_updater_ac" value="'.$selected_login_formatted.'" /><br />';
					$output .= '<input type="hidden" id="wats_select_ticket_updater" name="wats_select_ticket_updater" value="'.$selected_login.'" />';
				}
				else
				{
					$output .= '<input type="text" id="wats_select_ticket_originator_ac" name="wats_select_ticket_originator_ac" value="'.$selected_login_formatted.'" /><br />';
					$output .= '<input type="hidden" id="wats_select_ticket_originator" name="wats_select_ticket_originator" value="'.$selected_login.'" />';
				}
			}
		}
		$output .= '</div><br />';
	}
	else if (is_admin())
	{
		if ($post->ID)
		{
			$output .= '<label class="wats_label">'.__('Ticket originator : ','WATS').'</label>';
			$output .= get_the_author();
		}
		
	}
		
	if (is_admin())
	{
		$ticket_author_name = get_post_meta($post->ID,'wats_ticket_author_name',true);
		if ($ticket_author_name)
			$output .= '<br /><br /><label class="wats_label">'.__('Ticket author name : ','WATS').'</label>'.$ticket_author_name;
		
		$ticket_author_email = get_post_meta($post->ID,'wats_ticket_author_email',true);
		if ($ticket_author_email)
			$output .= '<br /><br /><label class="wats_label">'.__('Ticket author email : ','WATS').'</label>'.'<a href="mailto:'.$ticket_author_email.'">'.$ticket_author_email.'</a>';
		
		$ticket_author_url = get_post_meta($post->ID,'wats_ticket_author_url',true);
		if ($ticket_author_url)
			$output .= '<br /><br /><label class="wats_label">'.__('Ticket author url : ','WATS').'</label>'.'<a href="'.$ticket_author_url.'">'.$ticket_author_url.'</a>';
		$output .= '<br /><br />';
	}
	
	if ((current_user_can('administrator') && $wats_settings['ticket_notification_custom_list'] == 2) || $wats_settings['ticket_notification_custom_list'] == 1)
	{
		$ticket_update_mailing_list = isset($post) ? get_post_meta($post->ID,'wats_update_notification_mailing_list',true) : '';
		$output .= '<br /><div id="wats_div_ticket_update_notification_mailing_list"><label class="wats_label">'.__('Update notification mailing list : ','WATS').'</label><input type="text" name="wats_update_notification_mailing_list" id="wats_update_notification_mailing_list" value="'.$ticket_update_mailing_list.'" size="30" class="regular-text" /><br /><br /></div>';
	}
	
	if ($view == 0 && current_user_can('administrator'))
	{
		if (!is_admin() && $wats_settings['internal_comment_visibility'] == 1)
			$output .= 	'<input style="width:20px;" type="checkbox" id="wats_internal_update" name="wats_internal_update"> '.__('Only administrators can view this update','WATS').'<br /><br />';

		if ((!is_admin() || $pagenow != 'post-new.php') && ($wats_settings['ticket_update_notification_all_tickets'] == 1 || $wats_settings['ticket_update_notification_my_tickets'] == 1 || $wats_settings['ticket_notification_custom_list'] != 0))
			$output .= 	'<input style="width:20px;" type="checkbox" id="wats_update_no_notification" name="wats_update_no_notification"> '.__('Don\'t fire any notification for this update','WATS').'<br /><br />';
	}
	
	if ($view == 1)
		return ($output);
	else
		echo $output;
}

?>