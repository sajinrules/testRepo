<?php
header("Content-Type: application/javascript");
?>
jQuery(document).ready(function() {
	jQuery("input[name*='wats_cf_datepicker']").datepicker({dateFormat : 'mm/dd/yy'});
	
    jQuery('#wats_company_list').change(function() {
	
		var idcompany = jQuery('#wats_company_list option:selected').val();
		if (jQuery("#_wpnonce_wats_edit_ticket").val())
		{
			var nonce_value = jQuery("#_wpnonce_wats_edit_ticket").val();
			var type = 'adminticketeditauthorlist';
		}
		else
		{
			var nonce_value = jQuery("#_wpnonce_ticket_submit_form").val();
			var type = 'fsfauthorlist';
		}

		jQuery.post(ajaxurl, {action:"wats_get_user_list_from_company", _ajax_nonce:nonce_value, idcompany:idcompany, type:type},
			function(res)
			{
				var message_result = eval('(' + res + ')');
				if (message_result.success == "FALSE")
				{
					alert(message_result.error);
				}
				else
				{
					jQuery('#wats_div_ticket_originator_from_company').html(message_result.error);
				}
				
				return false;
			});
			
		return false;
	});
	
	return false;
});