<?php
header("Content-Type: application/javascript");
?>
jQuery(document).ready(function() {
	function wats_options_editable_init()
	{
		jQuery('.wats_editable').editable(
		{
			onEdit:wats_options_editable_begin,
			onSubmit:wats_options_editable_end,
			submitBy:'click'
		});
		
		return;
	}
	
	wats_options_editable_init();
	function wats_options_editable_begin()
	{    
		jQuery(this).addClass("wats_editableaccept");
	}
	
	function wats_options_editable_end(content)
	{
		jQuery(this).removeClass("wats_editableaccept");
		if (content.current != content.previous)
		{
			var id = jQuery(this);
			var newvalue = content.current;
			var previousvalue = content.previous;
			jQuery.post(ajaxurl, {action:"wats_admin_update_company_entry", _ajax_nonce:jQuery("#_wpnonce").val(), 'cookie': encodeURIComponent(document.cookie), newvalue:newvalue, previousvalue:previousvalue},
			function(res)
			{
				var message_result = eval('(' + res + ')');
				alert(message_result.error);
				if (message_result.success == "FALSE")
				{
					jQuery(id).html(content.previous);
				}
				else
				{
					jQuery(id).html(message_result.newvalue);
				}
			});
		}
	}
	
    jQuery('#add_new_company').click(function() {
		jQuery('#add_new_company').attr('disabled','disabled');
		
		var companyvalue = jQuery("#company_name").val();
		var slavalue = jQuery("#sla_list option:selected").val();
		var uservalue = jQuery("#user_list option:selected").val();
		wats_loading(document.getElementById("resultaddcompany"),watsmsg[4]);

		jQuery.post(ajaxurl, {action:"wats_admin_insert_company_entry", _ajax_nonce:jQuery("#_wpnonce").val(), 'cookie': encodeURIComponent(document.cookie), companyvalue:companyvalue, slavalue:slavalue, uservalue:uservalue},
		function(res)
		{
			jQuery('#add_new_company').removeAttr('disabled');
			var message_result = eval('(' + res + ')');
			if (message_result.success == "TRUE")
			{
				
			}
			wats_stop_loading(document.getElementById("resultaddcompany"),message_result.error);
		});
		return false;
	});

	jQuery('#remove_company').click(function() {
		if (jQuery("input[name=company_check]").length == 0)
			wats_stop_loading(document.getElementById("resultsupcompany"),watsmsg[0]);
		else if (jQuery("input[name=company_check]:checked").length == 0)
			wats_stop_loading(document.getElementById("resultsupcompany"),watsmsg[1]);
		
	    jQuery("input[name=company_check]:checked").each(function()
		{
		    if (this.checked == true)
			{
				jQuery('#remove_company').attr('disabled','disabled');
				var companyvalue = jQuery(this).parent().prev().prev().html();
				var nodetoremove = this.parentNode;
				jQuery.post(ajaxurl, {action:"wats_admin_remove_company_entry", _ajax_nonce:jQuery("#_wpnonce").val(), 'cookie': encodeURIComponent(document.cookie), companyvalue:companyvalue},
				function(res)
				{
					jQuery('#remove_company').removeAttr('disabled');
					var message_result = eval('(' + res + ')');
					wats_stop_loading(document.getElementById("resultsupcompany"),message_result.error);
					if (message_result.success == "TRUE")
					{
						parenttoremove = nodetoremove.parentNode;
						parenttoremove.parentNode.removeChild(parenttoremove);
					}
					if (jQuery("input[name=company_check]").length == 0)
						wats_js_add_blank_cell("tablecompany",3,watsmsg[2]);
				});
			}
		});
		return false;
	});
	
	jQuery('#associate_sla').click(function() {
		jQuery('#associate_sla').attr('disabled','disabled');
		
		var slavalue = jQuery("#sla_list_company option:selected").val();
		var companyvalue = jQuery("#wats_company_list option:selected").val();
		wats_loading(document.getElementById("resultassignsla"),watsmsg[4]);

		jQuery.post(ajaxurl, {action:"wats_admin_associate_sla_with_company", _ajax_nonce:jQuery("#_wpnonce").val(), 'cookie': encodeURIComponent(document.cookie), companyvalue:companyvalue, slavalue:slavalue},
		function(res)
		{
			jQuery('#associate_sla').removeAttr('disabled');
			var message_result = eval('(' + res + ')');
			wats_stop_loading(document.getElementById("resultassignsla"),message_result.error);
		});
		return false;
	});
	
	
	return false;
});