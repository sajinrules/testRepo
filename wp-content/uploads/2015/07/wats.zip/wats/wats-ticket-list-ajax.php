<?php
header("Content-Type: application/javascript");
?>
jQuery(document).ready(function() {

	jQuery("input[name*='wats_cf_datepicker']").datepicker({dateFormat : 'mm/dd/yy'});

	if (/msie/.test(navigator.userAgent.toLowerCase()))
		jQuery('.wats_select').css("width","auto");
		
	wats_js_page_list_bind();

    jQuery('#filter').click(function() {
			jQuery('#filter').attr('disabled','disabled');
			var view = 1;
			
			var wats_input_ticket_number_tl = jQuery('#wats_input_ticket_number_tl').val();
			var wats_select_ticket_type_tl = jQuery('#wats_select_ticket_type_tl option:selected').val();
			var wats_select_ticket_priority_tl = jQuery('#wats_select_ticket_priority_tl option:selected').val();
			var wats_select_ticket_status_tl = jQuery('#wats_select_ticket_status_tl option:selected').val();
			var wats_select_ticket_status_operator = jQuery('#wats_select_ticket_status_operator option:selected').val();
			if (jQuery('#wats_select_ticket_product_tl option:selected').val())
				var wats_select_ticket_product_tl = jQuery('#wats_select_ticket_product_tl option:selected').val();
			else
				var wats_select_ticket_product_tl = 0;

			if (jQuery('#wats_select_ticket_author_tl option:selected').val())
				var wats_select_ticket_author_tl = jQuery('#wats_select_ticket_author_tl option:selected').val();
			else if (jQuery('#wats_select_ticket_author_tl').val())
				var wats_select_ticket_author_tl = jQuery('#wats_select_ticket_author_tl').val();
			else
				var wats_select_ticket_author_tl = 0;
		
			if (jQuery('#wats_select_ticket_author_meta_value_tl option:selected').val())
				var wats_select_ticket_author_meta_value_tl = jQuery('#wats_select_ticket_author_meta_value_tl option:selected').val();
			else
				var wats_select_ticket_author_meta_value_tl = 0;

			if (jQuery('#wats_select_ticket_owner_tl option:selected').val())
				var wats_select_ticket_owner_tl = jQuery('#wats_select_ticket_owner_tl option:selected').val();
			else if (jQuery('#wats_select_ticket_owner_tl').val())
				var wats_select_ticket_owner_tl = jQuery('#wats_select_ticket_owner_tl').val();
			else
				var wats_select_ticket_owner_tl = 0;

			var categoryfilter = jQuery('#categoryfilter').val();
			var categorylistfilter = jQuery('#categorylistfilter').val();
			
			if (jQuery('#wats_page_list_tl option:selected').val())
				var wats_page_list_tl = jQuery('#wats_page_list_tl option:selected').val();
			else
				var wats_page_list_tl = 0;
			
			if (jQuery('#wats_tickets_per_page_list_tl option:selected').val())
				var wats_tickets_per_page_list_tl = jQuery('#wats_tickets_per_page_list_tl option:selected').val();
			else
				var wats_tickets_per_page_list_tl = 0;
			
			var customfieldlist = new Array();
			var j = 0;
			jQuery("input[name*='wats_cf']").each(function()
			{
				customfieldlist[j] = {};
				customfieldlist[j][jQuery(this).attr("id")] = jQuery(this).val();
				j++;
			});
			jQuery("select[name*='wats_select_cf']").each(function()
			{
				customfieldlist[j] = {};
				customfieldlist[j][jQuery(this).attr("id")] = jQuery(this).children(':selected').val();
				j++;
			});
			liste = JSON.stringify(customfieldlist);
			
			if (jQuery('#wats_select_custom_query_tl option:selected').val())
				var wats_select_custom_query_tl = jQuery('#wats_select_custom_query_tl option:selected').val();
			else
				var wats_select_custom_query_tl = -1;
			
			wats_loading(document.getElementById("resultticketlist"),watsmsg[0]);
			
			jQuery.post(ajaxurl, {action:"wats_ticket_list_ajax_processing", _ajax_nonce:jQuery("#_wpnonce_ticket_list").val(), view:view, wats_select_ticket_type_tl:wats_select_ticket_type_tl, wats_select_ticket_priority_tl:wats_select_ticket_priority_tl, wats_select_ticket_status_tl:wats_select_ticket_status_tl, wats_select_ticket_product_tl:wats_select_ticket_product_tl, wats_select_ticket_author_tl:wats_select_ticket_author_tl, wats_select_ticket_owner_tl:wats_select_ticket_owner_tl, wats_select_ticket_author_meta_value_tl:wats_select_ticket_author_meta_value_tl, categoryfilter:categoryfilter, categorylistfilter:categorylistfilter, wats_select_ticket_status_operator:wats_select_ticket_status_operator, liste:liste, wats_page_list_tl:wats_page_list_tl, wats_tickets_per_page_list_tl:wats_tickets_per_page_list_tl, wats_input_ticket_number_tl:wats_input_ticket_number_tl, wats_select_custom_query_tl:wats_select_custom_query_tl},
			function(res)
			{
				jQuery('#filter').removeAttr('disabled');
				wats_stop_loading(document.getElementById("resultticketlist"),res);
				jQuery('#tableticket').trigger('destroy');
				jQuery('#tableticket').tablesorter();
				jQuery('#tableticket').bind("sortEnd",function(){wats_js_ticket_list_rearrange_tr();});
				wats_js_page_list_bind();
				wats_js_ticket_list_bind_edit_ticket_row();
				wats_js_ticket_list_bind_expand_ticket_row();
			});
		
		return false;
	});

	if (jQuery('#tableticket').length > 0)
	{
		
		jQuery.tablesorter.addParser({
            id: 'ages',
			is: function(s) { return false; },
			format: function(s) {
			var result = 0;
			if (s.length > 0)
			{
				var a=s.split(" ");
				result = parseInt(a[0]) * 60 * 60 + parseInt(a[2]) * 60 + parseInt(a[4]);
			}
			return result;
			},
			type: 'numeric'
		});
		jQuery('#tableticket').tablesorter();
		jQuery('#tableticket').bind("sortEnd",function(){wats_js_ticket_list_rearrange_tr();});
	}

	function wats_js_page_list_bind()
	{
		jQuery('#wats_tickets_per_page_list_tl').change(function() {
			jQuery('#wats_page_list_tl').val(1);
			jQuery('#filter').click();
			return false;
		});

	
		jQuery('#wats_page_list_tl').change(function() {
			jQuery('#filter').click();
			return false;
		});
	
		return false;
	}
	
	var wats_select_ticket_author_tl_ac = 0;
	if (jQuery("#wats_select_ticket_author_tl_ac").is("input"))
	{
		jQuery('#wats_select_ticket_author_tl_ac').autocomplete({
							source: function(request,response)  {
							jQuery.ajax({
								url: ajaxurl+"?action=wats_ajax_frontend_get_user_list",
								dataType: "json",
								data: {
									value:jQuery('#wats_select_ticket_author_tl_ac').val(),
									_ajax_nonce:jQuery("#_wpnonce_ticket_list").val(),
									type:'ftlauthorlist',
									'cookie': encodeURIComponent(document.cookie)
								},
								success: function(data) {
									if (jQuery.isEmptyObject(data) == true)
										jQuery('#wats_select_ticket_author_tl').val("0");
									response(
									jQuery.map(data, function(item)
									{ return{value:item.label,label:item.label,hidden:item.value} }));
								}
								});
							},
							select: function(event,ui) {
								wats_select_ticket_author_tl_ac = 1;
								jQuery('#wats_select_ticket_author_tl').val(ui.item.hidden);
							},
							close : function(event,ui) {
								if (wats_select_ticket_author_tl_ac == 0)	
									jQuery('#wats_select_ticket_author_tl').val("0");
								wats_select_ticket_author_tl_ac = 0;
							},
							minLength:3,
							delay:300
		});
	}
	
	var wats_select_ticket_owner_tl_ac = 0;
	if (jQuery("#wats_select_ticket_owner_tl_ac").is("input"))
	{
		jQuery('#wats_select_ticket_owner_tl_ac').autocomplete({
							source: function(request,response)  {
							jQuery.ajax({
								url: ajaxurl+"?action=wats_ajax_frontend_get_user_list",
								dataType: "json",
								data: {
									value:jQuery('#wats_select_ticket_owner_tl_ac').val(),
									_ajax_nonce:jQuery("#_wpnonce_ticket_list").val(),
									type:'ftlownerlist',
									'cookie': encodeURIComponent(document.cookie)
								},
								success: function(data) {
									if (jQuery.isEmptyObject(data) == true)
										jQuery('#wats_select_ticket_owner_tl').val("0");
									response(
									jQuery.map(data, function(item)
									{ return{value:item.label,label:item.label,hidden:item.value} }));
								}
								});
							},
							select: function(event,ui) {
								wats_select_ticket_owner_tl_ac = 1;
								jQuery('#wats_select_ticket_owner_tl').val(ui.item.hidden);
							},
							close : function(event,ui) {
								if (wats_select_ticket_owner_tl_ac == 0)	
									jQuery('#wats_select_ticket_owner_tl').val("0");
								wats_select_ticket_owner_tl_ac = 0;
							},
							minLength:3,
							delay:300
		});
	}
	
	jQuery('#wats_select_ticket_type_tl').change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_select_ticket_status_tl').change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_select_ticket_status_operator').change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});	
	
	jQuery('#wats_select_ticket_priority_tl').change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_select_ticket_product_tl').change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_select_ticket_author_tl').change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_select_ticket_author_meta_value_tl').change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_select_ticket_owner_tl').change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery("select[name*='wats_select_cf']").change(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_select_ticket_author_tl_ac').keyup(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_select_ticket_owner_tl_ac').keyup(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery('#wats_input_ticket_number_tl').keyup(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});
	
	jQuery("input[name*='wats_cf']").keyup(function() {
		jQuery('#wats_select_custom_query_tl').val(-1);
		return false;
	});

	jQuery('#wats_select_custom_query_tl').change(function() {
		var wats_select_custom_query_tl = jQuery('#wats_select_custom_query_tl option:selected').val();
		if (wats_select_custom_query_tl > -1)
		{
			jQuery('#filter').attr('disabled','disabled');
			var view = 3;
			
			var categoryfilter = jQuery('#categoryfilter').val();
			var categorylistfilter = jQuery('#categorylistfilter').val();
			
			if (jQuery('#wats_page_list_tl option:selected').val())
				var wats_page_list_tl = jQuery('#wats_page_list_tl option:selected').val();
			else
				var wats_page_list_tl = 0;
			
			if (jQuery('#wats_tickets_per_page_list_tl option:selected').val())
				var wats_tickets_per_page_list_tl = jQuery('#wats_tickets_per_page_list_tl option:selected').val();
			else
				var wats_tickets_per_page_list_tl = 0;
			
			wats_loading(document.getElementById("resultticketlist"),watsmsg[0]);
			
			jQuery.post(ajaxurl, {action:"wats_ticket_list_ajax_processing", _ajax_nonce:jQuery("#_wpnonce_ticket_list").val(), view:view, categoryfilter:categoryfilter, categorylistfilter:categorylistfilter, wats_page_list_tl:wats_page_list_tl, wats_tickets_per_page_list_tl:wats_tickets_per_page_list_tl, wats_select_custom_query_tl:wats_select_custom_query_tl},
			function(res)
			{
				jQuery('#filter').removeAttr('disabled');
				wats_stop_loading(document.getElementById("resultticketlist"),res);
				jQuery('#tableticket').trigger('destroy');
				jQuery('#tableticket').tablesorter();
				jQuery('#tableticket').bind("sortEnd",function(){wats_js_ticket_list_rearrange_tr();});
				wats_js_page_list_bind();
				wats_js_ticket_list_bind_edit_ticket_row();
				wats_js_ticket_list_bind_expand_ticket_row();
			});
		
			return false;
		}
			
		return false;
	});
	
function wats_js_ticket_list_bind_edit_ticket_row()
{
	jQuery('[name^=wats_edit_ticket_row]').click(function() {
		jQuery('[name^=wats_edit_ticket_row]').attr('disabled','disabled');
		idvalue = jQuery(this).attr('name').substring(21);
		
		jQuery.post(ajaxurl, {action:"wats_ticket_list_get_ticket_row", _ajax_nonce:jQuery("#_wpnonce_ticket_list").val(), 'cookie': encodeURIComponent(document.cookie), idvalue:idvalue},
				function(res)
				{
					var message_result = eval('(' + res + ')');

					if (message_result.success == "TRUE")
					{
						jQuery('#wats_edit_ticket_row_'+idvalue).parent('td').parent('tr').html(message_result.output);
						wats_js_ticket_list_bind_save_ticket_row();
						wats_js_ticket_list_bind_expand_ticket_row();
						jQuery('[name^=wats_edit_ticket_row]').unbind('click');
					}
					else
						wats_stop_loading(document.getElementById("resultticketlist"),message_result.error);
				});
		return false;
	});
	
	return false;
}

function wats_js_ticket_list_bind_save_ticket_row()
{
	jQuery('[name^=wats_save_ticket_row]').click(function() {
		idvalue = jQuery(this).attr('name').substring(21);
	
		if (jQuery('#wats_select_ticket_type_'+idvalue+' option:selected').val())
			var idtype = jQuery('#wats_select_ticket_type_'+idvalue+' option:selected').val();
		else
			var idtype = 0;
		
		if (jQuery('#wats_select_ticket_priority_'+idvalue+' option:selected').val())
			var idpriority = jQuery('#wats_select_ticket_priority_'+idvalue+' option:selected').val();
		else
			var idpriority = 0;
		
		if (jQuery('#wats_select_ticket_status_'+idvalue+' option:selected').val())
			var idstatus = jQuery('#wats_select_ticket_status_'+idvalue+' option:selected').val();
		else
			var idstatus = 0;
			
		if (jQuery('#wats_select_ticket_product_'+idvalue+' option:selected').val())
			var idproduct = jQuery('#wats_select_ticket_product_'+idvalue+' option:selected').val();
		else
			var idproduct = 0;
		
		jQuery.post(ajaxurl, {action:"wats_ticket_list_update_ticket_row", _ajax_nonce:jQuery("#_wpnonce_ticket_list").val(), 'cookie': encodeURIComponent(document.cookie), idvalue:idvalue, idtype:idtype, idpriority:idpriority, idstatus:idstatus, idproduct:idproduct},
		function(res)
		{
			jQuery('[name^=wats_edit_ticket_row]').removeAttr('disabled');
			var message_result = eval('(' + res + ')');
			if (message_result.success == "TRUE")
			{
				jQuery('[name^=wats_save_ticket_row]').unbind('click');
				jQuery('#wats_save_ticket_row_'+idvalue).parent('td').parent('tr').html(message_result.output);
				jQuery('#tableticket').trigger('update');
				wats_js_ticket_list_bind_edit_ticket_row();
				wats_js_ticket_list_bind_expand_ticket_row();
			}
			wats_stop_loading(document.getElementById("resultticketlist"),message_result.error);
		});
		return false;
	});
	
	return false;
}

function wats_js_ticket_list_bind_expand_ticket_row()
{
	jQuery('[name^=wats_expand_ticket_row]').unbind('click');
	jQuery('[name^=wats_expand_ticket_row]').click(function() {
		if (jQuery(this).parent('td').parent('tr').next().css('display') == 'none')
			jQuery(this).parent('td').parent('tr').next().css('display','table-row');
		else
			jQuery(this).parent('td').parent('tr').next().css('display','none');

		return false;
	});
	
	return false;
}

function wats_js_ticket_list_rearrange_tr()
{
	jQuery("input[name*='wats_expand_ticket_row_']").each(function()
	{
		name = this.name.substring(23);
		row = jQuery('#wats_tr_expanded_'+name);
		jQuery(this).parents("tr").after(row);
		return;
	});
	
	return false;
}
	
	wats_js_ticket_list_bind_expand_ticket_row();
	wats_js_ticket_list_bind_edit_ticket_row();
	
	return false;
});