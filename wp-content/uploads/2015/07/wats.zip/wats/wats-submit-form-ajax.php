<?php
header("Content-Type: application/javascript");
?>
jQuery(document).ready(function() {

	jQuery("input[name*='wats_cf_datepicker']").datepicker({dateFormat : 'mm/dd/yy'});

	/*var wats_custom_uploader;
	jQuery('#wats_upload_button').click(function(e) {
		e.preventDefault();
 
		if (wats_custom_uploader)
		{
			wats_custom_uploader.open();
			return;
		}

		wats_custom_uploader = wp.media.frames.file_frame = wp.media({
			title: 'Choose Image',
			button: {
					text: 'Choose Image'
					},
			multiple: false
		});

		wats_custom_uploader.on('select', function() {
			attachment = wats_custom_uploader.state().get('selection').first().toJSON();
			var url = '';
			url = attachment['url'];
			jQuery('#wats_upload_files').val(url);
		});

		wats_custom_uploader.open();
	});*/

    jQuery('#wats_submit_ticket').click(function() {
			jQuery('#wats_submit_ticket').attr('disabled','disabled');
			var view = 1;
			wats_loading(document.getElementById("resultticketsubmitform"),watsmsg[1]);
			var name = jQuery('#name').val();
			var email = jQuery('#email').val();
			var url = jQuery('#url').val();
			var ticket_title = jQuery('#ticket_title').val();
			if (typeof(tinymce) !== "undefined")
				tinymce.triggerSave();
			var ticket_content = jQuery('#ticketcontent').val();
			var idtype = jQuery('#wats_select_ticket_type option:selected').val();
			var idpriority = jQuery('#wats_select_ticket_priority option:selected').val();
			var idstatus = jQuery('#wats_select_ticket_status option:selected').val();
			if (jQuery('#wats_select_ticket_product'))
				var idproduct = jQuery('#wats_select_ticket_product option:selected').val();
			else
				var idproduct = 0;

			if (jQuery('#wats_select_ticket_owner option:selected').val())
				var idowner = jQuery('#wats_select_ticket_owner option:selected').val();
			else
				var idowner = jQuery('#wats_select_ticket_owner').val();

			if (jQuery('#wats_cat_list option:selected').val())
				var category = jQuery('#wats_cat_list option:selected').val();
			else
				var category = '';
			
			var customfieldlist = new Array();
			var j = 0;
			jQuery("input[name*='wats_cf']").each(function()
			{
				customfieldlist[j] = {};
				customfieldlist[j][jQuery(this).attr("id")] = jQuery(this).val();
				j++;
			});
			jQuery("select[name*='wats_select_cf']").each(function()
			{
				customfieldlist[j] = {};
				customfieldlist[j][jQuery(this).attr("id")] = jQuery(this).children(':selected').val();
				j++;
			});
			liste = JSON.stringify(customfieldlist);
			
			var author = 0;
			if (jQuery('#wats_select_ticket_originator option:selected').val())
				var author = jQuery('#wats_select_ticket_originator option:selected').val();
			else
				var author = jQuery('#wats_select_ticket_originator').val();
		
			var wats_update_notification_mailing_list = '';
			if (jQuery('#wats_update_notification_mailing_list'))
				var wats_update_notification_mailing_list = jQuery('#wats_update_notification_mailing_list').val();
		
			jQuery.post(ajaxurl, {action:"wats_ticket_submit_form_ajax_processing", _ajax_nonce:jQuery("#_wpnonce_ticket_submit_form").val(), view:view, name:name, email:email, url:url, ticket_title:ticket_title, ticket_content:ticket_content, idtype:idtype, idpriority:idpriority, idstatus:idstatus, idproduct:idproduct, idowner:idowner, category:category, liste:liste, author:author, wats_update_notification_mailing_list:wats_update_notification_mailing_list},
			function(res)
			{
				var message_result = eval('(' + res + ')');
				wats_stop_loading(document.getElementById("resultticketsubmitform"),message_result.message);
				jQuery('#wats_submit_ticket').removeAttr('disabled');
				jQuery('#wats_submit_ticket').trigger('wats_frontend_submission_form_submitted',message_result.result);
			});
		
		return false;
	});

	var selected_wats_select_ticket_owner_ac = 0;
	if (jQuery("#wats_select_ticket_owner_ac").is("input"))
	{
		jQuery('#wats_select_ticket_owner_ac').autocomplete({
							source: function(request,response)  {
							jQuery.ajax({
								url: ajaxurl+"?action=wats_ajax_frontend_get_user_list",
								dataType: "json",
								data: {
									value:jQuery('#wats_select_ticket_owner_ac').val(),
									_ajax_nonce:jQuery("#_wpnonce_ticket_submit_form").val(),
									type:'fsfownerlist',
									'cookie': encodeURIComponent(document.cookie)
								},
								success: function(data) {
									if (jQuery.isEmptyObject(data) == true)
										jQuery('#wats_select_ticket_owner').val("0");
									response(
									jQuery.map(data, function(item)
									{ return{value:item.label,label:item.label,hidden:item.value} }));
								}
								});
							},
							select: function(event,ui) {
								selected_wats_select_ticket_owner_ac = 1;
								jQuery('#wats_select_ticket_owner').val(ui.item.hidden);
							},
							close : function(event,ui) {
								if (selected_wats_select_ticket_owner_ac == 0)	
									jQuery('#wats_select_ticket_owner').val("0");
								selected_wats_select_ticket_owner_ac = 0;
							},
							minLength:3,
							delay:300
		});
	}
	
	var selected_wats_select_ticket_originator_ac = 0;
	if (jQuery("#wats_select_ticket_originator_ac").is("input"))
	{
		jQuery('#wats_select_ticket_originator_ac').autocomplete({
							source: function(request,response)  {
							jQuery.ajax({
								url: ajaxurl+"?action=wats_ajax_frontend_get_user_list",
								dataType: "json",
								data: {
									value:jQuery('#wats_select_ticket_originator_ac').val(),
									_ajax_nonce:jQuery("#_wpnonce_ticket_submit_form").val(),
									type:'fsfauthorlist',
									'cookie': encodeURIComponent(document.cookie)
								},
								success: function(data) {
									if (jQuery.isEmptyObject(data) == true)
										jQuery('#wats_select_ticket_originator').val("0");
									response(
									jQuery.map(data, function(item)
									{ return{value:item.label,label:item.label,hidden:item.value} }));
								}
								});
							},
							select: function(event,ui) {
								selected_wats_select_ticket_originator_ac = 1;
								jQuery('#wats_select_ticket_originator').val(ui.item.hidden);
							},
							close : function(event,ui) {
								if (selected_wats_select_ticket_originator_ac == 0)	
									jQuery('#wats_select_ticket_originator').val("0");
								selected_wats_select_ticket_originator_ac = 0;
							},
							minLength:3,
							delay:300
		});
	}
	
	return false;
});