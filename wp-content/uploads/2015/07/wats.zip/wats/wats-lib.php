<?php

/*****************************************/
/*                                       */
/* Fonction de log d'un message de debug */
/*                                       */
/*****************************************/

function wats_debug($msg)
{
	if (WATS_DEBUG)
	{
	    $today = date("d/m/Y H:i:s ");
	    $myFile = dirname(__file__) . "/debug.log";
	    $fh = fopen($myFile, 'a') or die("Can't open debug file. Please manually create the 'debug.log' file (inside the 'wats' directory) and make it writable.");
	    $ua_simple = preg_replace("/(.*)\s\(.*/","\\1",$_SERVER['HTTP_USER_AGENT']);
	    fwrite($fh, $today . " [from: ".$_SERVER['REMOTE_ADDR']."|$ua_simple] - " . $msg . "\n");
	    fclose($fh);
	}
}

/*******************************************/
/*                                         */
/* Fonction de vérification d'un numérique */
/*                                         */
/*******************************************/

function wats_is_numeric($i)
{
	return (preg_match("/^\d+$/", $i));
}

/*****************************************/
/*                                       */
/* Fonction de vérification d'une chaîne */
/*                                       */
/*****************************************/

function wats_is_string($i)
{
	if (WATS_VERIFY_STRING)
		return (preg_match("/^[\.\,\#\&\;\'\"\+\-\_\:?¿!¡()@ßÀÁÂÃÄÅÇČĎĚÈÉÊËÌÍÎÏŇÒÓÔÕÖŘŠŤÙÚÛÜŮÝŽکگچپژیàáâãäåçčďěèéêëìíîïňðòóôõöřšťùúûüůýÿžدجحخهعغفقثصضطكمنتاأللأبيسشظزوةىآلالآرؤءئa-zA-Z-\d ]+$/", $i));
	else
		return 1;
}

/**************************************************************/
/*                                       					  */
/* Fonction de vérification d'une chaîne avec carriage return */
/*                                                            */
/**************************************************************/

function wats_is_paragraph($i)
{
	if (WATS_VERIFY_STRING)
		return (preg_match("/^[\.\,\#\&\;\'\"\+\-\_\:\/?¿!¡()@ßÀÁÂÃÄÅÇČĎĚÈÉÊËÌÍÎÏŇÒÓÔÕÖŘŠŤÙÚÛÜŮÝŽکگچپژیàáâãäåçčďěèéêëìíîïňðòóôõöřšťùúûüůýÿžدجحخهعغفقثصضطكمنتاأللأبيسشظزوةىآلالآرؤءئa-zA-Z-\d\s ]+$/", $i));
	else
		return 1;
}

/****************************************************/
/*                                                  */
/* Fonction de vérification d'une lettre ou chiffre */
/*                                                  */
/****************************************************/

function wats_is_letter_or_number($i)
{

	return (preg_match("/^[a-zA-Z\d]+$/", $i));
}

/*****************************************/
/*                                       */
/* Fonction de vérification d'une lettre */
/*                                       */
/*****************************************/

function wats_is_letter($i)
{
	return (preg_match("/^[a-zA-Z]+$/", $i));
}

/***************************************/
/*                                     */
/* Fonction de vérification d'une date */
/* format 1 : yyyy-mm-dd               */
/* format 2 : mm/dd/yyyy               */
/*                                     */
/***************************************/

function wats_is_date($i,$format)
{
	if ($format == 1)
		return (preg_match("#^(\d{4})\-(\d{2})\-(\d{2})$#", $i));
	else
		return (preg_match("#^(\d{2})\/(\d{2})\/(\d{4})$#", $i));	
}

/*************************************************************/
/*                                                           */
/* Fonction pour remplir une drop down list sans echo direct */
/*                                                           */
/*************************************************************/

function wats_fill_drop_down_no_echo($type_array,$selected_value)
{
	$output = '';

    foreach ($type_array as $key => $value)
    {
		$output .= '<option value="'.$key.'"';
        if ($selected_value == $key) $output .= ' selected';
		$output .= '>'.$value.'</option>';
	}

    return $output;
}

/***************************************************/
/*                                                 */
/* Fonction de construction d'un tableau numérique */
/*                                                 */
/***************************************************/

function wats_build_numeric_array($first,$last)
{
	$temptable = array();
	for ($i = $first; $i <= $last; $i++)
	{
		$temptable[$i] = $i;
	}
	
	return $temptable;
}

/******************************************/
/*                                        */
/* Fonction de calcul du numéro de ticket */
/*                                        */
/******************************************/

function wats_get_ticket_number($postID)
{
	global $wats_settings;
	
	$number = get_post_meta($postID,'wats_ticket_number',true);
	if (($wats_settings['numerotation'] == 0) || !$number)
		$value = 0;
	else if ($wats_settings['numerotation'] == 1)
	{
		$padding = '';
		if ($number < 10)
			$padding = '0000';
		else if ($number < 100)
			$padding = '000';
		else if ($number < 1000)
			$padding = '00';
		else if ($number < 10000)
			$padding = '0';
		$value = get_the_time("ymd",$postID)."-".$padding.$number;
	}
	else if ($wats_settings['numerotation'] == 2)
		$value = $number;
		
	return $value;
}

/********************************************************/
/*                                                      */
/* Fonction de récupération du dernier numéro de ticket */
/*                                                      */
/********************************************************/

function wats_get_latest_ticket_number()
{
	global $wpdb;
	
	$value = $wpdb->get_var($wpdb->prepare("SELECT meta_value FROM $wpdb->postmeta WHERE meta_key = %s ORDER BY ABS(meta_value) DESC LIMIT 0,1",'wats_ticket_number'));

	if (!$value)
		$value = 0;
	
	return $value;
}

/*******************************************/
/*                                         */
/* Fonction de calcul du nombre de tickets */
/*                                         */
/*******************************************/

function wats_get_number_of_tickets()
{
	global $wpdb;
	
	$value = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $wpdb->postmeta WHERE meta_key = %s",'wats_ticket_number'));

	if (!$value)
		$value = 0;
	
	return $value;
}

/*********************************************************************/
/*                                                                   */
/* Fonction de calcul du nombre de tickets par status et utilisateur */
/*                                                                   */
/*********************************************************************/

function wats_get_number_of_tickets_by_status($status,$userid)
{
	global $wpdb;
	
	$query = "SELECT COUNT(*) FROM $wpdb->posts";
	if ($status != 0)
		$query .= " LEFT JOIN $wpdb->postmeta ON ($wpdb->posts.ID = $wpdb->postmeta.post_id) WHERE $wpdb->posts.post_type = %s AND $wpdb->postmeta.meta_key = 'wats_ticket_status' AND $wpdb->postmeta.meta_value = $status AND $wpdb->posts.post_status = 'publish'";
	else
		$query .= " WHERE $wpdb->posts.post_type = %s AND $wpdb->posts.post_status = 'publish'";
		
	if ($userid != 0)
		$query .= " AND $wpdb->posts.post_author = $userid";

	$value = $wpdb->get_var($wpdb->prepare($query,'ticket'));

	if (!$value)
		$value = 0;
	
	return $value;
}

/*****************************************************/
/*                                                   */
/* Fonction de récupération de l'ID du status Closed */
/*                                                   */
/*****************************************************/

function wats_get_closed_status_id()
{
	global $wats_settings;
	
	return $wats_settings['closed_status_id'];
}

/*****************************************************/
/*                                                   */
/* Fonction de remplissage de la table des capacités */
/*                                                   */
/*****************************************************/

function wats_init_capabilities_table()
{
	global $wp_roles, $current_user, $wats_settings;
	
	$wats_capabilities_table = array();
	$wats_capabilities_table['wats_ticket_ownership'] = __('Tickets can be assigned to this user','WATS');
	if ($wats_settings['ticket_visibility_read_only_capability'] == 1)
		$wats_capabilities_table['wats_ticket_read_only'] = __('All tickets can be browsed by this user (read only access)','WATS');

	foreach ($wp_roles->role_names as $roledesc => $rolename)
	{
		if (in_array($roledesc,array_values($current_user->roles)))
		{
			$role = $wp_roles->get_role($roledesc);
			if (!array_key_exists('upload_files',$role->capabilities))
				$wats_capabilities_table['upload_files'] = __('User can attach files to tickets','WATS');
		}
	}
	
	return ($wats_capabilities_table);
}

/*********************************************************/
/*                                                       */
/* Fonction de remplissage de la table des notifications */
/*                                                       */
/*********************************************************/

function wats_init_notification_table()
{
	
	$wats_notification_table = array();
	$wats_notification_table['new_ticket_notification_admin'] = __('Get a mail notification when a new ticket is submitted (admin only)','WATS');
	$wats_notification_table['ticket_update_notification_all_tickets'] = __('Get a mail notification when any ticket is updated (admin only)','WATS');
	$wats_notification_table['ticket_update_notification_my_tickets'] = __('Get a mail notification when a ticket originated or updated by me is updated','WATS');
	
	return ($wats_notification_table);
}

/******************************************************/
/*                                                    */
/* Fonction de récupération du login du premier admin */
/*                                                    */
/******************************************************/

function wats_get_first_admin_login()
{
    global $wpdb;

	$users = $wpdb->get_results("SELECT ID FROM $wpdb->users");
	
	foreach ($users AS $user)
	{
		$user = new WP_user($user->ID);
		if ($user->has_cap('administrator'))
			return ($user->user_login);
	}		
	
	return 0;
}

/****************************************************/
/*                                                  */
/* Fonction de récupération du nom à partir d'un ID */
/*                                                  */
/****************************************************/

function wats_get_full_name($id)
{
	return (get_user_meta($id,"first_name",true)." ".get_user_meta($id,"last_name",true));
}

/******************************************************************************************/
/*                                                                                        */
/* Fonction Ajax de préparation à la construction de la liste des utilisateurs (frontend) */
/*                                                                                        */
/******************************************************************************************/

function wats_ajax_frontend_get_user_list()
{
	global $wpdb, $current_user, $wats_settings;

	wats_load_settings();

	$post = 0;
	$view = 0;
	if (isset($_GET['watsid']) && $_GET['type'] == 'frontendownerlist')
		$view = 1;
	else if (!isset($_GET['watsid']) && $_GET['type'] == 'fsfownerlist')
		$view = 0;
	else if (isset($_GET['watsid']) && $_GET['type'] == 'adminticketeditownerlist')
		$view = 2;
	else if ($_GET['type'] == 'ftlownerlist')
		$view = 3;
	else if ($_GET['type'] == 'ftlauthorlist')
		$view = 4;
	else if ($_GET['type'] == 'fsfauthorlist')
		$view = 5;
	else if ($_GET['type'] == 'adminticketeditauthorlist')
		$view = 6;
	else  if (isset($_GET['watsid']) && $_GET['type'] == 'frontendupdaterlist')
		$view = 7;
		
	if ($view == 1 || $view == 7)
		check_ajax_referer('wats-single-ticket');
	else if ($view == 0 || $view == 5)
		check_ajax_referer('filter-wats-submit-form');
	else if ($view == 3 || $view == 4)
		check_ajax_referer('filter-wats-tickets-list');
	else
		check_ajax_referer('wats-edit-ticket');
	
	if ($view == 1 || $view == 2 || $view == 6 || $view == 7)
	{
		$postid = $_GET['watsid'];
		
		if (wats_is_numeric($postid))
			$post = get_post($postid);
		else
		{
			echo json_encode(array(array("label" => __('Unknow ticket!','WATS'), "value" => "0")));
			exit;
		}

		if ($wats_settings['ticket_status_key_enabled'] == 1 && get_post_meta($post->ID,'wats_ticket_status',true) == wats_get_closed_status_id() && !current_user_can('administrator'))
		{
			echo json_encode(array(array("label" => __('The ticket is closed. Only administrators could reopen it.','WATS'), "value" => "0")));
			exit;
		}
		else if ($wats_settings['visibility'] == 2 && (!is_user_logged_in() || (is_user_logged_in() && !current_user_can('administrator') && $current_user->ID != $post->post_author && ($wats_settings['ticket_visibility_same_company'] == 0 || wats_check_user_same_company($current_user->ID,$post->post_author) == false))))
		{
			echo json_encode(array(array("label" => __("Only admins and ticket author can update this ticket.","WATS"), "value" => "0")));
			exit;
		}
	}
	else if ($view == 0)
	{
		if ($wats_settings['frontend_submit_form_access'] == 0 || ($wats_settings['frontend_submit_form_access'] == 2 && !is_user_logged_in()))
		{
			echo json_encode(array(array("label" => __("You don't have the rights to submit a ticket!","WATS"), "value" => "0")));
			exit;
		}
	}
	else if ($view == 3)
	{
		if ($wats_settings['ticket_assign'] == 0 || (($wats_settings['visibility'] == 1 && !is_user_logged_in()) || ($wats_settings['visibility'] == 2 && !current_user_can('administrator') && ($wats_settings['ticket_visibility_read_only_capability'] == 0 || !current_user_can('wats_ticket_read_only')))))
		{
			echo json_encode(array(array("label" => __("You don't have the rights to filter on the ticket owner!","WATS"), "value" => "0")));
			exit;
		}
	}
	else if ($view == 4)
	{
		if (($wats_settings['visibility'] == 1 && !is_user_logged_in()) || ($wats_settings['visibility'] == 2 && !current_user_can('administrator') && ($wats_settings['ticket_visibility_read_only_capability'] == 0 || !current_user_can('wats_ticket_read_only'))))
		{
			echo json_encode(array(array("label" => __("You don't have the rights to filter on the ticket author!","WATS"), "value" => "0")));
			exit;
		}
	}
	else if ($view == 5)
	{
		if ($wats_settings['frontend_submit_form_access'] == 0 || ($wats_settings['frontend_submit_form_access'] == 2 && !is_user_logged_in()) || !current_user_can('administrator'))
		{
			echo json_encode(array(array("label" => __("You don't have the rights to submit a ticket!","WATS"), "value" => "0")));
			exit;
		}
	}
	
	if ($view == 4 || $view == 5 || $view == 6 || $view == 7)
	{
		$searched_value = stripslashes($_GET['value']);
		$result = wats_ajax_get_user_list($searched_value,0,array(),array());
		if ($view == 4)
			array_push($result,array('label' => __('Any','WATS'), 'value' => "0"));
		echo (json_encode($result));
		exit;
	}
	else
	{	
		$wats_ticket_assign = $wats_settings['ticket_assign'];
		
		$role = array_shift($current_user->roles);
		$user_can_assign = 0;
		if (isset($role) && isset($wats_settings['ticket_assignment_'.$role]) && $wats_settings['ticket_assignment_'.$role] == 1)
			$user_can_assign = 1;
		
		$searched_value = stripslashes($_GET['value']);
		if ($wats_ticket_assign == 1 || ($wats_ticket_assign == 2 && $user_can_assign == 1))
		{
			$capability = array("administrator");
			$included = array();
			if ($wats_settings['ticket_assign_user_list'] == 0)
			{
				$capability = 0;
			}
			else if ($wats_settings['ticket_assign_user_list'] == 1)
			{
				$capability = array("administrator");
				if (is_object($post))
					$included[] = $post->post_author;
			}
			else if ($wats_settings['ticket_assign_user_list'] == 2)
			{
				$capability = array("wats_ticket_ownership");
				if (is_object($post))
					$included[] = $post->post_author;
			}
			else if ($wats_settings['ticket_assign_user_list'] == 3)
			{
				$capability = array("administrator","wats_ticket_ownership");
			}
			
		
			switch ($_GET['type'])
			{
				case 'frontendownerlist':echo json_encode(wats_ajax_get_user_list($searched_value,$capability,array(),$included));break;
				case 'fsfownerlist':echo json_encode(wats_ajax_get_user_list($searched_value,$capability,array(),$included));break;
				case 'adminticketeditownerlist':echo json_encode(wats_ajax_get_user_list($searched_value,$capability,array(),$included));break;
				case 'ftlownerlist':
					$result = wats_ajax_get_user_list($searched_value,0,array(),array());
					array_push($result,array('label' => __('Any','WATS'), 'value' => "0"));
					array_push($result,array('label' => __('None','WATS'), 'value' => "1"));
					echo (json_encode($result));
					break;
				default:break;
			}
		}
		else
		{
			echo json_encode(array(array("label" => __("You don't have the rights to assign this ticket!","WATS"), "value" => "0")));
			exit;
		}
	}
	
	exit;
}

/***************************************************************************************/
/*                                                                                     */
/* Fonction Ajax de préparation à la construction de la liste des utilisateurs (admin) */
/*                                                                                     */
/***************************************************************************************/

function wats_ajax_admin_get_user_list()
{
	global $wpdb, $current_user;

	check_ajax_referer('update-wats-options');

	$searched_value = stripslashes($_GET['value']);
	if (current_user_can('administrator'))
	{
		switch ($_GET['type'])
		{
			case 'guestlist':echo json_encode(wats_ajax_get_user_list($searched_value,array('edit_posts'),array($current_user->ID),array()));break;
			case 'defaultauthorlist':echo json_encode(wats_ajax_get_user_list($searched_value,0,array(),array()));break;
			default:break;
		}
	}

	exit;
}

/**************************************************************/
/*                                                            */
/* Fonction Ajax de construction de la liste des utilisateurs */
/*                                                            */
/**************************************************************/

function wats_ajax_get_user_list($searched_value,$required_capability,$excluded_user_list,$included_user_list)
{
	global $wpdb, $wats_settings;
	
	wats_load_settings();
	
	$metakeylist = wats_get_list_of_user_meta_keys(1);
	foreach ($metakeylist AS $index => $metakey)
	{
		if (strpos($wats_settings['user_selector_format'],$metakey) === false)
			unset($metakeylist[$index]);
	}

	$join = '';
	$where = '';
	$x = 0;
	foreach ($metakeylist AS $index => $metakey)
	{
		$x++;
		$join .= " LEFT JOIN $wpdb->usermeta AS wp".$x." ON wp0.ID = wp".$x.".user_id";
		$where .= " OR (wp".$x.".meta_key = '".$metakey."' AND wp".$x.".meta_value LIKE '%%".esc_sql($wpdb->esc_like($searched_value))."%%')";
	}

	$limit = " LIMIT 0,".WATS_MAX_NUMBER_OF_RESULTS_FOR_AUTO_COMPLETE;
	$users = $wpdb->get_results("SELECT DISTINCT user_login, ID FROM $wpdb->users as wp0 ".$join." WHERE wp0.user_login LIKE '%%".esc_sql($wpdb->esc_like($searched_value))."%%' ".$where.$limit);

	$list = array();
	foreach ($users as $user)
	{
		$user = new WP_user($user->ID);
		if (!in_array($user->ID,$excluded_user_list,true))
		{
			$has_cap = 0;
			if (is_array($required_capability))
			foreach ($required_capability as $key => $capability)
			{
				if ($user->has_cap($capability))
					$has_cap = 1;
			}
			
			if ((!is_array($required_capability) && $required_capability === 0) || $has_cap == 1 || in_array("$user->ID",$included_user_list,true))
			{
				$output = $wats_settings['user_selector_format'];
				foreach ($metakeylist AS $metakey)
				{
					if (strpos($wats_settings['user_selector_format'],$metakey) !== false)
						$output = str_replace($metakey,get_user_meta($user->ID,$metakey,true),$output);
				}
				$output = str_replace('user_login',$user->user_login,$output);
				if (wats_is_string(stripslashes($output)))
					$entry['label'] = esc_html(stripslashes($output));
				else
					$entry['label'] = $user->user_login;
				$entry['value'] = $user->user_login;
				array_push($list,$entry);
			}
		}
	}
	
	return ($list);
}

/*********************************************************/
/*                                                       */
/* Fonction de construction de la liste des utilisateurs */
/*                                                       */
/*********************************************************/

function wats_build_user_list($firstitem,$cap)
{
    global $wpdb, $wats_settings;

	wats_load_settings();
	
	$order1 = $wats_settings['user_selector_order_1'];
	$order2 = $wats_settings['user_selector_order_2'];
	
    $users = $wpdb->get_results($wpdb->prepare("SELECT ID FROM $wpdb->users LEFT JOIN $wpdb->usermeta AS wp1 ON ($wpdb->users.ID = wp1.user_id AND wp1.meta_key = %s) LEFT JOIN $wpdb->usermeta AS wp2 ON ($wpdb->users.ID = wp2.user_id AND wp2.meta_key = %s) ORDER BY wp1.meta_value, wp2.meta_value",$order1,$order2));
    $userlist = array();
	if ($firstitem !== 0)
		$userlist[0] = $firstitem;
	
	$metakeylist = wats_get_list_of_user_meta_keys(1);
	foreach ($metakeylist AS $index => $metakey)
	{
		if (strpos($wats_settings['user_selector_format'],$metakey) === false)
			unset($metakeylist[$index]);
	}
	
	foreach ($users AS $user)
    {
		$user = new WP_user($user->ID);
		if ($cap === 0 || $user->has_cap($cap))
		{
			$output = $wats_settings['user_selector_format'];
			foreach ($metakeylist AS $metakey)
			{
				if (strpos($wats_settings['user_selector_format'],$metakey) !== false)
					$output = str_replace($metakey,get_user_meta($user->ID,$metakey,true),$output);
			}
			$output = str_replace('user_login',$user->user_login,$output);
			if (wats_is_string(stripslashes($output)))
				$userlist[$user->user_login] = esc_html(stripslashes($output));
			else
				$userlist[$user->user_login] = $user->user_login;
		}
	}
        
    return ($userlist);
}

function wats_build_user_array_from_company($userID)
{
    global $wpdb, $wats_settings;

	wats_load_settings();
	
	$list = Array();
	$company = get_user_meta($userID,$wats_settings['company_meta_key_profile'],true);
	
	if (strlen($company) > 0)
	{
		$users = $wpdb->get_results($wpdb->prepare("SELECT ID FROM $wpdb->users JOIN $wpdb->usermeta AS wp3 ON ($wpdb->users.ID = wp3.user_id AND wp3.meta_key = %s AND wp3.meta_value = %s)",$wats_settings['company_meta_key_profile'],$company));
		foreach ($users as $user)
		{
			$list[] = $user->ID;
		}
	}
	else
		$list[] = $userID;

	return $list;
}

/**************************************************************************************/
/*                                                                                    */
/* Fonction de construction de la liste des utilisateurs appartenant à une entreprise */
/*                                                                                    */
/**************************************************************************************/

function wats_build_user_list_from_company($firstitem,$cap,$company)
{
    global $wpdb, $wats_settings;

	wats_load_settings();
	
	$order1 = $wats_settings['user_selector_order_1'];
	$order2 = $wats_settings['user_selector_order_2'];
	
	if ($company != "0")
		$users = $wpdb->get_results($wpdb->prepare("SELECT ID FROM $wpdb->users LEFT JOIN $wpdb->usermeta AS wp1 ON ($wpdb->users.ID = wp1.user_id AND wp1.meta_key = '$order1') LEFT JOIN $wpdb->usermeta AS wp2 ON ($wpdb->users.ID = wp2.user_id AND wp2.meta_key = '$order2') JOIN $wpdb->usermeta AS wp3 ON ($wpdb->users.ID = wp3.user_id AND wp3.meta_key = %s AND wp3.meta_value = %s) ORDER BY wp1.meta_value, wp2.meta_value",$wats_settings['company_meta_key_profile'],$company));
	else
		$users = $wpdb->get_results($wpdb->prepare("SELECT ID FROM $wpdb->users AS wp0 LEFT JOIN $wpdb->usermeta AS wp1 ON (wp0.ID = wp1.user_id AND wp1.meta_key = '$order1') LEFT JOIN $wpdb->usermeta AS wp2 ON (wp0.ID = wp2.user_id AND wp2.meta_key = '$order2') WHERE NOT EXISTS (SELECT * FROM $wpdb->usermeta AS wp3 WHERE wp0.ID = wp3.user_ID AND wp3.meta_key = %s) ORDER BY wp1.meta_value, wp2.meta_value",$wats_settings['company_meta_key_profile']));

    $userlist = array();
	if ($firstitem !== 0)
		$userlist[0] = $firstitem;
	
	$metakeylist = wats_get_list_of_user_meta_keys(1);
	foreach ($metakeylist AS $index => $metakey)
	{
		if (strpos($wats_settings['user_selector_format'],$metakey) === false)
			unset($metakeylist[$index]);
	}
	
	foreach ($users AS $user)
    {
		$user = new WP_user($user->ID);
		if ($cap === 0 || $user->has_cap($cap))
		{
			$output = $wats_settings['user_selector_format'];
			foreach ($metakeylist AS $metakey)
			{
				if (strpos($wats_settings['user_selector_format'],$metakey) !== false)
					$output = str_replace($metakey,get_user_meta($user->ID,$metakey,true),$output);
			}
			$output = str_replace('user_login',$user->user_login,$output);
			if (wats_is_string(stripslashes($output)))
				$userlist[$user->user_login] = esc_html(stripslashes($output));
			else
				$userlist[$user->user_login] = $user->user_login;
		}
	}
        
    return ($userlist);
}

/*******************************************/
/*                                         */
/* Fonction de construction du nom formaté */
/*                                         */
/*******************************************/

function wats_build_formatted_name($ID)
{
    global $wpdb, $wats_settings;

    $userlist = array();
	$metakeylist = wats_get_list_of_user_meta_keys(1);
	foreach ($metakeylist AS $index => $metakey)
	{
		if (strpos($wats_settings['user_selector_format'],$metakey) === false)
			unset($metakeylist[$index]);
	}
	
	$user = new WP_user($ID);
	$output = $wats_settings['user_selector_format'];
	foreach ($metakeylist AS $metakey)
	{
		if (strpos($wats_settings['user_selector_format'],$metakey) !== false)
			$output = str_replace($metakey,get_user_meta($user->ID,$metakey,true),$output);
	}
	$output = str_replace('user_login',$user->user_login,$output);
	if (wats_is_string(stripslashes($output)))
		$userlist[$user->user_login] = esc_html(stripslashes($output));
	else
		$userlist[$user->user_login] = $user->user_login;

    return ($userlist);
}

/*******************************************************/
/*                                                     */
/* Fonction de remplissage de la liste des meta keys */
/* view 0 : string contenant les meta keys           */
/* view 1 : table contenant les meta keys            */
/*                                                     */
/*******************************************************/

function wats_get_list_of_user_meta_keys($view)
{
	global $wpdb;
	
	$keys = $wpdb->get_results("SELECT DISTINCT meta_key FROM $wpdb->usermeta");
	if ($view == 0)
	{
		$list = '';
		$x = 0;
		foreach ($keys AS $key)
		{
			if (wats_is_string($key->meta_key))
			{
				if ($x != 0)
					$list .= ', ';
				else
					$x = 1;
				$list .= $key->meta_key;
			}
		}
		$list .= '.';
	}
	else
	{
		$list = array();
		foreach ($keys AS $key)
		{
			if (wats_is_string($key->meta_key))
				$list[] = $key->meta_key;
		}
	}
	
	return($list);
}

/*******************************************************/
/*                                                     */
/* Fonction de remplissage de la liste des meta values */
/*                                                     */
/*******************************************************/

function wats_build_list_meta_values($key)
{
	global $wpdb;
	
	$values = $wpdb->get_results($wpdb->prepare("SELECT DISTINCT meta_value FROM $wpdb->usermeta WHERE meta_key=%s ORDER BY meta_value ASC",$key));
	$list = array();
	foreach ($values AS $value)
	{
		$list[] = $value->meta_value;
	}
	
	return($list);
}

/******************************************************/
/*                                                    */
/* Fonction de récupération de l'ID à partir du login */
/*                                                    */
/******************************************************/

function wats_get_user_ID_from_user_login($login)
{
	global $wpdb;
	
	$id = $wpdb->get_var($wpdb->prepare("SELECT ID FROM $wpdb->users WHERE user_login=%s",$login));
	
	return($id);
}

/******************************************************/
/*                                                    */
/* Fonction de modification du code des single quotes */
/*                                                    */
/******************************************************/

function wats_fix_single_quotes($str)
{
	
	$str = str_replace('#039;','#39;',$str);
	
	return($str);
}

/**********************************************************/
/*                                                        */
/* Fonction de retour la signature pour les notifications */
/*                                                        */
/**********************************************************/

function wats_get_mail_notification_signature()
{
	global $wats_settings;

	return(esc_html(str_replace(array('\r\n','\r','<br />'),"\r\n",html_entity_decode(stripslashes($wats_settings['notification_signature'])))));
}

/***************************************************/
/*                                                 */
/* Fonction d'affichage des règles de notification */
/*                                                 */
/***************************************************/

function wats_admin_display_notification_rule($rule)
{
	global $wats_settings,$wats_rule_scope;
	
	$output = '';
	
	$listepriority = isset($wats_settings['wats_priorities']) ? $wats_settings['wats_priorities'] : 0;
	$listetype = isset($wats_settings['wats_types']) ? $wats_settings['wats_types'] : 0;
	$listestatus = isset($wats_settings['wats_statuses']) ? $wats_settings['wats_statuses'] : 0;
	$listeproduct = isset($wats_settings['wats_products']) ? $wats_settings['wats_products'] : 0;
	
	foreach ($rule AS $key => $value)
	{
		if (strlen($output) > 0 && !in_array($key,array('notify_author','notify_owner','notify_admins','notify_updaters')))
			$output .= __(' AND ','WATS');
		if ($value != "0")
		{
			switch ($key)
			{
				case "scope" : $output .= $key." : ".$wats_rule_scope[$value]; break;
				case "priority" : $output .= $key." : ".$listepriority[$value]; break;
				case "type" : $output .= $key." : ".$listetype[$value]; break;
				case "status" : $output .= $key." : ".$listestatus[$value]; break;
				case "product" : $output .= $key." : ".$listeproduct[$value]; break;
				case "country" : $output .= $key." : ".$value; break;
				case "company" : $output .= $key." : ".$value; break;
				case "category" : $output .= $key." : ".get_cat_name($value); break;
				case "duedatefield" : $output .= $key." : ".$value ; break;
				case "duedateinterval" : $output .= __('Notification frequency','WATS').' : '.__('every','WATS').' '.$value.' '.__('days','WATS'); break;
				case "duedatestart" : $output .= __('Notification start','WATS')." : ".$value.' '.__('days before the due date','WATS') ; break;

				default : break;
			}
		}
		else
			$output .= $key." : ".__('Any','WATS');
	}

	return $output;
}

/****************************************************/
/*                                                  */
/* Fonction d'affichage des utilisateurs à notifier */
/*                                                  */
/****************************************************/

function wats_admin_display_notification_rules_notifiers($rule)
{
	$output = '';
	foreach ($rule AS $key => $value)
	{
		if (strlen($output) > 0 && $value == 'true')
			$output .= __(' AND ','WATS');
		switch ($key)
		{
			case "notify_author" : if ($value == 'true') $output .= __('Ticket author','WATS'); break;
			case "notify_owner" : if ($value == 'true') $output .= __('Ticket owner','WATS'); break;
			case "notify_admins" : if ($value == 'true') $output .= __('All administrators','WATS'); break;
			case "notify_updaters" : if ($value == 'true') $output .= __('Ticket updaters','WATS'); break;
			default : break;
		}
	}
	
	return $output;
}

/*******************************************************/
/*                                                     */
/* Fonction de construction des règles de notification */
/*                                                     */
/*******************************************************/

function wats_admin_build_notification_rule($rule)
{
	$rules = explode(";",$rule);
	
	unset($rules[count($rules)-1]);
	$ruleset = array();
	foreach ($rules AS $rulesentry)
	{
		$newrule = explode(":",$rulesentry);
		$ruleset = array_merge($ruleset,array($newrule[0] => $newrule[1]));
	}
	
	return $ruleset;
}

/****************************************************************/
/*                                                              */
/* Fonction de mise à jour du format des règles de notification */
/*                                                              */
/****************************************************************/

function wats_update_notification_rules_format()
{
	$wats_notification_rules = get_option('wats_notification_rules');

	if (is_array($wats_notification_rules))
	{
		foreach ($wats_notification_rules AS $key => $rulesentry)
		{
			foreach ($rulesentry as $rule => $list)
			{
				if (strstr($rule,'scope') == false)
				{
					$rule = "scope:1;".$rule;
				}
			}
			$wats_notification_rules[$key] = array($rule => $list);
		}
	
		update_option('wats_notification_rules', $wats_notification_rules);
	}
		
	return;
}

/*************************************************/
/*                                               */
/* Fonction de construction de la liste des pays */
/*                                               */
/*************************************************/

function wats_build_country_list()
{

	$country_list = array("Afghanistan" => "AF",
				"Åland Islands" => "AX",
				"Albania" => "AL",
				"Algeria" => "DZ",
				"American Samoa" => "AS",
				"Andorra" => "AD",
				"Angola" => "AO",
				"Anguilla" => "AI",
				"Antarctica" => "AQ",
				"Antigua And Barbuda" => "AG",
				"Argentina" => "AR",
				"Armenia" => "AM",
				"Aruba" => "AW",
				"Australia" => "AU",
				"Austria" => "AT",
				"Azerbaijan" => "AZ",
				"Bahamas" => "BS",
				"Bahrain" => "BH",
				"Bangladesh" => "BD",
				"Barbados" => "BB",
				"Belarus" => "BY",
				"Belgium" => "BE",
				"Belize" => "BZ",
				"Benin" => "BJ",
				"Bermuda" => "BM",
				"Bhutan" => "BT",
				"Bolivia, Plurinational State Of" => "BO",
				"Bosnia And Herzegovina" => "BA",
				"Botswana" => "BW",
				"Bouvet Island" => "BV",
				"Brazil" => "BR",
				"British Indian Ocean Territory" => "IO",
				"Brunei Darussalam" => "BN",
				"Bulgaria" => "BG",
				"Burkina Faso" => "BF",
				"Burundi" => "BI",
				"Cambodia" => "KH",
				"Cameroon" => "CM",
				"Canada" => "CA",
				"Cape Verde" => "CV",
				"Cayman Islands" => "KY",
				"Central African Republic" => "CF",
				"Chad" => "TD",
				"Chile" => "CL",
				"China" => "CN",
				"Christmas Island" => "CX",
				"Cocos (Keeling) Islands" => "CC",
				"Colombia" => "CO",
				"Comoros" => "KM",
				"Congo" => "CG",
				"Congo, The Democratic Republic Of The" => "CD",
				"Cook Islands" => "CK",
				"Costa Rica" => "CR",
				"Côte D'Ivoire" => "CI",
				"Croatia" => "HR",
				"Cuba" => "CU",
				"Cyprus" => "CY",
				"Czech Republic" => "CZ",
				"Denmark" => "DK",
				"Djibouti" => "DJ",
				"Dominica" => "DM",
				"Dominican Republic" => "DO",
				"Ecuador" => "EC",
				"Egypt" => "EG",
				"El Salvador" => "SV",
				"Equatorial Guinea" => "GQ",
				"Eritrea" => "ER",
				"Estonia" => "EE",
				"Ethiopia" => "ET",
				"Falkland Islands (Malvinas)" => "FK",
				"Faroe Islands" => "FO",
				"Fiji" => "FJ",
				"Finland" => "FI",
				"France" => "FR",
				"French Guiana" => "GF",
				"French Polynesia" => "PF",
				"French Southern Territories" => "TF",
				"Gabon" => "GA",
				"Gambia" => "GM",
				"Georgia" => "GE",
				"Germany" => "DE",
				"Ghana" => "GH",
				"Gibraltar" => "GI",
				"Greece" => "GR",
				"Greenland" => "GL",
				"Grenada" => "GD",
				"Guadeloupe" => "GP",
				"Guam" => "GU",
				"Guatemala" => "GT",
				"Guernsey" => "GG",
				"Guinea" => "GN",
				"Guinea-Bissau" => "GW",
				"Guyana" => "GY",
				"Haiti" => "HT",
				"Heard Island And Mcdonald Islands" => "HM",
				"Holy See (Vatican City State)" => "VA",
				"Honduras" => "HN",
				"Hong Kong" => "HK",
				"Hungary" => "HU",
				"Iceland" => "IS",
				"India" => "IN",
				"Indonesia" => "ID",
				"Iran, Islamic Republic Of" => "IR",
				"Iraq" => "IQ",
				"Ireland" => "IE",
				"Isle Of Man" => "IM",
				"Israel" => "IL",
				"Italy" => "IT",
				"Jamaica" => "JM",
				"Japan" => "JP",
				"Jersey" => "JE",
				"Jordan" => "JO",
				"Kazakhstan" => "KZ",
				"Kenya" => "KE",
				"Kiribati" => "KI",
				"Korea, Democratic People'S Republic Of" => "KP",
				"Korea, Republic Of" => "KR",
				"Kuwait" => "KW",
				"Kyrgyzstan" => "KG",
				"Lao People'S Democratic Republic" => "LA",
				"Latvia" => "LV",
				"Lebanon" => "LB",
				"Lesotho" => "LS",
				"Liberia" => "LR",
				"Libyan Arab Jamahiriya" => "LY",
				"Liechtenstein" => "LI",
				"Lithuania" => "LT",
				"Luxembourg" => "LU",
				"Macao" => "MO",
				"Macedonia, The Former Yugoslav Republic Of" => "MK",
				"Madagascar" => "MG",
				"Malawi" => "MW",
				"Malaysia" => "MY",
				"Maldives" => "MV",
				"Mali" => "ML",
				"Malta" => "MT",
				"Marshall Islands" => "MH",
				"Martinique" => "MQ",
				"Mauritania" => "MR",
				"Mauritius" => "MU",
				"Mayotte" => "YT",
				"Mexico" => "MX",
				"Micronesia, Federated States Of" => "FM",
				"Moldova, Republic Of" => "MD",
				"Monaco" => "MC",
				"Mongolia" => "MN",
				"Montenegro" => "ME",
				"Montserrat" => "MS",
				"Morocco" => "MA",
				"Mozambique" => "MZ",
				"Myanmar" => "MM",
				"Namibia" => "NA",
				"Nauru" => "NR",
				"Nepal" => "NP",
				"Netherlands" => "NL",
				"Netherlands Antilles" => "AN",
				"New Caledonia" => "NC",
				"New Zealand" => "NZ",
				"Nicaragua" => "NI",
				"Niger" => "NE",
				"Nigeria" => "NG",
				"Niue" => "NU",
				"Norfolk Island" => "NF",
				"Northern Mariana Islands" => "MP",
				"Norway" => "NO",
				"Oman" => "OM",
				"Pakistan" => "PK",
				"Palau" => "PW",
				"Palestinian Territory, Occupied" => "PS",
				"Panama" => "PA",
				"Papua New Guinea" => "PG",
				"Paraguay" => "PY",
				"Peru" => "PE",
				"Philippines" => "PH",
				"Pitcairn" => "PN",
				"Poland" => "PL",
				"Portugal" => "PT",
				"Puerto Rico" => "PR",
				"Qatar" => "QA",
				"Réunion" => "RE",
				"Romania" => "RO",
				"Russian Federation" => "RU",
				"Rwanda" => "RW",
				"Saint Barthélemy" => "BL",
				"Saint Helena, Ascension And Tristan Da Cunha" => "SH",
				"Saint Kitts And Nevis" => "KN",
				"Saint Lucia" => "LC",
				"Saint Martin" => "MF",
				"Saint Pierre And Miquelon" => "PM",
				"Saint Vincent And The Grenadines" => "VC",
				"Samoa" => "WS",
				"San Marino" => "SM",
				"Sao Tome And Principe" => "ST",
				"Saudi Arabia" => "SA",
				"Senegal" => "SN",
				"Serbia" => "RS",
				"Seychelles" => "SC",
				"Sierra Leone" => "SL",
				"Singapore" => "SG",
				"Slovakia" => "SK",
				"Slovenia" => "SI",
				"Solomon Islands" => "SB",
				"Somalia" => "SO",
				"South Africa" => "ZA",
				"South Georgia And The South Sandwich Islands" => "GS",
				"Spain" => "ES",
				"Sri Lanka" => "LK",
				"Sudan" => "SD",
				"Suriname" => "SR",
				"Svalbard And Jan Mayen" => "SJ",
				"Swaziland" => "SZ",
				"Sweden" => "SE",
				"Switzerland" => "CH",
				"Syrian Arab Republic" => "SY",
				"Taiwan, Province Of China" => "TW",
				"Tajikistan" => "TJ",
				"Tanzania, United Republic Of" => "TZ",
				"Thailand" => "TH",
				"Timor-Leste" => "TL",
				"Togo" => "TG",
				"Tokelau" => "TK",
				"Tonga" => "TO",
				"Trinidad And Tobago" => "TT",
				"Tunisia" => "TN",
				"Turkey" => "TR",
				"Turkmenistan" => "TM",
				"Turks And Caicos Islands" => "TC",
				"Tuvalu" => "TV",
				"Uganda" => "UG",
				"Ukraine" => "UA",
				"United Arab Emirates" => "AE",
				"United Kingdom" => "GB",
				"United States" => "US",
				"United States Minor Outlying Islands" => "UM",
				"Uruguay" => "UY",
				"Uzbekistan" => "UZ",
				"Vanuatu" => "VU",
				"Vatican City State" => "",
				"Venezuela, Bolivarian Republic Of" => "VE",
				"Viet Nam" => "VN",
				"Virgin Islands, British" => "VG",
				"Virgin Islands, U.S." => "VI",
				"Wallis And Futuna" => "WF",
				"Western Sahara" => "EH",
				"Yemen" => "YE",
				"Zambia" => "ZM",
				"Zimbabwe" => "ZW");
				
	return $country_list;
}

/*******************************************************/
/*                                                     */
/* Fonction pour vérifier que deux utilisateurs appartiennent à la même compagnie */
/*                                                     */
/*******************************************************/

function wats_check_user_same_company($userID,$userID2)
{
	global $wats_settings;
	
	$user_company = get_user_meta($userID,$wats_settings['company_meta_key_profile'],true);
	$author_company = get_user_meta($userID2,$wats_settings['company_meta_key_profile'],true);
	
	if (strlen($user_company) > 0 && strlen($author_company) > 0 && $user_company === $author_company)
		return true;

	return false;
}

function wats_get_posts_with_shortcode($shortcode)
{
	global $wpdb;
	
	$posts = $wpdb->get_results($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE post_content LIKE %s AND post_status='publish'",'%'.$wpdb->esc_like($shortcode).'%'));
	
	return $posts;
}

function wats_compare_url($url1,$url2)
{
	if (parse_url($url1,PHP_URL_HOST) != parse_url($url2,PHP_URL_HOST))
		return false;
		
	return true;
}

?>