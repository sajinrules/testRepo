<?php
header("Content-Type: application/javascript");
?>
jQuery(document).ready(function() {
	jQuery("input[name*='wats_cf_datepicker']").datepicker({dateFormat : 'mm/dd/yy'});

	var selected_wats_select_ticket_owner_ac = 0;
	jQuery('#wats_select_ticket_owner_ac').autocomplete({
						source: function(request,response)  {
						jQuery.ajax({
							url: ajaxurl+"?action=wats_ajax_frontend_get_user_list",
							dataType: "json",
							data: {
								value:jQuery('#wats_select_ticket_owner_ac').val(),
								_ajax_nonce:jQuery("#_wpnonce_wats_single_ticket").val(),
								type:'frontendownerlist',
								'cookie': encodeURIComponent(document.cookie),
								watsid:watsid
							},
							success: function(data) {
								if (jQuery.isEmptyObject(data) == true)
									jQuery('#wats_select_ticket_owner').val("0");
								response(
								jQuery.map(data, function(item)
								{ return{value:item.label,label:item.label,hidden:item.value} }));
							}
							});
						},
						select: function(event,ui) {
							selected_wats_select_ticket_owner_ac = 1;
							jQuery('#wats_select_ticket_owner').val(ui.item.hidden);
						},
						close : function(event,ui) {
							if (selected_wats_select_ticket_owner_ac == 0)	
								jQuery('#wats_select_ticket_owner').val("0");
							selected_wats_select_ticket_owner_ac = 0;
						},
						minLength:3,
						delay:300
	});
	
	var wats_select_ticket_updater_ac = 0;
	if (jQuery("#wats_select_ticket_updater_ac").is("input"))
	{
		jQuery('#wats_select_ticket_updater_ac').autocomplete({
							source: function(request,response)  {
							jQuery.ajax({
								url: ajaxurl+"?action=wats_ajax_frontend_get_user_list",
								dataType: "json",
								data: {
									value:jQuery('#wats_select_ticket_updater_ac').val(),
									_ajax_nonce:jQuery("#_wpnonce_wats_single_ticket").val(),
									type:'frontendupdaterlist',
									'cookie': encodeURIComponent(document.cookie),
									watsid:watsid
								},
								success: function(data) {
									if (jQuery.isEmptyObject(data) == true)
										jQuery('#wats_select_ticket_updater').val("0");
									response(
									jQuery.map(data, function(item)
									{ return{value:item.label,label:item.label,hidden:item.value} }));
								}
								});
							},
							select: function(event,ui) {
								wats_select_ticket_updater_ac = 1;
								jQuery('#wats_select_ticket_updater').val(ui.item.hidden);
							},
							close : function(event,ui) {
								if (wats_select_ticket_updater_ac == 0)	
									jQuery('#wats_select_ticket_updater').val("0");
								wats_select_ticket_updater_ac = 0;
							},
							minLength:3,
							delay:300
		});
	}
	
	 jQuery('#wats_company_list').change(function() {
	
		var idcompany = jQuery('#wats_company_list option:selected').val();
		var type = 'frontendupdaterlist';

		jQuery.post(ajaxurl, {action:"wats_get_user_list_from_company", _ajax_nonce:jQuery("#_wpnonce_wats_single_ticket").val(), idcompany:idcompany, type:type},
			function(res)
			{
				var message_result = eval('(' + res + ')');
				if (message_result.success == "FALSE")
				{
					alert(message_result.error);
				}
				else
				{
					jQuery('#wats_div_ticket_updater_from_company').html(message_result.error);
				}
				
				return false;
			});
			
		return false;
	});
	
	return false;
});